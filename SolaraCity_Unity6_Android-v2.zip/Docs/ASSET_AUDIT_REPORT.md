# Аудит 3D-ресурсов Solara City (v0.1.0 → v0.2.0)

## 1. Фактическое состояние каталогов ресурсов

На момент аудита в репозитории **отсутствуют готовые внешние 3D-модели, текстуры и анимационные клипы**:

| Каталог | Фактических ассетов | Статус |
| :--- | :---: | :--- |
| `Assets/Models/` | 0 | Только структура подпапок (`Characters/`, `Vehicles/`, `Buildings/`, `Props/`) |
| `Assets/Textures/` | 0 | Внешние PNG/TGA отсутствуют; в v0.2.0 добавлен `ProceduralTextureGenerator` (256×256) |
| `Assets/Animations/` | 0 клипов | В v0.2.0 добавлен автогенератор шаблона `SolaraHumanoid_Template.controller` |
| `Assets/Prefabs/` | 0 | Ожидает сборки префабов после импорта FBX/GLTF |
| `Assets/Materials/` | 0 | Материалы создаются в рантайме через `MaterialFactory` (URP Lit) |

## 2. Полный реестр временных примитивных моделей в коде

| Подсистема | Файл | Примитивы | Приоритет замены |
| :--- | :--- | :--- | :---: |
| **Персонаж** | `Assets/Scripts/Player/PlayerFactory.cs` | 8 примитивов (`Cube` — торс, руки, ноги, обувь, причёска; `Sphere` — голова) + `ProceduralCharacterAnimator` | **Критический (P0)** |
| **Транспорт (4 модели)** | `Assets/Scripts/Vehicles/VehicleSpawner.cs` | `Cube` (кузов, кабина, бамперы, фары, зеркала) + `Cylinder` × 8 (шины и диски) | **Критический (P0)** |
| **Небоскрёбы и жилые здания** | `Assets/Scripts/World/DistrictBuilder.cs` | `Cube` (6 башен, 4 жилых здания, крыши, козырьки) | **Высокий (P1)** |
| **Ключевые локации (Автосалон, АЗС, Промзона, Парк)** | `Assets/Scripts/World/DistrictBuilder.cs` | `Cube` (шоурум, навес АЗС, колонки, склад, контейнеры, фонтан) + `Cylinder`/`Sphere` (6 деревьев, 12 фонарей, 4 маркера) | **Высокий (P1)** |
| **Дороги и тротуары** | `Assets/Scripts/World/DistrictBuilder.cs` | `Cube` (дорожное полотно, разметка, зебры, бордюры, базовая плоскость) | **Средний (P2)** |
| **Маяки миссий** | `Assets/Scripts/Missions/WaypointBeacon.cs` | `Cylinder` × 2 (кольцо + луч) | **Низкий (P3 — заменить на VFX-шейдер)** |

## 3. Что уже улучшено в v0.2.0 без имитации несуществующих FBX

1. **Инфраструктура бесшовной подмены (`VisualAssetCatalog`):** добавлен `ScriptableObject` `Assets/Resources/SolaraVisualCatalog.asset`. Подключение готовых моделей персонажа, авто и зданий выполняется через инспектор Unity без переписывания игровой логики.
2. **Мост Humanoid-анимаций (`CharacterAnimationBridge`) + генератор контроллера (`SolaraAnimatorTemplateGenerator`):** `PlayerController` уже транслирует параметры `Speed`, `IsSprinting`, `IsGrounded`, `VerticalVelocity`, `Jump`, `EnterVehicle`, `ExitVehicle`, `IsSeated` и привязывает персонажа к `DriverSeatAnchor` при наличии Humanoid Rig.
3. **Связка детальных авто (`VehicleVisualBinding`):** готова к приёму FBX-автомобилей с отдельными колёсами, точкой входа в дверь, посадкой водителя и динамическими стоп-сигналами.
4. **Мобильные PBR-текстуры и отражения:** добавлен `ProceduralTextureGenerator` (асфальт с Normal Map, плитка тротуара с Normal Map, стеклянные фасады с ночной подсветкой окон, гофрированный металл промзоны, газон) и `EnvironmentReflectionRig` (один `ReflectionProbe` 128×128 с обновлением раз в 2 игровых часа).
5. **Автоматический импортёр под Android GPU (`MobileAssetImportProcessor`):** автоматически сжимает все новые текстуры в `ASTC_6x6` / `ASTC_5x5`, отключает Read/Write, выставляет Humanoid Rig для персонажей и оптимизирует меши.
