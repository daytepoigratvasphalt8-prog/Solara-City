# Настройка GitHub Actions для автоматической сборки Android APK

Файл workflow уже расположен по пути `.github/workflows/android-build.yml`.

## 1. Как запускается сборка

- **Автоматически:** при каждом `push` в ветку `main`.
- **Вручную:** во вкладке **Actions → Build Solara City Android APK → Run workflow** (с выбором режима `debug` или `release`).

Готовый файл `SolaraCity-*.apk` сохраняется в **GitHub Actions Artifacts** (срок хранения — 14 дней). При сбое сборки логи автоматически выгружаются отдельным артефактом `Unity-Build-Error-Logs-*`.

## 2. Необходимые секреты GitHub (Settings → Secrets and variables → Actions)

Никакие ключи и пароли не хранятся в коде репозитория.

### Вариант A — Unity Personal License (бесплатная)
1. Получите файл активации `.ulf` через [GameCI Activation](https://game.ci/docs/github/activation) или локально из Unity Hub.
2. Добавьте в GitHub Secrets:
   - `UNITY_LICENSE` — полное XML-содержимое файла `.ulf`.
   - `UNITY_EMAIL` — email аккаунта Unity.
   - `UNITY_PASSWORD` — пароль аккаунта Unity.

### Вариант B — Unity Pro / Plus License
- `UNITY_SERIAL` — серийный ключ Unity.
- `UNITY_EMAIL` — email аккаунта Unity.
- `UNITY_PASSWORD` — пароль аккаунта Unity.

### Опционально — Подпись Release APK (только для `build_type = release`)
Если эти секреты не заданы, Unity соберёт установочный APK с debug-подписью (подходит для тестирования на Android).
- `ANDROID_KEYSTORE_BASE64` — ваш `.keystore` файл, закодированный в Base64 (`base64 -w 0 user.keystore`).
- `ANDROID_KEYSTORE_PASS` — пароль хранилища ключей.
- `ANDROID_KEYALIAS_NAME` — имя алиаса ключа.
- `ANDROID_KEYALIAS_PASS` — пароль алиаса ключа.

## 3. Первый коммит и запуск

```bash
git init
git branch -M main
git add .
git commit -m "Stage 1-9: Initialize Solara City Unity 6 URP Android project and CI pipeline"
git remote add origin https://github.com/<ваш-аккаунт>/solara-city.git
git push -u origin main
```
