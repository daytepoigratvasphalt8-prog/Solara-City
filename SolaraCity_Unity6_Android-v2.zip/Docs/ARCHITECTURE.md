# Архитектура проекта Solara City

## 1. Структура каталогов

```text
Assets/
├── Scripts/
│   ├── Core/          # GameManager, EventBus, MaterialFactory, WorldBootstrap
│   ├── Player/        # PlayerController, PlayerInputHandler, PlayerStats, PlayerInteractor, ThirdPersonCamera
│   ├── Vehicles/      # VehicleController, VehicleCatalog, VehicleData, VehicleSpawner, VehicleCameraProfile
│   ├── World/         # DistrictBuilder, DayNightCycle, DealershipZone, FuelStationZone, PropertyZone, IInteractable
│   ├── Missions/      # MissionManager, MissionDefinition, WaypointBeacon
│   ├── Economy/       # EconomyManager
│   ├── SaveSystem/    # SaveManager, SaveData
│   ├── UI/            # RuntimeUIFactory, MobileHUDController, VirtualJoystick, TouchCameraPad, MinimapController, SafeAreaFitter
│   ├── Optimization/  # MobileQualityController
│   └── Editor/        # SolaraProjectSetup, AndroidBuildPipeline
├── Scenes/            # SolaraCity_District01.unity (генерируется Editor-инструментом и CI)
├── Prefabs/           # Под заменяемые префабы зданий, машин и персонажа
├── Materials/         # URP-материалы
├── Models/            # Импортируемые FBX/GLTF модели
├── Textures/          # Текстуры (ASTC сжатие для Android)
├── Animations/        # Animator Controllers и клипы
├── Audio/             # Звуки двигателей, города, UI
├── UI/                # Спрайты и иконки интерфейса
└── Settings/          # URP Mobile Render Pipeline Asset
```

## 2. Принятые технические решения

1. **Слабая связанность через `EventBus`:** UI, экономика, миссии и игрок общаются через типизированные события (`MoneyChangedEvent`, `GameStateChangedEvent`, `MissionUpdatedEvent`, `InteractablePromptEvent`), что исключает монолитные классы и циклические зависимости.
2. **Универсальный ввод (`PlayerInputHandler`):** одновременно поддерживает сенсорное управление Android, Unity Input System и Legacy Input Manager (через директивы компиляции `#if ENABLE_INPUT_SYSTEM`), упрощая отладку и на ПК, и на смартфоне.
3. **Устойчивая физика транспорта:** используется `WheelCollider` с пониженным центром масс (`y = -0.45`), стабилизатором поперечной устойчивости (`ApplyAntiRoll`) и ограничением угла поворота на высокой скорости для комфортного сенсорного управления.
4. **Мобильная URP-оптимизация:** отключён HDR (экономия пропускной способности памяти мобильных GPU), используется 1 основной источник света (`Directional Light`) для цикла дня и ночи, 2 каскада теней, динамический `renderScale` (0.75–1.0) и статическая разметка зданий для батчинга.
5. **Воспроизводимая генерация сцены (`SolaraProjectSetup` + `WorldBootstrap`):** исключает конфликты YAML при импорте в Unity 6 и позволяет GitHub Actions собрать рабочий APK с первого запуска без ручной сборки сцены.
6. **Заменяемость контента:** временные геометрические блоки района и персонажа изолированы в `DistrictBuilder` и `PlayerFactory`. Замена на финальные 3D-модели и Humanoid-анимации не затрагивает игровую логику.
