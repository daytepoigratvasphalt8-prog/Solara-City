# План перехода к качественным 3D-ассетам (Android / Unity 6 URP)

## 1. Игровой персонаж с Humanoid Rig

- **Формат:** `.fbx` или `.glb` (масштаб 1 unit = 1 метр, рост 1.78–1.82 м, пивот строго между стопами в `Y = 0`, взгляд по оси `+Z`).
- **Полигонаж (Android бюджет):**
  - `LOD0`: 8 000 – 14 000 треугольников (1–2 SkinnedMeshRenderer, до 2 материалов: тело/одежда + голова/волосы).
  - `LOD1`: 4 000 – 6 000 треугольников (дистанция > 20 м).
- **Кости:** стандартный Unity Humanoid (максимум 4 кости на вершину — `Skin Weights = 4 Bones` в Quality Settings, 45–65 костей).
- **Интеграция в проект:**
  1. Поместить FBX в `Assets/Models/Characters/` — `MobileAssetImportProcessor` автоматически включит `Humanoid Avatar`.
  2. Создать префаб в `Assets/Prefabs/Characters/` и перетащить его в поле `PlayerHumanoidPrefab` в `Assets/Resources/SolaraVisualCatalog.asset`.

## 2. Анимации (ходьба, бег, прыжок, посадка в автомобиль)

- **Контроллер:** уже сгенерирован шаблон `Assets/Animations/SolaraHumanoid_Template.controller` (`Solara City → 2. Generate Humanoid Animator Controller Template`).
- **Необходимые клипы (Humanoid, Root Motion выключен для ходьбы/бега, управление скоростью через `CharacterController`):**
  1. `Idle` (loop)
  2. `Walk` (loop, скорость ~1.6 м/с, синхронизируется с `walkSpeed`)
  3. `Run` / `Sprint` (loop, скорость ~4.2 м/с)
  4. `Jump` (одиночный клип + фаза падения)
  5. `EnterVehicle` (открытие двери и посадка — 0.8–1.1 с)
  6. `DrivingSeated` (loop, руки на руле)
  7. `ExitVehicle` (выход из авто — 0.7–1.0 с)
- **Скриптовая поддержка:** `CharacterAnimationBridge` уже передаёт параметры `Speed`, `IsSprinting`, `IsGrounded`, `VerticalVelocity`, `Jump`, `EnterVehicle`, `ExitVehicle`, `IsSeated`.

## 3. Детализированные автомобили с полноценной геометрией

- **Иерархия FBX (4 модели: `solara_compact`, `veridian_sedan`, `titan_suv`, `apex_gt`):**
  - `Body_LOD0 / LOD1 / LOD2` (кузов, салон с упрощённым интерьером, стёкла отдельным прозрачным материалом)
  - `Wheel_FL`, `Wheel_FR`, `Wheel_RL`, `Wheel_RR` — **отдельные меши** с пивотом строго в геометрическом центре колеса (радиус ~0.36 м).
  - `Headlights`, `BrakeLights` — отдельные меши/подматериалы для динамического включения стоп-сигналов.
- **Бюджет на 1 автомобиль:** `LOD0`: 12 000 – 20 000 tris; `LOD1`: 5 000 – 8 000 tris; `LOD2`: 1 500 – 2 500 tris; 2–3 материала (Paint Metallic, Trim/Interior Atlas, Glass).
- **Интеграция:** повесить `VehicleVisualBinding` на префаб авто, указать 4 колеса, `DriverSeatAnchor`, `DoorEntryPoint`, `BrakeLightRenderers` и зарегистрировать префаб в `SolaraVisualCatalog → VehicleOverrides`.

## 4. Качественные здания, дороги, тротуары и окружение

- **Модульный подход (Modular Kit + Trim Sheets):** вместо уникальных 4K-текстур на каждое здание использовать 2–3 общих Trim Sheet (фасады небоскрёбов, штукатурка/кирпич/окна жилых домов, металл/бетон промзоны). Это позволяет URP SRP Batcher рисовать целые кварталы за минимальное число Draw Calls.
- **Дорожная сеть:** модульные сегменты `Road_Straight_20m`, `Road_Intersection_4Way`, `Road_Corner`, `Sidewalk_Curb` с плавными стыками UV и декалями износа/люков.
- **Окружение:** деревья с `LOD0` (800–1200 tris, Alpha Clip листва) и `LOD1` (Cross-Card Billboard ~20 tris), уличные фонари (300–500 tris), скамейки, дорожные знаки и мусорные баки в общем атласе 1024×1024.
- **Подключение:** заполнить поля в `SolaraVisualCatalog → Environment`.

## 5. Улучшенные материалы, освещение и отражения для Android

- **Шейдеры:** строго `Universal Render Pipeline/Lit` (или `Simple Lit` для дальних фоновых объектов). Избегать тяжёлых прозрачных наложений (overdraw).
- **Освещение:**
  - 1 реальный `Directional Light` (солнце/луна) с 2 каскадами теней, дистанция теней 35–65 м.
  - `Ambient Mode: Trilight` (небо / горизонт / земля) для объёмности теневых сторон зданий.
  - Ночной город: подсветка окон через `_EmissionMap` (нулевой расход на источники света) вместо десятков реальных Point Lights.
- **Отражения:** один `ReflectionProbe` (`128×128`, `HDR = false`, `ViaScripting`, `IndividualFaces` Time Slicing — уже реализован в `EnvironmentReflectionRig`), обновляемый только при смене фазы дня.

## 6. Оптимизация моделей и текстур под мобильные GPU (Adreno / Mali)

| Метрика | Целевой лимит (Средний Android, 60 FPS) | Инструмент контроля в проекте |
| :--- | :--- | :--- |
| **Треугольники в кадре** | ≤ 180 000 – 250 000 tris | `LODGroup` + Frustum/Occlusion Culling |
| **Draw Calls (Batches)** | ≤ 120 – 160 | URP SRP Batcher + Static Batching + Trim Sheets |
| **Текстуры сжатие** | `ASTC 6x6` (Albedo/Mask), `ASTC 5x5` (Normal) | Автоматически через `MobileAssetImportProcessor` |
| **Разрешение текстур** | Props ≤ 512px, Auto/Hero ≤ 1024px, Trim ≤ 2048px | Автоматически через `MobileAssetImportProcessor` |
| **Текстурная память (VRAM)** | ≤ 250 – 350 MB | `Mipmap Streaming = ON`, `Read/Write = OFF` |
| **Render Scale (URP)** | 0.75 (Low) / 0.90 (Med) / 1.00 (High) | `MobileQualityController` |
