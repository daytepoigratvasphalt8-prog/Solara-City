using UnityEngine;

namespace SolaraCity.Player
{
    /// <summary>
    /// Smooth procedural limb animation for the placeholder humanoid rig.
    /// Can be swapped cleanly with an Animator + Humanoid Avatar when final character art is imported.
    /// </summary>
    public class ProceduralCharacterAnimator : MonoBehaviour
    {
        public Transform LeftLeg;
        public Transform RightLeg;
        public Transform LeftArm;
        public Transform RightArm;
        public Transform Torso;

        private float _cycle;

        public void UpdateAnimation(float normalizedSpeed, bool isSprinting, bool isGrounded)
        {
            if (LeftLeg == null || RightLeg == null || LeftArm == null || RightArm == null)
                return;

            if (!isGrounded)
            {
                LeftLeg.localRotation = Quaternion.Lerp(LeftLeg.localRotation, Quaternion.Euler(22f, 0f, 0f), Time.deltaTime * 10f);
                RightLeg.localRotation = Quaternion.Lerp(RightLeg.localRotation, Quaternion.Euler(-18f, 0f, 0f), Time.deltaTime * 10f);
                LeftArm.localRotation = Quaternion.Lerp(LeftArm.localRotation, Quaternion.Euler(-35f, 0f, 15f), Time.deltaTime * 10f);
                RightArm.localRotation = Quaternion.Lerp(RightArm.localRotation, Quaternion.Euler(-35f, 0f, -15f), Time.deltaTime * 10f);
                return;
            }

            if (normalizedSpeed > 0.05f)
            {
                float freq = isSprinting ? 12.5f : 8.0f;
                float swing = isSprinting ? 48f : 30f;
                _cycle += Time.deltaTime * freq * Mathf.Clamp(normalizedSpeed, 0.4f, 1.2f);
                float angle = Mathf.Sin(_cycle) * swing;

                LeftLeg.localRotation = Quaternion.Euler(angle, 0f, 0f);
                RightLeg.localRotation = Quaternion.Euler(-angle, 0f, 0f);
                LeftArm.localRotation = Quaternion.Euler(-angle * 0.85f, 0f, 4f);
                RightArm.localRotation = Quaternion.Euler(angle * 0.85f, 0f, -4f);

                if (Torso != null)
                {
                    float bob = Mathf.Abs(Mathf.Cos(_cycle)) * (isSprinting ? 0.05f : 0.025f);
                    Torso.localPosition = new Vector3(0f, 1.05f + bob, 0f);
                }
            }
            else
            {
                LeftLeg.localRotation = Quaternion.Lerp(LeftLeg.localRotation, Quaternion.identity, Time.deltaTime * 10f);
                RightLeg.localRotation = Quaternion.Lerp(RightLeg.localRotation, Quaternion.identity, Time.deltaTime * 10f);
                LeftArm.localRotation = Quaternion.Lerp(LeftArm.localRotation, Quaternion.Euler(0f, 0f, 4f), Time.deltaTime * 10f);
                RightArm.localRotation = Quaternion.Lerp(RightArm.localRotation, Quaternion.Euler(0f, 0f, -4f), Time.deltaTime * 10f);
                if (Torso != null)
                    Torso.localPosition = Vector3.Lerp(Torso.localPosition, new Vector3(0f, 1.05f, 0f), Time.deltaTime * 10f);
            }
        }
    }
}
