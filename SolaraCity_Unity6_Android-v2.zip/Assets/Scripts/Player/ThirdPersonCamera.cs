using UnityEngine;
using SolaraCity.Core;
using SolaraCity.Vehicles;

namespace SolaraCity.Player
{
    public class ThirdPersonCamera : MonoBehaviour
    {
        [Header("On-Foot Camera")]
        [SerializeField] private float footDistance = 4.6f;
        [SerializeField] private float footHeight = 0.6f;

        [Header("Look Settings")]
        [SerializeField] private float sensitivity = 0.28f;
        [SerializeField] private float minPitch = -18f;
        [SerializeField] private float maxPitch = 62f;
        [SerializeField] private float positionSmoothTime = 0.08f;
        [SerializeField] private float collisionRadius = 0.25f;

        private Transform _target;
        private bool _isVehicleMode;
        private VehicleCameraProfile _vehicleProfile;

        private float _yaw;
        private float _pitch = 16f;
        private Vector3 _smoothVel;

        public float Sensitivity
        {
            get => sensitivity;
            set => sensitivity = Mathf.Clamp(value, 0.08f, 1.0f);
        }

        public void SetPlayerTarget(Transform pivot)
        {
            _target = pivot;
            _isVehicleMode = false;
            _vehicleProfile = null;
        }

        public void SetVehicleTarget(Transform vehicleRoot, VehicleCameraProfile profile)
        {
            _target = vehicleRoot;
            _isVehicleMode = true;
            _vehicleProfile = profile;
            _yaw = vehicleRoot.eulerAngles.y;
            _pitch = 14f;
        }

        private void LateUpdate()
        {
            if (_target == null || GameManager.Instance == null) return;
            var state = GameManager.Instance.CurrentState;
            if (state != GameState.PlayingOnFoot && state != GameState.PlayingInVehicle)
                return;

            var input = GameManager.Instance.Player != null ? GameManager.Instance.Player.InputHandler : null;
            if (input != null && input.LookDelta.sqrMagnitude > 0.0001f)
            {
                _yaw += input.LookDelta.x * sensitivity;
                _pitch = Mathf.Clamp(_pitch - input.LookDelta.y * sensitivity, minPitch, maxPitch);
            }
            else if (_isVehicleMode && GameManager.Instance.ActiveVehicle != null)
            {
                // Gently align camera behind moving vehicle when user isn't manually orbiting
                if (GameManager.Instance.ActiveVehicle.SpeedKmh > 6f)
                {
                    float targetYaw = _target.eulerAngles.y;
                    _yaw = Mathf.LerpAngle(_yaw, targetYaw, Time.deltaTime * 2.4f);
                }
            }

            float dist = _isVehicleMode && _vehicleProfile != null ? _vehicleProfile.Distance : footDistance;
            float height = _isVehicleMode && _vehicleProfile != null ? _vehicleProfile.Height : footHeight;
            float lookAhead = _isVehicleMode && _vehicleProfile != null ? _vehicleProfile.LookHeight : 0.35f;

            Vector3 focusPoint = _target.position + Vector3.up * height;
            Quaternion rotation = Quaternion.Euler(_pitch, _yaw, 0f);
            Vector3 desiredOffset = rotation * new Vector3(0f, 0f, -dist);
            Vector3 desiredPos = focusPoint + desiredOffset;

            // Avoid clipping into buildings or terrain
            if (Physics.SphereCast(focusPoint, collisionRadius, desiredOffset.normalized, out RaycastHit hit, dist, ~0, QueryTriggerInteraction.Ignore))
            {
                if (!hit.collider.transform.IsChildOf(_target))
                {
                    desiredPos = focusPoint + desiredOffset.normalized * Mathf.Max(0.8f, hit.distance - 0.15f);
                }
            }

            transform.position = Vector3.SmoothDamp(transform.position, desiredPos, ref _smoothVel, positionSmoothTime);
            transform.LookAt(focusPoint + Vector3.up * lookAhead);
        }
    }
}
