using UnityEngine;
using SolaraCity.Core;

namespace SolaraCity.Player
{
    [RequireComponent(typeof(CharacterController))]
    public class PlayerController : MonoBehaviour
    {
        [Header("Movement")]
        [SerializeField] private float walkSpeed = 4.8f;
        [SerializeField] private float sprintSpeed = 8.4f;
        [SerializeField] private float rotationSpeed = 12f;
        [SerializeField] private float jumpHeight = 1.35f;
        [SerializeField] private float gravity = -22f;

        public Transform CameraPivot;
        public GameObject VisualRoot;

        public PlayerInputHandler InputHandler { get; private set; }
        public PlayerStats Stats { get; private set; }
        public PlayerInteractor Interactor { get; private set; }
        public CharacterAnimationBridge AnimationBridge { get; private set; }

        private CharacterController _cc;
        private Vector3 _velocity;
        private bool _inVehicle;

        private void Awake()
        {
            _cc = GetComponent<CharacterController>();
            InputHandler = GetComponent<PlayerInputHandler>() ?? gameObject.AddComponent<PlayerInputHandler>();
            Stats = GetComponent<PlayerStats>() ?? gameObject.AddComponent<PlayerStats>();
            Interactor = GetComponent<PlayerInteractor>() ?? gameObject.AddComponent<PlayerInteractor>();
            AnimationBridge = GetComponent<CharacterAnimationBridge>() ?? gameObject.AddComponent<CharacterAnimationBridge>();
        }

        private void Update()
        {
            if (GameManager.Instance == null) return;

            if (InputHandler.InteractPressed)
                Interactor.TryInteract();

            if (_inVehicle || GameManager.Instance.CurrentState != GameState.PlayingOnFoot)
                return;

            HandleMovement();
        }

        private void HandleMovement()
        {
            bool grounded = _cc.isGrounded;
            if (grounded && _velocity.y < 0f)
                _velocity.y = -2.5f;

            Vector2 moveInput = InputHandler.MoveInput;
            Vector3 moveDir = Vector3.zero;

            if (moveInput.sqrMagnitude > 0.01f)
            {
                Transform camTransform = Camera.main != null ? Camera.main.transform : transform;
                Vector3 camForward = camTransform.forward;
                camForward.y = 0f;
                camForward.Normalize();

                Vector3 camRight = camTransform.right;
                camRight.y = 0f;
                camRight.Normalize();

                moveDir = (camForward * moveInput.y + camRight * moveInput.x).normalized;
                Quaternion targetRot = Quaternion.LookRotation(moveDir);
                transform.rotation = Quaternion.Slerp(transform.rotation, targetRot, rotationSpeed * Time.deltaTime);
            }

            float targetSpeed = InputHandler.IsSprinting ? sprintSpeed : walkSpeed;
            Vector3 horizontalMove = moveDir * (targetSpeed * moveInput.magnitude);

            if (grounded && InputHandler.JumpPressed)
            {
                _velocity.y = Mathf.Sqrt(jumpHeight * -2f * gravity);
                AnimationBridge?.TriggerJump();
            }

            _velocity.y += gravity * Time.deltaTime;
            _cc.Move((horizontalMove + _velocity) * Time.deltaTime);

            AnimationBridge?.UpdateLocomotion(moveInput.magnitude, InputHandler.IsSprinting, grounded, _velocity.y);
        }

        public void TeleportTo(Vector3 worldPosition)
        {
            if (_cc != null) _cc.enabled = false;
            transform.position = worldPosition;
            _velocity = Vector3.zero;
            if (_cc != null && !_inVehicle) _cc.enabled = true;
        }

        public void SetInVehicleState(bool inVehicle, Transform vehicleTransform, Transform seatAnchor = null)
        {
            _inVehicle = inVehicle;
            if (_cc != null) _cc.enabled = !inVehicle;

            bool keepVisibleSeated = inVehicle && seatAnchor != null && AnimationBridge != null && AnimationBridge.HasHumanoidAnimator;
            if (VisualRoot != null)
                VisualRoot.SetActive(!inVehicle || keepVisibleSeated);

            if (inVehicle && vehicleTransform != null)
            {
                Transform parent = seatAnchor != null ? seatAnchor : vehicleTransform;
                transform.SetParent(parent, false);
                transform.localPosition = Vector3.zero;
                transform.localRotation = Quaternion.identity;
            }
            else
            {
                transform.SetParent(null);
            }

            AnimationBridge?.SetVehicleSeated(inVehicle);
        }
    }
}
