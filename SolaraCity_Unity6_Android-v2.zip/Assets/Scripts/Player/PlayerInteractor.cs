using UnityEngine;
using SolaraCity.Core;
using SolaraCity.World;

namespace SolaraCity.Player
{
    public class PlayerInteractor : MonoBehaviour
    {
        [SerializeField] private float interactRadius = 3.2f;
        private IInteractable _currentTarget;
        private readonly Collider[] _overlapBuffer = new Collider[24];
        private string _lastPrompt = "";

        public IInteractable CurrentTarget => _currentTarget;

        private void Update()
        {
            if (GameManager.Instance == null || GameManager.Instance.CurrentState != GameState.PlayingOnFoot)
            {
                if (!string.IsNullOrEmpty(_lastPrompt))
                {
                    _lastPrompt = "";
                    _currentTarget = null;
                    EventBus.Publish(new InteractablePromptEvent(false));
                }
                return;
            }

            FindClosestInteractable();
        }

        private void FindClosestInteractable()
        {
            int count = Physics.OverlapSphereNonAlloc(transform.position + Vector3.up * 0.9f, interactRadius, _overlapBuffer);
            IInteractable best = null;
            float bestDistSq = float.MaxValue;

            for (int i = 0; i < count; i++)
            {
                var col = _overlapBuffer[i];
                if (col == null) continue;
                var interactable = col.GetComponentInParent<IInteractable>();
                if (interactable == null || !interactable.CanInteract) continue;

                float distSq = (col.transform.position - transform.position).sqrMagnitude;
                if (distSq < bestDistSq)
                {
                    bestDistSq = distSq;
                    best = interactable;
                }
            }

            _currentTarget = best;
            string prompt = _currentTarget != null ? _currentTarget.InteractionPrompt : "";

            if (prompt != _lastPrompt)
            {
                _lastPrompt = prompt;
                EventBus.Publish(new InteractablePromptEvent(_currentTarget != null, prompt));
            }
        }

        public void TryInteract()
        {
            if (GameManager.Instance == null) return;

            if (GameManager.Instance.CurrentState == GameState.PlayingInVehicle)
            {
                GameManager.Instance.ExitCurrentVehicle();
                return;
            }

            if (GameManager.Instance.CurrentState == GameState.PlayingOnFoot && _currentTarget != null)
            {
                _currentTarget.Interact(gameObject);
            }
        }
    }
}
