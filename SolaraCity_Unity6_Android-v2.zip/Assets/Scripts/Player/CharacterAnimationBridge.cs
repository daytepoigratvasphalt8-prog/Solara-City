using System.Collections.Generic;
using UnityEngine;

namespace SolaraCity.Player
{
    /// <summary>
    /// Unified animation driver supporting production Humanoid Animator Controllers
    /// (Walk, Run, Jump, EnterVehicle, DrivingSeated, ExitVehicle) with safe fallback
    /// to ProceduralCharacterAnimator when only temporary geometry is present.
    /// </summary>
    public class CharacterAnimationBridge : MonoBehaviour
    {
        private static readonly int SpeedHash = Animator.StringToHash("Speed");
        private static readonly int IsSprintingHash = Animator.StringToHash("IsSprinting");
        private static readonly int IsGroundedHash = Animator.StringToHash("IsGrounded");
        private static readonly int VerticalVelHash = Animator.StringToHash("VerticalVelocity");
        private static readonly int JumpHash = Animator.StringToHash("Jump");
        private static readonly int EnterVehicleHash = Animator.StringToHash("EnterVehicle");
        private static readonly int ExitVehicleHash = Animator.StringToHash("ExitVehicle");
        private static readonly int IsSeatedHash = Animator.StringToHash("IsSeated");

        private Animator _animator;
        private ProceduralCharacterAnimator _procedural;
        private readonly HashSet<int> _availableParams = new HashSet<int>();

        public bool HasHumanoidAnimator => _animator != null && _animator.runtimeAnimatorController != null;

        public void BindHumanoidAnimator(Animator animator, RuntimeAnimatorController overrideController = null)
        {
            _animator = animator;
            if (_animator != null && overrideController != null)
                _animator.runtimeAnimatorController = overrideController;

            CacheAnimatorParameters();
        }

        public void BindProceduralFallback(ProceduralCharacterAnimator procedural)
        {
            _procedural = procedural;
        }

        private void CacheAnimatorParameters()
        {
            _availableParams.Clear();
            if (_animator == null || _animator.runtimeAnimatorController == null) return;

            foreach (var p in _animator.parameters)
                _availableParams.Add(p.nameHash);
        }

        public void UpdateLocomotion(float normalizedSpeed, bool isSprinting, bool isGrounded, float verticalVelocity)
        {
            if (HasHumanoidAnimator)
            {
                float animSpeed = normalizedSpeed * (isSprinting ? 2.0f : 1.0f);
                if (_availableParams.Contains(SpeedHash))
                    _animator.SetFloat(SpeedHash, animSpeed, 0.08f, Time.deltaTime);
                if (_availableParams.Contains(IsSprintingHash))
                    _animator.SetBool(IsSprintingHash, isSprinting);
                if (_availableParams.Contains(IsGroundedHash))
                    _animator.SetBool(IsGroundedHash, isGrounded);
                if (_availableParams.Contains(VerticalVelHash))
                    _animator.SetFloat(VerticalVelHash, verticalVelocity);
            }
            else if (_procedural != null)
            {
                _procedural.UpdateAnimation(normalizedSpeed, isSprinting, isGrounded);
            }
        }

        public void TriggerJump()
        {
            if (HasHumanoidAnimator && _availableParams.Contains(JumpHash))
                _animator.SetTrigger(JumpHash);
        }

        public void SetVehicleSeated(bool seated)
        {
            if (!HasHumanoidAnimator) return;

            if (_availableParams.Contains(IsSeatedHash))
                _animator.SetBool(IsSeatedHash, seated);

            if (seated && _availableParams.Contains(EnterVehicleHash))
                _animator.SetTrigger(EnterVehicleHash);
            else if (!seated && _availableParams.Contains(ExitVehicleHash))
                _animator.SetTrigger(ExitVehicleHash);
        }
    }
}
