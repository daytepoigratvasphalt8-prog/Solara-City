using UnityEngine;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
#endif

namespace SolaraCity.Player
{
    /// <summary>
    /// Unified input layer combining mobile touch controls with desktop testing controls.
    /// Compatible with both Unity Input System and Legacy Input Manager.
    /// </summary>
    public class PlayerInputHandler : MonoBehaviour
    {
        public Vector2 MoveInput { get; private set; }
        public Vector2 LookDelta { get; private set; }
        public bool IsSprinting { get; private set; }
        public bool JumpPressed { get; private set; }
        public bool InteractPressed { get; private set; }

        // Vehicle touch channels
        public float VehicleThrottle { get; private set; }
        public float VehicleBrake { get; private set; }
        public float VehicleSteer { get; private set; }

        private Vector2 _mobileMove;
        private Vector2 _mobileLook;
        private bool _mobileSprint;
        private bool _mobileJumpQueued;
        private bool _mobileInteractQueued;

        private float _touchThrottle;
        private float _touchBrake;
        private float _touchSteerLeft;
        private float _touchSteerRight;

        public void SetMobileMove(Vector2 dir) => _mobileMove = Vector2.ClampMagnitude(dir, 1f);
        public void AddMobileLook(Vector2 delta) => _mobileLook += delta;
        public void SetMobileSprint(bool active) => _mobileSprint = active;
        public void TriggerMobileJump() => _mobileJumpQueued = true;
        public void TriggerMobileInteract() => _mobileInteractQueued = true;

        public void SetTouchGas(bool pressed) => _touchThrottle = pressed ? 1f : 0f;
        public void SetTouchBrake(bool pressed) => _touchBrake = pressed ? 1f : 0f;
        public void SetTouchSteerLeft(bool pressed) => _touchSteerLeft = pressed ? -1f : 0f;
        public void SetTouchSteerRight(bool pressed) => _touchSteerRight = pressed ? 1f : 0f;

        private void Update()
        {
            Vector2 kbMove = Vector2.zero;
            Vector2 mouseLook = Vector2.zero;
            bool kbSprint = false;
            bool kbJump = false;
            bool kbInteract = false;
            float kbThrottle = 0f;
            float kbBrake = 0f;
            float kbSteer = 0f;

#if ENABLE_INPUT_SYSTEM
            var kb = Keyboard.current;
            if (kb != null)
            {
                if (kb.wKey.isPressed || kb.upArrowKey.isPressed) kbMove.y += 1f;
                if (kb.sKey.isPressed || kb.downArrowKey.isPressed) kbMove.y -= 1f;
                if (kb.dKey.isPressed || kb.rightArrowKey.isPressed) kbMove.x += 1f;
                if (kb.aKey.isPressed || kb.leftArrowKey.isPressed) kbMove.x -= 1f;
                kbSprint = kb.leftShiftKey.isPressed;
                kbJump = kb.spaceKey.wasPressedThisFrame;
                kbInteract = kb.fKey.wasPressedThisFrame || kb.eKey.wasPressedThisFrame;

                kbThrottle = kb.wKey.isPressed || kb.upArrowKey.isPressed ? 1f : 0f;
                kbBrake = kb.sKey.isPressed || kb.downArrowKey.isPressed ? 1f : 0f;
                if (kb.aKey.isPressed || kb.leftArrowKey.isPressed) kbSteer -= 1f;
                if (kb.dKey.isPressed || kb.rightArrowKey.isPressed) kbSteer += 1f;
            }
            var mouse = Mouse.current;
            if (mouse != null && mouse.rightButton.isPressed)
            {
                mouseLook = mouse.delta.ReadValue() * 0.15f;
            }
#elif ENABLE_LEGACY_INPUT_MANAGER
            kbMove = new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical"));
            kbSprint = Input.GetKey(KeyCode.LeftShift);
            kbJump = Input.GetKeyDown(KeyCode.Space);
            kbInteract = Input.GetKeyDown(KeyCode.F) || Input.GetKeyDown(KeyCode.E);
            kbThrottle = kbMove.y > 0f ? kbMove.y : 0f;
            kbBrake = kbMove.y < 0f ? -kbMove.y : 0f;
            kbSteer = kbMove.x;
            if (Input.GetMouseButton(1))
                mouseLook = new Vector2(Input.GetAxis("Mouse X"), Input.GetAxis("Mouse Y")) * 2.5f;
#endif

            MoveInput = _mobileMove.sqrMagnitude > 0.001f
                ? _mobileMove
                : Vector2.ClampMagnitude(kbMove, 1f);

            LookDelta = _mobileLook + mouseLook;
            _mobileLook = Vector2.zero;

            IsSprinting = _mobileSprint || kbSprint;
            JumpPressed = _mobileJumpQueued || kbJump;
            InteractPressed = _mobileInteractQueued || kbInteract;

            _mobileJumpQueued = false;
            _mobileInteractQueued = false;

            VehicleThrottle = Mathf.Max(_touchThrottle, kbThrottle);
            VehicleBrake = Mathf.Max(_touchBrake, kbBrake);
            float touchSteer = _touchSteerLeft + _touchSteerRight;
            VehicleSteer = Mathf.Abs(touchSteer) > 0.01f ? touchSteer : kbSteer;
        }
    }
}
