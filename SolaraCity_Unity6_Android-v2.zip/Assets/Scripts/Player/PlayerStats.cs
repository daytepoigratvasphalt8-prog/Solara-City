using UnityEngine;
using SolaraCity.Core;

namespace SolaraCity.Player
{
    public class PlayerStats : MonoBehaviour
    {
        [SerializeField] private float maxHealth = 100f;
        public float MaxHealth => maxHealth;
        public float CurrentHealth { get; private set; } = 100f;

        private void Start()
        {
            CurrentHealth = maxHealth;
            PublishHealth();
        }

        public void SetHealth(float value)
        {
            CurrentHealth = Mathf.Clamp(value, 0f, maxHealth);
            PublishHealth();
        }

        public void TakeDamage(float amount)
        {
            if (amount <= 0f) return;
            CurrentHealth = Mathf.Max(0f, CurrentHealth - amount);
            PublishHealth();

            if (CurrentHealth <= 0f)
            {
                RespawnAtHospital();
            }
        }

        public void Heal(float amount)
        {
            if (amount <= 0f) return;
            CurrentHealth = Mathf.Min(maxHealth, CurrentHealth + amount);
            PublishHealth();
        }

        public void ResetStats()
        {
            CurrentHealth = maxHealth;
            PublishHealth();
        }

        private void RespawnAtHospital()
        {
            CurrentHealth = maxHealth;
            PublishHealth();
            var controller = GetComponent<PlayerController>();
            if (controller != null)
                controller.TeleportTo(new Vector3(0f, 1.2f, -12f));
            EventBus.Publish(new ToastNotificationEvent("Вы восстановлены в клинике Solara Bay"));
        }

        private void PublishHealth()
        {
            EventBus.Publish(new HealthChangedEvent(CurrentHealth, maxHealth));
        }
    }
}
