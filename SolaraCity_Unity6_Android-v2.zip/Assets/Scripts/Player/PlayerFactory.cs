using UnityEngine;
using SolaraCity.Core;

namespace SolaraCity.Player
{
    public static class PlayerFactory
    {
        public static PlayerController CreatePlayer(Vector3 spawnPos, VisualAssetCatalog catalog = null)
        {
            var root = new GameObject("Player");
            root.tag = "Player";
            root.transform.position = spawnPos;

            var cc = root.AddComponent<CharacterController>();
            cc.height = 1.85f;
            cc.radius = 0.35f;
            cc.center = new Vector3(0f, 0.925f, 0f);
            cc.slopeLimit = 45f;
            cc.stepOffset = 0.35f;

            var controller = root.AddComponent<PlayerController>();
            var animBridge = controller.AnimationBridge ?? root.AddComponent<CharacterAnimationBridge>();

            var pivot = new GameObject("CameraPivot").transform;
            pivot.SetParent(root.transform, false);
            pivot.localPosition = new Vector3(0f, 1.48f, 0f);
            controller.CameraPivot = pivot;

            // Production Humanoid Rig path when assigned in SolaraVisualCatalog
            if (catalog != null && catalog.PlayerHumanoidPrefab != null)
            {
                var visual = Object.Instantiate(catalog.PlayerHumanoidPrefab, root.transform);
                visual.name = "HumanoidVisual";
                visual.transform.localPosition = Vector3.zero;
                visual.transform.localRotation = Quaternion.identity;
                controller.VisualRoot = visual;

                var animator = visual.GetComponentInChildren<Animator>();
                if (animator == null)
                    animator = visual.AddComponent<Animator>();

                animBridge.BindHumanoidAnimator(animator, catalog.PlayerAnimatorController);
                return controller;
            }

            // Temporary placeholder humanoid rig (clearly isolated for future FBX replacement)
            BuildPlaceholderVisual(root, controller, animBridge);
            return controller;
        }

        private static void BuildPlaceholderVisual(GameObject root, PlayerController controller, CharacterAnimationBridge animBridge)
        {
            var anim = root.AddComponent<ProceduralCharacterAnimator>();
            var visual = new GameObject("PlaceholderVisual");
            visual.transform.SetParent(root.transform, false);
            controller.VisualRoot = visual;

            var jacketMat = MaterialFactory.CreateLit("Player_Jacket", new Color(0.14f, 0.22f, 0.36f), 0.35f);
            var pantsMat = MaterialFactory.CreateLit("Player_Pants", new Color(0.16f, 0.17f, 0.20f), 0.2f);
            var skinMat = MaterialFactory.CreateLit("Player_Skin", new Color(0.86f, 0.70f, 0.58f), 0.25f);
            var hairMat = MaterialFactory.CreateLit("Player_Hair", new Color(0.12f, 0.09f, 0.07f), 0.2f);
            var shoeMat = MaterialFactory.CreateLit("Player_Shoes", new Color(0.92f, 0.93f, 0.95f), 0.3f);

            var torso = CreateLimb("Torso", PrimitiveType.Cube, visual.transform, new Vector3(0f, 1.05f, 0f), new Vector3(0.46f, 0.62f, 0.25f), jacketMat);
            var head = CreateLimb("Head", PrimitiveType.Sphere, torso.transform, new Vector3(0f, 0.48f, 0f), new Vector3(0.32f, 0.34f, 0.32f), skinMat);
            CreateLimb("HairCap", PrimitiveType.Cube, head.transform, new Vector3(0f, 0.24f, -0.02f), new Vector3(0.95f, 0.45f, 0.95f), hairMat);

            var leftArmPivot = new GameObject("LeftArmPivot").transform;
            leftArmPivot.SetParent(torso.transform, false);
            leftArmPivot.localPosition = new Vector3(-0.31f, 0.22f, 0f);
            CreateLimb("LeftArmMesh", PrimitiveType.Cube, leftArmPivot, new Vector3(0f, -0.25f, 0f), new Vector3(0.14f, 0.56f, 0.14f), jacketMat);

            var rightArmPivot = new GameObject("RightArmPivot").transform;
            rightArmPivot.SetParent(torso.transform, false);
            rightArmPivot.localPosition = new Vector3(0.31f, 0.22f, 0f);
            CreateLimb("RightArmMesh", PrimitiveType.Cube, rightArmPivot, new Vector3(0f, -0.25f, 0f), new Vector3(0.14f, 0.56f, 0.14f), jacketMat);

            var leftLegPivot = new GameObject("LeftLegPivot").transform;
            leftLegPivot.SetParent(visual.transform, false);
            leftLegPivot.localPosition = new Vector3(-0.13f, 0.72f, 0f);
            CreateLimb("LeftLegMesh", PrimitiveType.Cube, leftLegPivot, new Vector3(0f, -0.34f, 0f), new Vector3(0.18f, 0.66f, 0.20f), pantsMat);
            CreateLimb("LeftShoe", PrimitiveType.Cube, leftLegPivot, new Vector3(0f, -0.68f, 0.04f), new Vector3(0.19f, 0.10f, 0.28f), shoeMat);

            var rightLegPivot = new GameObject("RightLegPivot").transform;
            rightLegPivot.SetParent(visual.transform, false);
            rightLegPivot.localPosition = new Vector3(0.13f, 0.72f, 0f);
            CreateLimb("RightLegMesh", PrimitiveType.Cube, rightLegPivot, new Vector3(0f, -0.34f, 0f), new Vector3(0.18f, 0.66f, 0.20f), pantsMat);
            CreateLimb("RightShoe", PrimitiveType.Cube, rightLegPivot, new Vector3(0f, -0.68f, 0.04f), new Vector3(0.19f, 0.10f, 0.28f), shoeMat);

            anim.Torso = torso.transform;
            anim.LeftArm = leftArmPivot;
            anim.RightArm = rightArmPivot;
            anim.LeftLeg = leftLegPivot;
            anim.RightLeg = rightLegPivot;

            animBridge.BindProceduralFallback(anim);
        }

        private static GameObject CreateLimb(string name, PrimitiveType type, Transform parent, Vector3 localPos, Vector3 localScale, Material mat)
        {
            var go = GameObject.CreatePrimitive(type);
            go.name = name;
            Object.Destroy(go.GetComponent<Collider>());
            go.transform.SetParent(parent, false);
            go.transform.localPosition = localPos;
            go.transform.localScale = localScale;
            go.GetComponent<Renderer>().sharedMaterial = mat;
            return go;
        }
    }
}
