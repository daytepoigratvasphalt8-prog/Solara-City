#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;

namespace SolaraCity.Editor
{
    /// <summary>
    /// Automatically enforces Android GPU optimization standards whenever new 3D models
    /// or textures are imported into Assets/Models/ or Assets/Textures/.
    /// </summary>
    public class MobileAssetImportProcessor : AssetPostprocessor
    {
        private void OnPreprocessModel()
        {
            if (!assetPath.StartsWith("Assets/Models/")) return;

            var importer = (ModelImporter)assetImporter;
            importer.importCameras = false;
            importer.importLights = false;
            importer.meshCompression = ModelImporterMeshCompression.Medium;
            importer.meshOptimizationFlags = MeshOptimizationFlags.Everything;
            importer.weldVertices = true;
            importer.isReadable = false;

            // Characters automatically receive Humanoid Avatar rig setup
            if (assetPath.Contains("/Characters/"))
            {
                importer.animationType = ModelImporterAnimationType.Human;
                importer.avatarSetup = ModelImporterAvatarSetup.CreateFromThisModel;
            }
            else if (assetPath.Contains("/Buildings/") || assetPath.Contains("/Props/"))
            {
                importer.animationType = ModelImporterAnimationType.None;
                importer.generateSecondaryUV = true; // Lightmap UVs for static city architecture
            }
        }

        private void OnPreprocessTexture()
        {
            if (!assetPath.StartsWith("Assets/Textures/")) return;

            var importer = (TextureImporter)assetImporter;
            importer.isReadable = false;
            importer.mipmapEnabled = true;
            importer.streamingMipmaps = true;

            bool isNormal = assetPath.ToLowerInvariant().Contains("normal") ||
                            assetPath.ToLowerInvariant().Contains("_nrm") ||
                            assetPath.ToLowerInvariant().EndsWith("_n.png");

            if (isNormal)
                importer.textureType = TextureImporterType.NormalMap;

            int maxSize = 1024;
            if (assetPath.Contains("/Props/")) maxSize = 512;
            else if (assetPath.Contains("/Buildings/")) maxSize = 2048;
            else if (assetPath.Contains("/Characters/") || assetPath.Contains("/Vehicles/")) maxSize = 1024;

            var androidSettings = new TextureImporterPlatformSettings
            {
                name = "Android",
                overridden = true,
                maxTextureSize = maxSize,
                format = isNormal ? TextureImporterFormat.ASTC_5x5 : TextureImporterFormat.ASTC_6x6,
                compressionQuality = 50
            };
            importer.SetPlatformTextureSettings(androidSettings);
        }
    }
}
#endif
