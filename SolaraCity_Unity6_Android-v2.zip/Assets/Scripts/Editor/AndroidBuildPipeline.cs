#if UNITY_EDITOR
using System;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEngine;

namespace SolaraCity.Editor
{
    /// <summary>
    /// Headless Android APK build entry point invoked by GitHub Actions.
    /// Ensures project setup & scenes exist, applies optional CI signing, and validates BuildResult.
    /// </summary>
    public static class AndroidBuildPipeline
    {
        public static void BuildAndroidAPK()
        {
            Debug.Log("[AndroidBuildPipeline] Starting Android APK build...");

            // Guarantee URP, Android PlayerSettings, and Main Scene are initialized
            SolaraProjectSetup.SetupProjectHeadless();

            ConfigureOptionalKeystoreFromEnv();

            string outputDir = GetArg("-customBuildPath") ?? "build/Android";
            string fileName = GetArg("-customBuildName") ?? "SolaraCity-Android.apk";
            if (!fileName.EndsWith(".apk", StringComparison.OrdinalIgnoreCase))
                fileName += ".apk";

            Directory.CreateDirectory(outputDir);
            string fullOutputPath = Path.Combine(outputDir, fileName);

            string[] scenes = EditorBuildSettings.scenes
                .Where(s => s.enabled && File.Exists(s.path))
                .Select(s => s.path)
                .ToArray();

            if (scenes.Length == 0)
            {
                Debug.LogError("[AndroidBuildPipeline] No enabled scenes found in EditorBuildSettings.");
                EditorApplication.Exit(1);
                return;
            }

            EditorUserBuildSettings.buildAppBundle = false;
            EditorUserBuildSettings.SwitchActiveBuildTarget(BuildTargetGroup.Android, BuildTarget.Android);

            var options = new BuildPlayerOptions
            {
                scenes = scenes,
                locationPathName = fullOutputPath,
                target = BuildTarget.Android,
                options = BuildOptions.None
            };

            BuildReport report = BuildPipeline.BuildPlayer(options);
            BuildSummary summary = report.summary;

            Debug.Log($"[AndroidBuildPipeline] Result: {summary.result} | Size: {summary.totalSize / (1024f * 1024f):F2} MB | Duration: {summary.totalTime}");

            if (summary.result != BuildResult.Succeeded)
            {
                Debug.LogError($"[AndroidBuildPipeline] Build FAILED with {summary.totalErrors} errors.");
                EditorApplication.Exit(1);
            }
        }

        private static void ConfigureOptionalKeystoreFromEnv()
        {
            string keystorePath = Environment.GetEnvironmentVariable("ANDROID_KEYSTORE_PATH");
            string keystorePass = Environment.GetEnvironmentVariable("ANDROID_KEYSTORE_PASS");
            string keyaliasName = Environment.GetEnvironmentVariable("ANDROID_KEYALIAS_NAME");
            string keyaliasPass = Environment.GetEnvironmentVariable("ANDROID_KEYALIAS_PASS");

            if (!string.IsNullOrEmpty(keystorePath) && File.Exists(keystorePath) &&
                !string.IsNullOrEmpty(keystorePass) && !string.IsNullOrEmpty(keyaliasName))
            {
                PlayerSettings.Android.useCustomKeystore = true;
                PlayerSettings.Android.keystoreName = keystorePath;
                PlayerSettings.Android.keystorePass = keystorePass;
                PlayerSettings.Android.keyaliasName = keyaliasName;
                PlayerSettings.Android.keyaliasPass = keyaliasPass ?? keystorePass;
                Debug.Log("[AndroidBuildPipeline] Release keystore configured from environment variables.");
            }
            else
            {
                PlayerSettings.Android.useCustomKeystore = false;
                Debug.Log("[AndroidBuildPipeline] Building with Unity default debug keystore.");
            }
        }

        private static string GetArg(string name)
        {
            string[] args = Environment.GetCommandLineArgs();
            for (int i = 0; i < args.Length - 1; i++)
            {
                if (args[i] == name)
                    return args[i + 1];
            }
            return null;
        }
    }
}
#endif
