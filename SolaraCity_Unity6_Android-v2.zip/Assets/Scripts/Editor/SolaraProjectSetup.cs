#if UNITY_EDITOR
using System;
using System.IO;
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
using SolaraCity.Core;

namespace SolaraCity.Editor
{
    /// <summary>
    /// Automates Unity 6 URP + Android project configuration, VisualAssetCatalog creation,
    /// Humanoid Animator template creation, and District 01 scene setup.
    /// </summary>
    public static class SolaraProjectSetup
    {
        public const string MainScenePath = "Assets/Scenes/SolaraCity_District01.unity";
        private const string UrpAssetPath = "Assets/Settings/SolaraURP_Mobile.asset";
        private const string RendererAssetPath = "Assets/Settings/SolaraURP_Renderer.asset";
        private const string CatalogAssetPath = "Assets/Resources/SolaraVisualCatalog.asset";

        [MenuItem("Solara City/1. Configure Android + URP & Generate District Scene")]
        public static void SetupProjectInteractive()
        {
            SetupProjectHeadless();
            EditorUtility.DisplayDialog(
                "Solara City Setup Complete (v0.2.0)",
                "Настроены Android (URP, IL2CPP, ARM64), SolaraVisualCatalog, шаблон Humanoid Animator и сцена SolaraCity_District01.",
                "Отлично");
        }

        public static void SetupProjectHeadless()
        {
            EnsureDirectories();
            ConfigureAndroidPlayerSettings();
            ConfigureURPPipeline();
            EnsureVisualCatalogAndAnimator();
            CreateOrUpdateDistrictScene();
            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
            AssetAuditTool.GenerateReport();
            Debug.Log("[SolaraProjectSetup] Android + URP + VisualCatalog + SolaraCity_District01 configured successfully.");
        }

        private static void EnsureDirectories()
        {
            string[] folders =
            {
                "Assets/Scenes", "Assets/Settings", "Assets/Materials", "Assets/Prefabs",
                "Assets/Resources", "Assets/Animations",
                "Assets/Models/Characters", "Assets/Models/Vehicles", "Assets/Models/Buildings", "Assets/Models/Props",
                "Assets/Textures/Characters", "Assets/Textures/Vehicles", "Assets/Textures/Buildings", "Assets/Textures/Props"
            };
            foreach (var f in folders)
            {
                if (!Directory.Exists(f))
                    Directory.CreateDirectory(f);
            }
        }

        private static void ConfigureAndroidPlayerSettings()
        {
            PlayerSettings.companyName = "SolaraInteractive";
            PlayerSettings.productName = "Solara City";
            PlayerSettings.bundleVersion = "0.2.0";

            int buildNum = 2;
            string envBuild = Environment.GetEnvironmentVariable("BUILD_NUMBER");
            if (!string.IsNullOrEmpty(envBuild) && int.TryParse(envBuild, out int parsed) && parsed > 0)
                buildNum = parsed;
            PlayerSettings.Android.bundleVersionCode = buildNum;

            PlayerSettings.SetApplicationIdentifier(NamedBuildTarget.Android, "com.solarainteractive.solaracity");
            PlayerSettings.SetScriptingBackend(NamedBuildTarget.Android, ScriptingImplementation.IL2CPP);
            PlayerSettings.Android.targetArchitectures = AndroidArchitecture.ARM64;
            PlayerSettings.Android.minSdkVersion = AndroidSdkVersions.AndroidApiLevel24;
            PlayerSettings.Android.targetSdkVersion = AndroidSdkVersions.AndroidApiLevelAuto;

            PlayerSettings.defaultInterfaceOrientation = UIOrientation.AutoRotation;
            PlayerSettings.allowedAutorotateToLandscapeLeft = true;
            PlayerSettings.allowedAutorotateToLandscapeRight = true;
            PlayerSettings.allowedAutorotateToPortrait = false;
            PlayerSettings.allowedAutorotateToPortraitUpsideDown = false;

            PlayerSettings.SetUseDefaultGraphicsAPIs(BuildTarget.Android, false);
            PlayerSettings.SetGraphicsAPIs(BuildTarget.Android, new[]
            {
                GraphicsDeviceType.Vulkan,
                GraphicsDeviceType.OpenGLES3
            });
        }

        private static void ConfigureURPPipeline()
        {
            var urpAsset = AssetDatabase.LoadAssetAtPath<UniversalRenderPipelineAsset>(UrpAssetPath);
            if (urpAsset == null)
            {
                var rendererData = ScriptableObject.CreateInstance<UniversalRendererData>();
                AssetDatabase.CreateAsset(rendererData, RendererAssetPath);

                urpAsset = UniversalRenderPipelineAsset.Create(rendererData);
                urpAsset.renderScale = 0.9f;
                urpAsset.shadowDistance = 65f;
                urpAsset.shadowCascadeCount = 2;
                urpAsset.msaaSampleCount = 2;
                urpAsset.supportsHDR = false;

                AssetDatabase.CreateAsset(urpAsset, UrpAssetPath);
            }

            GraphicsSettings.defaultRenderPipeline = urpAsset;
            QualitySettings.renderPipeline = urpAsset;
        }

        private static void EnsureVisualCatalogAndAnimator()
        {
            var animCtrl = SolaraAnimatorTemplateGenerator.GenerateHeadless();

            var catalog = AssetDatabase.LoadAssetAtPath<VisualAssetCatalog>(CatalogAssetPath);
            if (catalog == null)
            {
                catalog = ScriptableObject.CreateInstance<VisualAssetCatalog>();
                catalog.PlayerAnimatorController = animCtrl;
                catalog.UseProceduralPBRTextures = true;
                catalog.EnableEnvironmentReflections = true;
                catalog.AttachAutomaticLODGroups = true;
                AssetDatabase.CreateAsset(catalog, CatalogAssetPath);
            }
        }

        private static void CreateOrUpdateDistrictScene()
        {
            var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

            var bootstrapObj = new GameObject("WorldBootstrap");
            bootstrapObj.AddComponent<WorldBootstrap>();

            EditorSceneManager.SaveScene(scene, MainScenePath);

            EditorBuildSettings.scenes = new[]
            {
                new EditorBuildSettingsScene(MainScenePath, true)
            };
        }
    }
}
#endif
