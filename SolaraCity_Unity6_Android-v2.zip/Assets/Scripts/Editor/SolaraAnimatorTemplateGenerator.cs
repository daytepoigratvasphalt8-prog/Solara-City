#if UNITY_EDITOR
using System.IO;
using UnityEditor;
using UnityEditor.Animations;
using UnityEngine;

namespace SolaraCity.Editor
{
    /// <summary>
    /// Generates a standardized Humanoid Animator Controller ready for Mixamo or custom
    /// Walk, Run, Jump, EnterVehicle, DrivingSeated, and ExitVehicle animation clips.
    /// </summary>
    public static class SolaraAnimatorTemplateGenerator
    {
        public const string ControllerPath = "Assets/Animations/SolaraHumanoid_Template.controller";

        [MenuItem("Solara City/2. Generate Humanoid Animator Controller Template")]
        public static void GenerateInteractive()
        {
            GenerateHeadless();
            EditorUtility.DisplayDialog(
                "Animator Template Created",
                $"Создан контроллер {ControllerPath}. Назначьте реальные клипы (Idle, Walk, Run, Jump, EnterVehicle, Seated, ExitVehicle) в Animator Window и привяжите его в SolaraVisualCatalog.",
                "Понятно");
        }

        public static AnimatorController GenerateHeadless()
        {
            Directory.CreateDirectory("Assets/Animations");
            var existing = AssetDatabase.LoadAssetAtPath<AnimatorController>(ControllerPath);
            if (existing != null) return existing;

            var controller = AnimatorController.CreateAnimatorControllerAtPath(ControllerPath);

            controller.AddParameter("Speed", AnimatorControllerParameterType.Float);
            controller.AddParameter("IsSprinting", AnimatorControllerParameterType.Bool);
            controller.AddParameter("IsGrounded", AnimatorControllerParameterType.Bool);
            controller.AddParameter("VerticalVelocity", AnimatorControllerParameterType.Float);
            controller.AddParameter("Jump", AnimatorControllerParameterType.Trigger);
            controller.AddParameter("EnterVehicle", AnimatorControllerParameterType.Trigger);
            controller.AddParameter("ExitVehicle", AnimatorControllerParameterType.Trigger);
            controller.AddParameter("IsSeated", AnimatorControllerParameterType.Bool);

            var sm = controller.layers[0].stateMachine;
            var idleState = sm.AddState("Idle", new Vector3(240, 60, 0));
            var walkState = sm.AddState("Walk", new Vector3(480, 0, 0));
            var runState = sm.AddState("Run", new Vector3(720, 0, 0));
            var jumpState = sm.AddState("Jump", new Vector3(480, 140, 0));
            var enterVehState = sm.AddState("EnterVehicle", new Vector3(240, 240, 0));
            var seatedState = sm.AddState("DrivingSeated", new Vector3(480, 240, 0));
            var exitVehState = sm.AddState("ExitVehicle", new Vector3(720, 240, 0));

            sm.defaultState = idleState;

            var idleToWalk = idleState.AddTransition(walkState);
            idleToWalk.hasExitTime = false;
            idleToWalk.duration = 0.15f;
            idleToWalk.AddCondition(AnimatorConditionMode.Greater, 0.1f, "Speed");

            var walkToIdle = walkState.AddTransition(idleState);
            walkToIdle.hasExitTime = false;
            walkToIdle.duration = 0.15f;
            walkToIdle.AddCondition(AnimatorConditionMode.Less, 0.1f, "Speed");

            var walkToRun = walkState.AddTransition(runState);
            walkToRun.hasExitTime = false;
            walkToRun.duration = 0.15f;
            walkToRun.AddCondition(AnimatorConditionMode.If, 0f, "IsSprinting");

            var runToWalk = runState.AddTransition(walkState);
            runToWalk.hasExitTime = false;
            runToWalk.duration = 0.15f;
            runToWalk.AddCondition(AnimatorConditionMode.IfNot, 0f, "IsSprinting");

            var anyToJump = sm.AddAnyStateTransition(jumpState);
            anyToJump.hasExitTime = false;
            anyToJump.duration = 0.1f;
            anyToJump.AddCondition(AnimatorConditionMode.If, 0f, "Jump");

            var jumpToIdle = jumpState.AddTransition(idleState);
            jumpToIdle.hasExitTime = false;
            jumpToIdle.duration = 0.15f;
            jumpToIdle.AddCondition(AnimatorConditionMode.If, 0f, "IsGrounded");

            var anyToEnter = sm.AddAnyStateTransition(enterVehState);
            anyToEnter.hasExitTime = false;
            anyToEnter.duration = 0.15f;
            anyToEnter.AddCondition(AnimatorConditionMode.If, 0f, "EnterVehicle");

            var enterToSeated = enterVehState.AddTransition(seatedState);
            enterToSeated.hasExitTime = true;
            enterToSeated.exitTime = 0.9f;
            enterToSeated.duration = 0.12f;

            var seatedToExit = seatedState.AddTransition(exitVehState);
            seatedToExit.hasExitTime = false;
            seatedToExit.duration = 0.12f;
            seatedToExit.AddCondition(AnimatorConditionMode.If, 0f, "ExitVehicle");

            var exitToIdle = exitVehState.AddTransition(idleState);
            exitToIdle.hasExitTime = true;
            exitToIdle.exitTime = 0.9f;
            exitToIdle.duration = 0.15f;

            AssetDatabase.SaveAssets();
            Debug.Log($"[SolaraAnimatorTemplateGenerator] Created Humanoid Animator template at {ControllerPath}");
            return controller;
        }
    }
}
#endif
