using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

namespace SolaraCity.Optimization
{
    public enum MobileQualityTier
    {
        Low = 0,
        Medium = 1,
        High = 2
    }

    public class MobileQualityController : MonoBehaviour
    {
        public MobileQualityTier CurrentTier { get; private set; } = MobileQualityTier.Medium;

        private void Awake()
        {
            QualitySettings.vSyncCount = 0;
            Screen.sleepTimeout = SleepTimeout.NeverSleep;
            ApplyTier(Application.isMobilePlatform ? MobileQualityTier.Medium : MobileQualityTier.High);
        }

        public void ApplyTier(MobileQualityTier tier)
        {
            CurrentTier = tier;

            var urp = GraphicsSettings.currentRenderPipeline as UniversalRenderPipelineAsset;

            switch (tier)
            {
                case MobileQualityTier.Low:
                    Application.targetFrameRate = 30;
                    QualitySettings.globalTextureMipmapLimit = 1;
                    if (urp != null)
                    {
                        urp.renderScale = 0.75f;
                        urp.shadowDistance = 35f;
                        urp.msaaSampleCount = 1;
                    }
                    break;

                case MobileQualityTier.Medium:
                    Application.targetFrameRate = 60;
                    QualitySettings.globalTextureMipmapLimit = 0;
                    if (urp != null)
                    {
                        urp.renderScale = 0.90f;
                        urp.shadowDistance = 65f;
                        urp.msaaSampleCount = 2;
                    }
                    break;

                case MobileQualityTier.High:
                    Application.targetFrameRate = 60;
                    QualitySettings.globalTextureMipmapLimit = 0;
                    if (urp != null)
                    {
                        urp.renderScale = 1.0f;
                        urp.shadowDistance = 100f;
                        urp.msaaSampleCount = 4;
                    }
                    break;
            }
        }
    }
}
