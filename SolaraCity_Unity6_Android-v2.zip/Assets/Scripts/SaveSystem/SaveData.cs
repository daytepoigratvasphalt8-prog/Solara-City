using System;
using System.Collections.Generic;

namespace SolaraCity.SaveSystem
{
    [Serializable]
    public class SaveData
    {
        public int Version = 1;
        public int Money = 5000;
        public float Health = 100f;
        public float PlayerPosX = 0f;
        public float PlayerPosY = 1.2f;
        public float PlayerPosZ = -12f;
        public float TimeOfDay = 10.5f;
        public int QualityTier = 1;
        public float CameraSensitivity = 0.28f;
        public List<string> OwnedVehicles = new List<string>();
        public List<string> OwnedProperties = new List<string>();
        public List<string> CompletedMissions = new List<string>();
    }
}
