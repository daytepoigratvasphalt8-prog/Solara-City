using System;
using System.IO;
using System.Linq;
using UnityEngine;
using SolaraCity.Core;

namespace SolaraCity.SaveSystem
{
    public class SaveManager : MonoBehaviour
    {
        private string SavePath => Path.Combine(Application.persistentDataPath, "solara_city_save.json");
        private string BackupPath => Path.Combine(Application.persistentDataPath, "solara_city_save.bak");

        public bool HasSaveFile() => File.Exists(SavePath);

        public void SaveGame()
        {
            var gm = GameManager.Instance;
            if (gm == null) return;

            var data = new SaveData
            {
                Money = gm.Economy != null ? gm.Economy.Balance : 5000,
                Health = gm.Player != null ? gm.Player.Stats.CurrentHealth : 100f,
                TimeOfDay = gm.DayNight != null ? gm.DayNight.TimeOfDay : 10.5f,
                QualityTier = gm.Quality != null ? (int)gm.Quality.CurrentTier : 1,
                CameraSensitivity = gm.MainCamera != null ? gm.MainCamera.Sensitivity : 0.28f,
                OwnedVehicles = gm.Economy != null ? gm.Economy.OwnedVehicles.ToList() : new System.Collections.Generic.List<string>(),
                OwnedProperties = gm.Economy != null ? gm.Economy.OwnedProperties.ToList() : new System.Collections.Generic.List<string>(),
                CompletedMissions = gm.Missions != null ? gm.Missions.CompletedMissionIds.ToList() : new System.Collections.Generic.List<string>()
            };

            if (gm.Player != null)
            {
                Vector3 pos = gm.ActiveVehicle != null ? gm.ActiveVehicle.GetSafeExitPosition() : gm.Player.transform.position;
                data.PlayerPosX = pos.x;
                data.PlayerPosY = Mathf.Max(1.0f, pos.y);
                data.PlayerPosZ = pos.z;
            }

            try
            {
                string json = JsonUtility.ToJson(data, true);
                if (File.Exists(SavePath))
                    File.Copy(SavePath, BackupPath, true);
                File.WriteAllText(SavePath, json);
            }
            catch (Exception ex)
            {
                Debug.LogError($"[SaveManager] Failed to save game: {ex.Message}");
            }
        }

        public bool LoadGame()
        {
            var gm = GameManager.Instance;
            if (gm == null || !File.Exists(SavePath)) return false;

            try
            {
                string json = File.ReadAllText(SavePath);
                var data = JsonUtility.FromJson<SaveData>(json);
                if (data == null) return false;

                gm.Economy?.LoadState(data.Money, data.OwnedVehicles, data.OwnedProperties);
                gm.Missions?.LoadCompleted(data.CompletedMissions);
                gm.DayNight?.SetTimeOfDay(data.TimeOfDay);
                gm.Quality?.ApplyTier((Optimization.MobileQualityTier)Mathf.Clamp(data.QualityTier, 0, 2));

                if (gm.MainCamera != null)
                    gm.MainCamera.Sensitivity = data.CameraSensitivity;

                if (gm.Player != null)
                {
                    gm.Player.TeleportTo(new Vector3(data.PlayerPosX, data.PlayerPosY, data.PlayerPosZ));
                    gm.Player.Stats.SetHealth(data.Health);
                }

                return true;
            }
            catch (Exception ex)
            {
                Debug.LogError($"[SaveManager] Failed to load save: {ex.Message}");
                return false;
            }
        }

        public void DeleteSave()
        {
            if (File.Exists(SavePath)) File.Delete(SavePath);
            if (File.Exists(BackupPath)) File.Delete(BackupPath);
        }
    }
}
