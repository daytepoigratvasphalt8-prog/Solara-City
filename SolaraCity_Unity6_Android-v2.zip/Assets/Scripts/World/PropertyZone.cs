using UnityEngine;
using SolaraCity.Core;

namespace SolaraCity.World
{
    public class PropertyZone : MonoBehaviour, IInteractable
    {
        public string PropertyId;
        public string PropertyName;
        public int Price;
        public int PassiveIncomePerMinute;

        private float _incomeTimer;

        public bool IsOwned => GameManager.Instance != null &&
                               GameManager.Instance.Economy != null &&
                               GameManager.Instance.Economy.OwnsProperty(PropertyId);

        public bool CanInteract => true;

        public string InteractionPrompt => IsOwned
            ? $"{PropertyName} (Ваша собственность — Сохранить игру)"
            : $"Купить {PropertyName} (${Price:N0})";

        private void Update()
        {
            if (!IsOwned || Time.timeScale <= 0f) return;

            _incomeTimer += Time.deltaTime;
            if (_incomeTimer >= 60f)
            {
                _incomeTimer = 0f;
                GameManager.Instance.Economy.AddMoney(PassiveIncomePerMinute);
                EventBus.Publish(new ToastNotificationEvent($"Доход от {PropertyName}: +${PassiveIncomePerMinute}", 2.5f));
            }
        }

        public void Interact(GameObject interactor)
        {
            var gm = GameManager.Instance;
            if (gm == null || gm.Economy == null) return;

            if (IsOwned)
            {
                gm.Player?.Stats.Heal(100f);
                gm.SaveSystem?.SaveGame();
                EventBus.Publish(new ToastNotificationEvent($"Прогресс сохранён в {PropertyName}!"));
                return;
            }

            if (gm.Economy.TryBuyProperty(PropertyId, Price))
            {
                gm.SaveSystem?.SaveGame();
                EventBus.Publish(new ToastNotificationEvent($"Куплено: {PropertyName}! Доход: +${PassiveIncomePerMinute}/мин"));
            }
            else
            {
                EventBus.Publish(new ToastNotificationEvent($"Нужно ${Price:N0} для покупки {PropertyName}"));
            }
        }
    }
}
