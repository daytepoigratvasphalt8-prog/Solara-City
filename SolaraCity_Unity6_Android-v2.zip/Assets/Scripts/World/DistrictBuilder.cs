using UnityEngine;
using SolaraCity.Core;

namespace SolaraCity.World
{
    /// <summary>
    /// Builds Solara City District 01 with upgraded procedural PBR textures, curbs, crosswalks,
    /// rooftop details, LODGroups, and automatic Prefab override hooks from VisualAssetCatalog.
    /// </summary>
    public class DistrictBuilder : MonoBehaviour
    {
        public VisualAssetCatalog VisualCatalog { get; set; }

        private Material _asphaltMat;
        private Material _sidewalkMat;
        private Material _curbMat;
        private Material _grassMat;
        private Material _laneMat;
        private Material _glassTowerMat;
        private Material _concreteMat;
        private Material _residentialA;
        private Material _residentialB;
        private Material _industrialMat;
        private Material _accentCyan;
        private Material _accentGold;
        private Material _accentRed;
        private Material _woodMat;
        private Material _foliageMat;
        private Material _metalDark;

        public void BuildDistrict(DayNightCycle dayNight = null)
        {
            InitMaterials(dayNight);
            BuildGroundAndRoads();
            BuildDowntownBlock();
            BuildResidentialBlock();
            BuildCentralPark();
            BuildAutoDealership();
            BuildGasStation();
            BuildIndustrialZone();
            BuildStreetFurniture(dayNight);
            BuildCityPerimeter();
        }

        private void InitMaterials(DayNightCycle dayNight)
        {
            bool useTex = VisualCatalog == null || VisualCatalog.UseProceduralPBRTextures;

            if (useTex)
            {
                _asphaltMat = MaterialFactory.CreateTexturedLit("Mat_Asphalt", Color.white,
                    ProceduralTextureGenerator.GetAsphaltAlbedo(),
                    ProceduralTextureGenerator.GetAsphaltNormal(),
                    new Vector2(2f, 22f), 0.22f, 0f, 0.7f);

                _sidewalkMat = MaterialFactory.CreateTexturedLit("Mat_Sidewalk", Color.white,
                    ProceduralTextureGenerator.GetSidewalkAlbedo(),
                    ProceduralTextureGenerator.GetSidewalkNormal(),
                    new Vector2(36f, 36f), 0.14f, 0f, 0.6f);

                _grassMat = MaterialFactory.CreateTexturedLit("Mat_Grass", Color.white,
                    ProceduralTextureGenerator.GetGrassAlbedo(), null,
                    new Vector2(8f, 8f), 0.08f, 0f);

                _glassTowerMat = MaterialFactory.CreateTexturedLit("Mat_GlassTower", Color.white,
                    ProceduralTextureGenerator.GetSkyscraperFacadeAlbedo(), null,
                    new Vector2(2f, 6f), 0.88f, 0.55f);
                MaterialFactory.SetEmissionMap(_glassTowerMat,
                    ProceduralTextureGenerator.GetSkyscraperWindowEmission(),
                    Color.white, 0f, new Vector2(2f, 6f));
                dayNight?.RegisterSkyscraperMaterial(_glassTowerMat);

                _residentialA = MaterialFactory.CreateTexturedLit("Mat_ResidentialWarm", Color.white,
                    ProceduralTextureGenerator.GetResidentialFacadeAlbedo(new Color(0.84f, 0.76f, 0.65f)),
                    null, new Vector2(2f, 2f), 0.14f, 0f);

                _residentialB = MaterialFactory.CreateTexturedLit("Mat_ResidentialTerracotta", Color.white,
                    ProceduralTextureGenerator.GetResidentialFacadeAlbedo(new Color(0.76f, 0.50f, 0.41f)),
                    null, new Vector2(2f, 3f), 0.16f, 0f);

                _industrialMat = MaterialFactory.CreateTexturedLit("Mat_Industrial", Color.white,
                    ProceduralTextureGenerator.GetIndustrialMetalAlbedo(),
                    ProceduralTextureGenerator.GetIndustrialMetalNormal(),
                    new Vector2(4f, 2f), 0.35f, 0.38f, 0.75f);
            }
            else
            {
                _asphaltMat = MaterialFactory.CreateLit("Mat_Asphalt", new Color(0.16f, 0.17f, 0.19f), 0.18f);
                _sidewalkMat = MaterialFactory.CreateLit("Mat_Sidewalk", new Color(0.62f, 0.63f, 0.64f), 0.12f);
                _grassMat = MaterialFactory.CreateLit("Mat_Grass", new Color(0.24f, 0.48f, 0.24f), 0.08f);
                _glassTowerMat = MaterialFactory.CreateLit("Mat_GlassTower", new Color(0.22f, 0.34f, 0.46f), 0.85f, 0.4f);
                _residentialA = MaterialFactory.CreateLit("Mat_ResidentialWarm", new Color(0.82f, 0.73f, 0.62f), 0.12f);
                _residentialB = MaterialFactory.CreateLit("Mat_ResidentialTerracotta", new Color(0.74f, 0.48f, 0.39f), 0.15f);
                _industrialMat = MaterialFactory.CreateLit("Mat_Industrial", new Color(0.42f, 0.46f, 0.50f), 0.25f, 0.2f);
            }

            _curbMat = MaterialFactory.CreateLit("Mat_Curb", new Color(0.55f, 0.56f, 0.58f), 0.15f);
            _laneMat = MaterialFactory.CreateLit("Mat_LaneMarking", new Color(0.92f, 0.88f, 0.65f), 0.12f);
            _concreteMat = MaterialFactory.CreateLit("Mat_Concrete", new Color(0.70f, 0.72f, 0.74f), 0.18f);
            _accentCyan = MaterialFactory.CreateEmissive("Mat_SignCyan", new Color(0.1f, 0.8f, 0.95f), new Color(0.1f, 0.85f, 1f), 1.6f);
            _accentGold = MaterialFactory.CreateEmissive("Mat_SignGold", new Color(1f, 0.78f, 0.2f), new Color(1f, 0.75f, 0.15f), 1.5f);
            _accentRed = MaterialFactory.CreateLit("Mat_FuelRed", new Color(0.78f, 0.18f, 0.18f), 0.45f);
            _woodMat = MaterialFactory.CreateLit("Mat_Wood", new Color(0.38f, 0.25f, 0.16f), 0.12f);
            _foliageMat = MaterialFactory.CreateLit("Mat_Foliage", new Color(0.18f, 0.42f, 0.20f), 0.10f);
            _metalDark = MaterialFactory.CreateLit("Mat_MetalDark", new Color(0.22f, 0.24f, 0.27f), 0.58f, 0.65f);
        }

        private void BuildGroundAndRoads()
        {
            var groundParent = new GameObject("RoadsAndGround").transform;
            groundParent.SetParent(transform, false);

            CreateBox("BaseGround", groundParent, new Vector3(0f, -0.5f, 0f), new Vector3(320f, 1f, 320f), _sidewalkMat, true);

            float[] roadCoords = { -60f, 0f, 60f };
            foreach (float x in roadCoords)
            {
                CreateBox($"RoadNS_{x}", groundParent, new Vector3(x, 0.02f, 0f), new Vector3(14f, 0.04f, 280f), _asphaltMat, true);
                for (float z = -125f; z <= 125f; z += 12f)
                {
                    if (Mathf.Abs(z) < 9f || Mathf.Abs(z - 60f) < 9f || Mathf.Abs(z + 60f) < 9f) continue;
                    CreateBox("Dash", groundParent, new Vector3(x, 0.045f, z), new Vector3(0.25f, 0.01f, 4.5f), _laneMat, false);
                }
            }

            foreach (float z in roadCoords)
            {
                CreateBox($"RoadEW_{z}", groundParent, new Vector3(0f, 0.022f, z), new Vector3(280f, 0.04f, 14f), _asphaltMat, true);
                for (float x = -125f; x <= 125f; x += 12f)
                {
                    if (Mathf.Abs(x) < 9f || Mathf.Abs(x - 60f) < 9f || Mathf.Abs(x + 60f) < 9f) continue;
                    CreateBox("Dash", groundParent, new Vector3(x, 0.046f, z), new Vector3(4.5f, 0.01f, 0.25f), _laneMat, false);
                }
            }

            // Crosswalks at central intersections
            foreach (float ix in roadCoords)
            {
                foreach (float iz in roadCoords)
                {
                    CreateCrosswalk(groundParent, new Vector3(ix, 0.048f, iz + 8.6f), true);
                    CreateCrosswalk(groundParent, new Vector3(ix, 0.048f, iz - 8.6f), true);
                    CreateCrosswalk(groundParent, new Vector3(ix + 8.6f, 0.048f, iz), false);
                    CreateCrosswalk(groundParent, new Vector3(ix - 8.6f, 0.048f, iz), false);
                }
            }

            // Raised curb borders on the central 4 city blocks
            float[] blockCenters = { -30f, 30f };
            foreach (float bx in blockCenters)
                foreach (float bz in blockCenters)
                    CreateBlockCurbFrame(groundParent, new Vector3(bx, 0.08f, bz), 44f, 44f);
        }

        private void CreateCrosswalk(Transform parent, Vector3 center, bool horizontalRoad)
        {
            for (int i = -2; i <= 2; i++)
            {
                Vector3 offset = horizontalRoad ? new Vector3(i * 2.1f, 0f, 0f) : new Vector3(0f, 0f, i * 2.1f);
                Vector3 scale = horizontalRoad ? new Vector3(0.85f, 0.01f, 2.6f) : new Vector3(2.6f, 0.01f, 0.85f);
                CreateBox("CrosswalkStripe", parent, center + offset, scale, _laneMat, false);
            }
        }

        private void CreateBlockCurbFrame(Transform parent, Vector3 center, float width, float depth)
        {
            float halfW = width * 0.5f;
            float halfD = depth * 0.5f;
            CreateBox("CurbN", parent, center + new Vector3(0f, 0f, halfD), new Vector3(width, 0.14f, 0.45f), _curbMat, false);
            CreateBox("CurbS", parent, center + new Vector3(0f, 0f, -halfD), new Vector3(width, 0.14f, 0.45f), _curbMat, false);
            CreateBox("CurbE", parent, center + new Vector3(halfW, 0f, 0f), new Vector3(0.45f, 0.14f, depth), _curbMat, false);
            CreateBox("CurbW", parent, center + new Vector3(-halfW, 0f, 0f), new Vector3(0.45f, 0.14f, depth), _curbMat, false);
        }

        private void BuildDowntownBlock()
        {
            var parent = new GameObject("Downtown_District").transform;
            parent.SetParent(transform, false);

            CreateSkyscraper(parent, "SolaraTower_One", new Vector3(-24f, 0f, 24f), new Vector3(14f, 48f, 14f), _glassTowerMat, _concreteMat, 0);
            CreateSkyscraper(parent, "SolaraTower_Two", new Vector3(-42f, 0f, 38f), new Vector3(16f, 62f, 14f), _glassTowerMat, _concreteMat, 1);
            CreateSkyscraper(parent, "MeridianPlaza", new Vector3(-22f, 0f, 42f), new Vector3(13f, 34f, 12f), _glassTowerMat, _concreteMat, 0);
            CreateSkyscraper(parent, "NorthBank", new Vector3(-42f, 0f, 20f), new Vector3(12f, 26f, 12f), _concreteMat, _glassTowerMat, 1);
            CreateSkyscraper(parent, "Skyline_A", new Vector3(-28f, 0f, 88f), new Vector3(18f, 70f, 18f), _glassTowerMat, _concreteMat, 0);
            CreateSkyscraper(parent, "Skyline_B", new Vector3(28f, 0f, 88f), new Vector3(16f, 54f, 16f), _glassTowerMat, _concreteMat, 1);
        }

        private void BuildResidentialBlock()
        {
            var parent = new GameObject("Residential_Quarter").transform;
            parent.SetParent(transform, false);

            CreateResidentialBuilding(parent, "PalmViewLoft", new Vector3(-24f, 0f, -24f), new Vector3(14f, 12f, 12f), _residentialA, 0);
            CreateBox("PalmViewSign", parent, new Vector3(-16.9f, 3.2f, -24f), new Vector3(0.2f, 0.8f, 5.5f), _accentGold, false);
            CreatePropertyTrigger(parent, "prop_palm_loft", "Palm View Loft", 18000, 450, new Vector3(-15f, 1f, -24f));

            CreateResidentialBuilding(parent, "Apartments_B", new Vector3(-42f, 0f, -22f), new Vector3(13f, 16f, 14f), _residentialB, 1);
            CreateResidentialBuilding(parent, "Apartments_C", new Vector3(-24f, 0f, -42f), new Vector3(15f, 10f, 11f), _residentialB, 0);
            CreateResidentialBuilding(parent, "CornerShop", new Vector3(-42f, 0f, -42f), new Vector3(12f, 6f, 12f), _residentialA, 1);
            CreateBox("ShopAwning", parent, new Vector3(-35.5f, 2.8f, -42f), new Vector3(1.5f, 0.4f, 10f), _accentCyan, false);
        }

        private void BuildCentralPark()
        {
            var parent = new GameObject("Central_Park").transform;
            parent.SetParent(transform, false);

            CreateBox("ParkLawn", parent, new Vector3(30f, 0.06f, -30f), new Vector3(38f, 0.12f, 38f), _grassMat, true);
            CreateBox("Walkway_NS", parent, new Vector3(30f, 0.13f, -30f), new Vector3(3.5f, 0.05f, 38f), _sidewalkMat, false);
            CreateBox("Walkway_EW", parent, new Vector3(30f, 0.13f, -30f), new Vector3(38f, 0.05f, 3.5f), _sidewalkMat, false);

            if (VisualCatalog?.Environment?.FountainPrefab != null)
            {
                var f = Instantiate(VisualCatalog.Environment.FountainPrefab, parent);
                f.transform.position = new Vector3(30f, 0.15f, -30f);
            }
            else
            {
                CreateBox("FountainBase", parent, new Vector3(30f, 0.45f, -30f), new Vector3(6.5f, 0.9f, 6.5f), _concreteMat, true);
                CreateBox("FountainWater", parent, new Vector3(30f, 0.78f, -30f), new Vector3(5.2f, 0.3f, 5.2f), _accentCyan, false);
            }

            Vector3[] treePositions =
            {
                new Vector3(17f, 0f, -17f), new Vector3(43f, 0f, -17f),
                new Vector3(17f, 0f, -43f), new Vector3(43f, 0f, -43f),
                new Vector3(22f, 0f, -38f), new Vector3(38f, 0f, -22f)
            };
            foreach (var pos in treePositions)
                CreateTree(parent, pos);
        }

        private void BuildAutoDealership()
        {
            var parent = new GameObject("SolaraMotors_Dealership").transform;
            parent.SetParent(transform, false);

            if (VisualCatalog?.Environment?.DealershipPrefab != null)
            {
                var d = Instantiate(VisualCatalog.Environment.DealershipPrefab, parent);
                d.transform.position = new Vector3(26f, 0f, 34f);
            }
            else
            {
                CreateBox("ShowroomBuilding", parent, new Vector3(26f, 4f, 34f), new Vector3(22f, 8f, 16f), _glassTowerMat, true);
                CreateBox("ShowroomRoof", parent, new Vector3(26f, 8.3f, 34f), new Vector3(24f, 0.7f, 18f), _metalDark, true);
                CreateBox("DealershipNeon", parent, new Vector3(26f, 8.8f, 25.2f), new Vector3(12f, 0.9f, 0.4f), _accentCyan, false);
            }

            CreateBox("ForecourtAsphalt", parent, new Vector3(28f, 0.04f, 17f), new Vector3(34f, 0.06f, 14f), _asphaltMat, true);

            var triggerObj = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            triggerObj.name = "DealershipInteractPoint";
            triggerObj.transform.SetParent(parent, false);
            triggerObj.transform.position = new Vector3(26f, 0.25f, 23f);
            triggerObj.transform.localScale = new Vector3(2.2f, 0.15f, 2.2f);
            triggerObj.GetComponent<Renderer>().sharedMaterial = _accentCyan;
            triggerObj.GetComponent<Collider>().isTrigger = true;
            var zone = triggerObj.AddComponent<DealershipZone>();
            zone.DeliverySpawnPoint = new Vector3(38f, 0.8f, 16f);
        }

        private void BuildGasStation()
        {
            var parent = new GameObject("SolaraFuel_Station").transform;
            parent.SetParent(transform, false);

            CreateBox("StationPad", parent, new Vector3(84f, 0.05f, 26f), new Vector3(28f, 0.1f, 24f), _asphaltMat, true);

            if (VisualCatalog?.Environment?.FuelStationPrefab != null)
            {
                var gs = Instantiate(VisualCatalog.Environment.FuelStationPrefab, parent);
                gs.transform.position = new Vector3(84f, 0.1f, 26f);
            }
            else
            {
                CreateBox("CanopyRoof", parent, new Vector3(80f, 5.2f, 26f), new Vector3(14f, 0.7f, 16f), _accentRed, true);
                CreateBox("Pillar1", parent, new Vector3(76f, 2.6f, 21f), new Vector3(0.6f, 5.2f, 0.6f), _concreteMat, true);
                CreateBox("Pillar2", parent, new Vector3(76f, 2.6f, 31f), new Vector3(0.6f, 5.2f, 0.6f), _concreteMat, true);
                CreateBox("Pump1", parent, new Vector3(80f, 1.0f, 23f), new Vector3(1.0f, 2.0f, 0.7f), _metalDark, true);
                CreateBox("Pump2", parent, new Vector3(80f, 1.0f, 29f), new Vector3(1.0f, 2.0f, 0.7f), _metalDark, true);
                CreateBox("FuelStore", parent, new Vector3(93f, 2.5f, 26f), new Vector3(8f, 5f, 14f), _concreteMat, true);
            }

            var triggerObj = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            triggerObj.name = "FuelInteractPoint";
            triggerObj.transform.SetParent(parent, false);
            triggerObj.transform.position = new Vector3(80f, 0.25f, 26f);
            triggerObj.transform.localScale = new Vector3(2.4f, 0.15f, 2.4f);
            triggerObj.GetComponent<Renderer>().sharedMaterial = _accentGold;
            triggerObj.GetComponent<Collider>().isTrigger = true;
            triggerObj.AddComponent<FuelStationZone>();
        }

        private void BuildIndustrialZone()
        {
            var parent = new GameObject("Industrial_Zone").transform;
            parent.SetParent(transform, false);

            if (VisualCatalog?.Environment?.WarehousePrefab != null)
            {
                var wh = Instantiate(VisualCatalog.Environment.WarehousePrefab, parent);
                wh.transform.position = new Vector3(92f, 0f, -30f);
            }
            else
            {
                CreateBox("Warehouse_Main", parent, new Vector3(92f, 5.5f, -30f), new Vector3(26f, 11f, 20f), _industrialMat, true);
            }

            CreateBox("Container_Blue", parent, new Vector3(78f, 1.4f, -45f), new Vector3(6.5f, 2.8f, 2.6f), _glassTowerMat, true);
            CreateBox("Container_Red", parent, new Vector3(86f, 1.4f, -45f), new Vector3(6.5f, 2.8f, 2.6f), _accentRed, true);

            CreatePropertyTrigger(parent, "prop_harbor_garage", "Harbor Warehouse Garage", 35000, 950, new Vector3(76f, 1f, -30f));
        }

        private void BuildStreetFurniture(DayNightCycle dayNight)
        {
            var parent = new GameObject("StreetLights").transform;
            parent.SetParent(transform, false);
            if (dayNight == null) dayNight = FindFirstObjectByType<DayNightCycle>();

            for (float z = -80f; z <= 80f; z += 28f)
            {
                CreateStreetLamp(parent, new Vector3(8.5f, 0f, z), dayNight);
                CreateStreetLamp(parent, new Vector3(-8.5f, 0f, z), dayNight);
            }
        }

        private void BuildCityPerimeter()
        {
            var parent = new GameObject("WorldBounds").transform;
            parent.SetParent(transform, false);

            CreateBox("Wall_N", parent, new Vector3(0f, 1.5f, 155f), new Vector3(312f, 3f, 2f), _concreteMat, true);
            CreateBox("Wall_S", parent, new Vector3(0f, 1.5f, -155f), new Vector3(312f, 3f, 2f), _concreteMat, true);
            CreateBox("Wall_E", parent, new Vector3(155f, 1.5f, 0f), new Vector3(2f, 3f, 312f), _concreteMat, true);
            CreateBox("Wall_W", parent, new Vector3(-155f, 1.5f, 0f), new Vector3(2f, 3f, 312f), _concreteMat, true);
        }

        private void CreateSkyscraper(Transform parent, string name, Vector3 basePos, Vector3 size, Material mainMat, Material trimMat, int variantIndex)
        {
            var variants = VisualCatalog?.Environment?.SkyscraperVariants;
            if (variants != null && variants.Length > 0 && variants[variantIndex % variants.Length] != null)
            {
                var inst = Instantiate(variants[variantIndex % variants.Length], parent);
                inst.name = name;
                inst.transform.position = basePos;
                return;
            }

            var main = CreateBox(name, parent, basePos + new Vector3(0f, size.y * 0.5f, 0f), size, mainMat, true);
            CreateBox($"{name}_Crown", main.transform, new Vector3(0f, 0.52f, 0f), new Vector3(0.86f, 0.04f, 0.86f), trimMat, false);
            CreateBox($"{name}_HVAC", main.transform, new Vector3(0.18f, 0.55f, -0.14f), new Vector3(0.28f, 0.04f, 0.28f), _metalDark, false);
        }

        private void CreateResidentialBuilding(Transform parent, string name, Vector3 basePos, Vector3 size, Material mainMat, int variantIndex)
        {
            var variants = VisualCatalog?.Environment?.ResidentialVariants;
            if (variants != null && variants.Length > 0 && variants[variantIndex % variants.Length] != null)
            {
                var inst = Instantiate(variants[variantIndex % variants.Length], parent);
                inst.name = name;
                inst.transform.position = basePos;
                return;
            }

            var main = CreateBox(name, parent, basePos + new Vector3(0f, size.y * 0.5f, 0f), size, mainMat, true);
            CreateBox($"{name}_RoofTrim", main.transform, new Vector3(0f, 0.51f, 0f), new Vector3(1.03f, 0.04f, 1.03f), _concreteMat, false);
        }

        private void CreateTree(Transform parent, Vector3 pos)
        {
            if (VisualCatalog?.Environment?.TreePrefab != null)
            {
                var t = Instantiate(VisualCatalog.Environment.TreePrefab, parent);
                t.transform.position = pos;
                return;
            }

            var tree = new GameObject("Tree");
            tree.transform.SetParent(parent, false);
            tree.transform.position = pos;

            var trunk = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            trunk.transform.SetParent(tree.transform, false);
            trunk.transform.localPosition = new Vector3(0f, 1.6f, 0f);
            trunk.transform.localScale = new Vector3(0.45f, 1.6f, 0.45f);
            trunk.GetComponent<Renderer>().sharedMaterial = _woodMat;

            var crown = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            Object.Destroy(crown.GetComponent<Collider>());
            crown.transform.SetParent(tree.transform, false);
            crown.transform.localPosition = new Vector3(0f, 3.8f, 0f);
            crown.transform.localScale = new Vector3(3.1f, 2.8f, 3.1f);
            crown.GetComponent<Renderer>().sharedMaterial = _foliageMat;

            AttachSimpleCullLOD(tree, 0.04f);
        }

        private void CreateStreetLamp(Transform parent, Vector3 pos, DayNightCycle dayNight)
        {
            if (VisualCatalog?.Environment?.StreetLampPrefab != null)
            {
                var l = Instantiate(VisualCatalog.Environment.StreetLampPrefab, parent);
                l.transform.position = pos;
                return;
            }

            var lamp = new GameObject("StreetLamp");
            lamp.transform.SetParent(parent, false);
            lamp.transform.position = pos;

            var pole = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            pole.transform.SetParent(lamp.transform, false);
            pole.transform.localPosition = new Vector3(0f, 3.2f, 0f);
            pole.transform.localScale = new Vector3(0.16f, 3.2f, 0.16f);
            pole.GetComponent<Renderer>().sharedMaterial = _metalDark;

            var bulb = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            Object.Destroy(bulb.GetComponent<Collider>());
            bulb.transform.SetParent(lamp.transform, false);
            bulb.transform.localPosition = new Vector3(0f, 6.4f, 0f);
            bulb.transform.localScale = new Vector3(0.45f, 0.3f, 0.45f);
            var rend = bulb.GetComponent<Renderer>();
            if (dayNight != null) dayNight.RegisterStreetLamp(rend);

            AttachSimpleCullLOD(lamp, 0.025f);
        }

        private void AttachSimpleCullLOD(GameObject target, float cullThreshold)
        {
            if (VisualCatalog != null && !VisualCatalog.AttachAutomaticLODGroups) return;
            var lodGroup = target.AddComponent<LODGroup>();
            var renderers = target.GetComponentsInChildren<Renderer>();
            lodGroup.SetLODs(new[] { new LOD(cullThreshold, renderers) });
            lodGroup.RecalculateBounds();
        }

        private void CreatePropertyTrigger(Transform parent, string id, string displayName, int price, int income, Vector3 pos)
        {
            var marker = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            marker.name = $"Property_{id}";
            marker.transform.SetParent(parent, false);
            marker.transform.position = new Vector3(pos.x, 0.25f, pos.z);
            marker.transform.localScale = new Vector3(2.0f, 0.15f, 2.0f);
            marker.GetComponent<Renderer>().sharedMaterial = _accentGold;
            marker.GetComponent<Collider>().isTrigger = true;

            var zone = marker.AddComponent<PropertyZone>();
            zone.PropertyId = id;
            zone.PropertyName = displayName;
            zone.Price = price;
            zone.PassiveIncomePerMinute = income;
        }

        private static GameObject CreateBox(string name, Transform parent, Vector3 pos, Vector3 scale, Material mat, bool withCollider)
        {
            var go = GameObject.CreatePrimitive(PrimitiveType.Cube);
            go.name = name;
            go.isStatic = true;
            if (!withCollider)
                Object.Destroy(go.GetComponent<Collider>());
            go.transform.SetParent(parent, false);
            go.transform.localPosition = pos;
            go.transform.localScale = scale;
            go.GetComponent<Renderer>().sharedMaterial = mat;
            return go;
        }
    }
}
