using UnityEngine;
using UnityEngine.Rendering;

namespace SolaraCity.World
{
    /// <summary>
    /// Mobile-optimized environment reflection probe (128x128, ViaScripting with TimeSlicing)
    /// giving realistic sky/city reflections on car paint and skyscraper glass without per-frame GPU overhead.
    /// </summary>
    public class EnvironmentReflectionRig : MonoBehaviour
    {
        private ReflectionProbe _probe;

        public void Initialize()
        {
            var probeObj = new GameObject("CityReflectionProbe");
            probeObj.transform.SetParent(transform, false);
            probeObj.transform.position = new Vector3(0f, 18f, 0f);

            _probe = probeObj.AddComponent<ReflectionProbe>();
            _probe.mode = ReflectionProbeMode.Realtime;
            _probe.refreshMode = ReflectionProbeRefreshMode.ViaScripting;
            _probe.timeSlicingMode = ReflectionProbeTimeSlicingMode.IndividualFaces;
            _probe.resolution = 128;
            _probe.size = new Vector3(340f, 160f, 340f);
            _probe.intensity = 0.85f;
            _probe.hdr = false;
            _probe.farClipPlane = 260f;

            RefreshNow();
        }

        public void RefreshNow()
        {
            if (_probe != null)
                _probe.RenderProbe();
        }
    }
}
