using UnityEngine;
using SolaraCity.Core;

namespace SolaraCity.World
{
    public class FuelStationZone : MonoBehaviour, IInteractable
    {
        [SerializeField] private int serviceCost = 150;
        public bool CanInteract => true;
        public string InteractionPrompt => $"Заправка и ремонт (${serviceCost})";

        public void Interact(GameObject interactor)
        {
            var gm = GameManager.Instance;
            if (gm == null || gm.Economy == null) return;

            var vehicles = FindObjectsByType<Vehicles.VehicleController>(FindObjectsSortMode.None);
            Vehicles.VehicleController nearest = null;
            float bestDist = 14f;
            foreach (var v in vehicles)
            {
                float d = Vector3.Distance(transform.position, v.transform.position);
                if (d < bestDist)
                {
                    bestDist = d;
                    nearest = v;
                }
            }

            if (nearest == null)
            {
                EventBus.Publish(new ToastNotificationEvent("Подгоните автомобиль ближе к колонке"));
                return;
            }

            if (!gm.Economy.TrySpend(serviceCost))
            {
                EventBus.Publish(new ToastNotificationEvent("Недостаточно средств для обслуживания"));
                return;
            }

            nearest.RefuelAndRepair();
            gm.Player?.Stats.Heal(100f);
            EventBus.Publish(new ToastNotificationEvent($"{nearest.DisplayName}: бак полон, ремонт выполнен!"));
        }
    }
}
