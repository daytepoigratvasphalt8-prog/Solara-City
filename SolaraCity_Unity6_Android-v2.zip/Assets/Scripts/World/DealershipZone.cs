using UnityEngine;
using SolaraCity.Core;
using SolaraCity.UI;

namespace SolaraCity.World
{
    public class DealershipZone : MonoBehaviour, IInteractable
    {
        public Vector3 DeliverySpawnPoint = new Vector3(44f, 0.7f, 18f);
        public bool CanInteract => true;
        public string InteractionPrompt => "Автосалон Solara Motors";

        public void Interact(GameObject interactor)
        {
            var ui = FindFirstObjectByType<DealershipUIController>();
            if (ui != null)
                ui.Open(DeliverySpawnPoint);
            else
                EventBus.Publish(new ToastNotificationEvent("Автосалон Solara Motors открыт"));
        }
    }
}
