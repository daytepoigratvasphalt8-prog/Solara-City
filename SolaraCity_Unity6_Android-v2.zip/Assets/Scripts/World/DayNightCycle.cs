using System.Collections.Generic;
using UnityEngine;
using SolaraCity.Core;

namespace SolaraCity.World
{
    /// <summary>
    /// Mobile-friendly dynamic time-of-day controller using a single directional light,
    /// ambient/fog interpolation, night-time skyscraper window illumination,
    /// emissive streetlights, and periodic low-cost ReflectionProbe refreshes.
    /// </summary>
    public class DayNightCycle : MonoBehaviour
    {
        [Range(0f, 24f)] public float TimeOfDay = 10.5f;
        [SerializeField] private float fullDayDurationSeconds = 480f;

        private Light _sunLight;
        private readonly List<Renderer> _streetLampBulbs = new List<Renderer>();
        private readonly List<Material> _skyscraperMaterials = new List<Material>();
        private EnvironmentReflectionRig _reflectionRig;
        private Material _lampOnMat;
        private Material _lampOffMat;
        private bool _lampsLit;
        private int _lastReflectionBucket = -1;

        private void Awake()
        {
            _sunLight = FindFirstObjectByType<Light>();
            if (_sunLight == null || _sunLight.type != LightType.Directional)
            {
                var sunObj = new GameObject("Directional Sun");
                _sunLight = sunObj.AddComponent<Light>();
                _sunLight.type = LightType.Directional;
                _sunLight.shadows = LightShadows.Soft;
                _sunLight.shadowStrength = 0.72f;
            }

            _lampOnMat = MaterialFactory.CreateEmissive("Lamp_On", new Color(1f, 0.92f, 0.7f), new Color(1f, 0.85f, 0.55f), 2.5f);
            _lampOffMat = MaterialFactory.CreateLit("Lamp_Off", new Color(0.65f, 0.68f, 0.72f), 0.3f);

            RenderSettings.fog = true;
            RenderSettings.fogMode = FogMode.Linear;
            RenderSettings.fogStartDistance = 100f;
            RenderSettings.fogEndDistance = 350f;
            RenderSettings.ambientMode = UnityEngine.Rendering.AmbientMode.Trilight;
        }

        public void SetReflectionRig(EnvironmentReflectionRig rig) => _reflectionRig = rig;

        public void RegisterStreetLamp(Renderer bulbRenderer)
        {
            if (bulbRenderer != null)
                _streetLampBulbs.Add(bulbRenderer);
        }

        public void RegisterSkyscraperMaterial(Material mat)
        {
            if (mat != null && !_skyscraperMaterials.Contains(mat))
                _skyscraperMaterials.Add(mat);
        }

        private void Update()
        {
            if (Time.timeScale <= 0f) return;

            TimeOfDay = (TimeOfDay + (24f / fullDayDurationSeconds) * Time.deltaTime) % 24f;
            ApplyLighting(TimeOfDay);
        }

        public void SetTimeOfDay(float hour)
        {
            TimeOfDay = Mathf.Repeat(hour, 24f);
            ApplyLighting(TimeOfDay);
        }

        private void ApplyLighting(float hour)
        {
            float normalized = hour / 24f;
            float sunAngle = normalized * 360f - 90f;
            _sunLight.transform.rotation = Quaternion.Euler(sunAngle, 155f, 0f);

            bool isNight = hour < 6f || hour > 19.5f;
            float daylight = Mathf.Clamp01(Mathf.Sin((hour - 6f) / 12f * Mathf.PI));
            float sunsetFactor = 1f - Mathf.Clamp01(Mathf.Abs(hour - 18.5f) / 2f);
            float sunriseFactor = 1f - Mathf.Clamp01(Mathf.Abs(hour - 6.5f) / 2f);
            float goldenHour = Mathf.Max(sunsetFactor, sunriseFactor);

            Color daySun = new Color(1.0f, 0.96f, 0.88f);
            Color goldenSun = new Color(1.0f, 0.58f, 0.32f);
            Color nightMoon = new Color(0.32f, 0.42f, 0.65f);

            _sunLight.color = isNight ? nightMoon : Color.Lerp(daySun, goldenSun, goldenHour);
            _sunLight.intensity = isNight ? 0.25f : Mathf.Lerp(0.38f, 1.38f, daylight);

            // Trilight ambient for richer shading on buildings & vehicles
            Color skyDay = new Color(0.62f, 0.74f, 0.90f);
            Color skyNight = new Color(0.10f, 0.14f, 0.24f);
            Color eqDay = new Color(0.48f, 0.54f, 0.60f);
            Color eqGolden = new Color(0.66f, 0.42f, 0.34f);
            Color groundColor = new Color(0.18f, 0.19f, 0.21f);

            RenderSettings.ambientSkyColor = Color.Lerp(skyNight, skyDay, daylight);
            RenderSettings.ambientEquatorColor = Color.Lerp(Color.Lerp(skyNight, eqDay, daylight), eqGolden, goldenHour * 0.65f);
            RenderSettings.ambientGroundColor = groundColor;

            Color dayFog = new Color(0.70f, 0.82f, 0.94f);
            Color nightFog = new Color(0.06f, 0.08f, 0.15f);
            Color goldenFog = new Color(0.86f, 0.56f, 0.42f);
            Color fog = Color.Lerp(nightFog, dayFog, daylight);
            fog = Color.Lerp(fog, goldenFog, goldenHour * 0.7f);
            RenderSettings.fogColor = fog;

            if (Camera.main != null)
            {
                Camera.main.clearFlags = CameraClearFlags.SolidColor;
                Camera.main.backgroundColor = fog;
            }

            if (isNight != _lampsLit)
            {
                _lampsLit = isNight;
                var targetMat = _lampsLit ? _lampOnMat : _lampOffMat;
                foreach (var bulb in _streetLampBulbs)
                    if (bulb != null) bulb.sharedMaterial = targetMat;

                float windowGlow = _lampsLit ? 1.55f : 0.0f;
                foreach (var towerMat in _skyscraperMaterials)
                {
                    if (towerMat != null && towerMat.HasProperty("_EmissionColor"))
                        towerMat.SetColor("_EmissionColor", Color.white * windowGlow);
                }
            }

            // Refresh reflection probe only every 2 in-game hours to preserve Android GPU budget
            int bucket = Mathf.FloorToInt(hour / 2f);
            if (bucket != _lastReflectionBucket)
            {
                _lastReflectionBucket = bucket;
                _reflectionRig?.RefreshNow();
            }
        }
    }
}
