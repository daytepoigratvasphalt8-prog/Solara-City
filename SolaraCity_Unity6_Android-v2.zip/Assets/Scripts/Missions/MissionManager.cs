using System.Collections.Generic;
using UnityEngine;
using SolaraCity.Core;

namespace SolaraCity.Missions
{
    public class MissionManager : MonoBehaviour
    {
        public List<MissionDefinition> AvailableMissions { get; } = new List<MissionDefinition>();
        public HashSet<string> CompletedMissionIds { get; } = new HashSet<string>();

        public MissionDefinition ActiveMission { get; private set; }
        public int CurrentStepIndex { get; private set; }

        private WaypointBeacon _beacon;

        private void Awake()
        {
            BuildDefaultMissions();
            _beacon = WaypointBeacon.Create();
        }

        private void BuildDefaultMissions()
        {
            AvailableMissions.Clear();

            AvailableMissions.Add(new MissionDefinition
            {
                Id = "mission_express_courier",
                Title = "Экспресс-доставка",
                Summary = "Заберите посылку в жилом квартале и доставьте её в центр города.",
                Type = MissionType.Delivery,
                Reward = 1500,
                Steps = new[]
                {
                    new MissionStep { Description = "Заберите груз у Palm View Loft", TargetPosition = new Vector3(-12f, 0f, -24f), TriggerRadius = 6f },
                    new MissionStep { Description = "Доставьте груз к Solara Tower", TargetPosition = new Vector3(-10f, 0f, 24f), TriggerRadius = 6.5f }
                }
            });

            AvailableMissions.Add(new MissionDefinition
            {
                Id = "mission_harbor_supply",
                Title = "Снабжение порта",
                Summary = "Перевезите оборудование из промышленной зоны на заправку Solara Fuel.",
                Type = MissionType.Delivery,
                Reward = 2200,
                Steps = new[]
                {
                    new MissionStep { Description = "Прибудьте на склад промзоны", TargetPosition = new Vector3(72f, 0f, -30f), TriggerRadius = 7f },
                    new MissionStep { Description = "Доставьте груз на Solara Fuel", TargetPosition = new Vector3(70f, 0f, 26f), TriggerRadius = 7f }
                }
            });

            AvailableMissions.Add(new MissionDefinition
            {
                Id = "mission_city_circuit",
                Title = "Ночной круг Solara",
                Summary = "Проедьте по ключевым перекрёсткам района на автомобиле.",
                Type = MissionType.CheckpointDrive,
                Reward = 3000,
                Steps = new[]
                {
                    new MissionStep { Description = "Контрольная точка 1: Северный проспект", TargetPosition = new Vector3(0f, 0f, 60f), TriggerRadius = 8f },
                    new MissionStep { Description = "Контрольная точка 2: Восточный бульвар", TargetPosition = new Vector3(60f, 0f, 0f), TriggerRadius = 8f },
                    new MissionStep { Description = "Контрольная точка 3: Южное кольцо", TargetPosition = new Vector3(0f, 0f, -60f), TriggerRadius = 8f },
                    new MissionStep { Description = "Финиш: Центральный перекрёсток", TargetPosition = new Vector3(0f, 0f, 0f), TriggerRadius = 8f }
                }
            });

            AvailableMissions.Add(new MissionDefinition
            {
                Id = "mission_city_tour",
                Title = "Знакомство с районом",
                Summary = "Посетите Центральный парк и автосалон Solara Motors.",
                Type = MissionType.Exploration,
                Reward = 1000,
                Steps = new[]
                {
                    new MissionStep { Description = "Посетите фонтан в Центральном парке", TargetPosition = new Vector3(30f, 0f, -24f), TriggerRadius = 7f },
                    new MissionStep { Description = "Посетите автосалон Solara Motors", TargetPosition = new Vector3(26f, 0f, 18f), TriggerRadius = 7f }
                }
            });
        }

        public void ResetMissions()
        {
            CompletedMissionIds.Clear();
            CancelActiveMission();
        }

        public void LoadCompleted(IEnumerable<string> completedIds)
        {
            CompletedMissionIds.Clear();
            if (completedIds != null)
                foreach (var id in completedIds) CompletedMissionIds.Add(id);
        }

        public bool StartMission(string missionId)
        {
            MissionDefinition found = null;
            foreach (var m in AvailableMissions)
            {
                if (m.Id == missionId) { found = m; break; }
            }
            if (found == null || found.Steps == null || found.Steps.Length == 0) return false;

            ActiveMission = found;
            CurrentStepIndex = 0;
            UpdateBeaconAndUI();
            EventBus.Publish(new ToastNotificationEvent($"Задание начато: {found.Title}"));
            return true;
        }

        public void CancelActiveMission()
        {
            ActiveMission = null;
            CurrentStepIndex = 0;
            if (_beacon != null) _beacon.Hide();
            EventBus.Publish(new MissionUpdatedEvent("", "", false));
        }

        private void Update()
        {
            if (ActiveMission == null || GameManager.Instance == null) return;
            var state = GameManager.Instance.CurrentState;
            if (state != GameState.PlayingOnFoot && state != GameState.PlayingInVehicle) return;

            Transform tracked = GameManager.Instance.ActiveVehicle != null
                ? GameManager.Instance.ActiveVehicle.transform
                : GameManager.Instance.Player?.transform;

            if (tracked == null) return;

            var step = ActiveMission.Steps[CurrentStepIndex];
            Vector2 playerXZ = new Vector2(tracked.position.x, tracked.position.z);
            Vector2 targetXZ = new Vector2(step.TargetPosition.x, step.TargetPosition.z);

            if (Vector2.Distance(playerXZ, targetXZ) <= step.TriggerRadius)
            {
                AdvanceStep();
            }
        }

        private void AdvanceStep()
        {
            CurrentStepIndex++;
            if (CurrentStepIndex >= ActiveMission.Steps.Length)
            {
                CompleteActiveMission();
            }
            else
            {
                UpdateBeaconAndUI();
                EventBus.Publish(new ToastNotificationEvent("Точка достигнута! Следуйте к следующей цели", 2.2f));
            }
        }

        private void CompleteActiveMission()
        {
            var finished = ActiveMission;
            ActiveMission = null;
            CurrentStepIndex = 0;
            if (_beacon != null) _beacon.Hide();

            CompletedMissionIds.Add(finished.Id);
            GameManager.Instance.Economy?.AddMoney(finished.Reward);
            GameManager.Instance.SaveSystem?.SaveGame();

            EventBus.Publish(new MissionUpdatedEvent("", "", false));
            EventBus.Publish(new ToastNotificationEvent($"Задание «{finished.Title}» выполнено! +${finished.Reward:N0}", 4f));
        }

        private void UpdateBeaconAndUI()
        {
            if (ActiveMission == null) return;
            var step = ActiveMission.Steps[CurrentStepIndex];
            if (_beacon != null) _beacon.ShowAt(step.TargetPosition);
            EventBus.Publish(new MissionUpdatedEvent(ActiveMission.Title, step.Description, true));
        }
    }
}
