using System;
using UnityEngine;

namespace SolaraCity.Missions
{
    public enum MissionType
    {
        Delivery,
        CheckpointDrive,
        Exploration
    }

    [Serializable]
    public class MissionStep
    {
        public string Description;
        public Vector3 TargetPosition;
        public float TriggerRadius = 5.5f;
    }

    [Serializable]
    public class MissionDefinition
    {
        public string Id;
        public string Title;
        public string Summary;
        public MissionType Type;
        public int Reward;
        public MissionStep[] Steps;
    }
}
