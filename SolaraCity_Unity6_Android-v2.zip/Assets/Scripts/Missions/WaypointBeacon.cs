using UnityEngine;
using SolaraCity.Core;

namespace SolaraCity.Missions
{
    /// <summary>
    /// High-visibility glowing 3D beacon indicating the active mission waypoint.
    /// </summary>
    public class WaypointBeacon : MonoBehaviour
    {
        private Transform _ring;
        private Transform _beam;

        public static WaypointBeacon Create()
        {
            var go = new GameObject("MissionWaypointBeacon");
            var beacon = go.AddComponent<WaypointBeacon>();

            var mat = MaterialFactory.CreateEmissive("Mat_Beacon", new Color(0.15f, 0.95f, 0.55f), new Color(0.15f, 1f, 0.55f), 2.2f);

            var ring = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            Destroy(ring.GetComponent<Collider>());
            ring.transform.SetParent(go.transform, false);
            ring.transform.localScale = new Vector3(4.2f, 0.12f, 4.2f);
            ring.GetComponent<Renderer>().sharedMaterial = mat;
            beacon._ring = ring.transform;

            var beam = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            Destroy(beam.GetComponent<Collider>());
            beam.transform.SetParent(go.transform, false);
            beam.transform.localPosition = new Vector3(0f, 18f, 0f);
            beam.transform.localScale = new Vector3(0.45f, 18f, 0.45f);
            beam.GetComponent<Renderer>().sharedMaterial = mat;
            beacon._beam = beam.transform;

            go.SetActive(false);
            return beacon;
        }

        private void Update()
        {
            if (_ring != null)
            {
                float pulse = 1f + Mathf.Sin(Time.time * 4f) * 0.12f;
                _ring.localScale = new Vector3(4.2f * pulse, 0.12f, 4.2f * pulse);
            }
            if (_beam != null)
            {
                _beam.Rotate(Vector3.up, 45f * Time.deltaTime);
            }
        }

        public void ShowAt(Vector3 position)
        {
            transform.position = new Vector3(position.x, 0.2f, position.z);
            gameObject.SetActive(true);
        }

        public void Hide()
        {
            gameObject.SetActive(false);
        }
    }
}
