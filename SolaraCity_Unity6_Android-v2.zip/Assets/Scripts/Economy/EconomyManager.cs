using System.Collections.Generic;
using UnityEngine;
using SolaraCity.Core;

namespace SolaraCity.Economy
{
    public class EconomyManager : MonoBehaviour
    {
        [SerializeField] private int startingCash = 5000;

        public int Balance { get; private set; }
        public HashSet<string> OwnedVehicles { get; } = new HashSet<string>();
        public HashSet<string> OwnedProperties { get; } = new HashSet<string>();

        private void Awake()
        {
            ResetToDefaults();
        }

        public void ResetToDefaults()
        {
            Balance = startingCash;
            OwnedVehicles.Clear();
            OwnedVehicles.Add("solara_compact");
            OwnedProperties.Clear();
            EventBus.Publish(new MoneyChangedEvent(Balance, 0));
        }

        public void LoadState(int balance, IEnumerable<string> vehicles, IEnumerable<string> properties)
        {
            Balance = Mathf.Max(0, balance);
            OwnedVehicles.Clear();
            OwnedVehicles.Add("solara_compact");
            if (vehicles != null)
                foreach (var v in vehicles) OwnedVehicles.Add(v);

            OwnedProperties.Clear();
            if (properties != null)
                foreach (var p in properties) OwnedProperties.Add(p);

            EventBus.Publish(new MoneyChangedEvent(Balance, 0));
        }

        public void AddMoney(int amount)
        {
            if (amount <= 0) return;
            Balance += amount;
            EventBus.Publish(new MoneyChangedEvent(Balance, amount));
        }

        public bool TrySpend(int amount)
        {
            if (amount < 0 || Balance < amount) return false;
            Balance -= amount;
            EventBus.Publish(new MoneyChangedEvent(Balance, -amount));
            return true;
        }

        public bool OwnsVehicle(string vehicleId) => OwnedVehicles.Contains(vehicleId);
        public bool OwnsProperty(string propertyId) => OwnedProperties.Contains(propertyId);

        public bool TryBuyVehicle(string vehicleId, int price)
        {
            if (OwnsVehicle(vehicleId)) return true;
            if (!TrySpend(price)) return false;
            OwnedVehicles.Add(vehicleId);
            return true;
        }

        public bool TryBuyProperty(string propertyId, int price)
        {
            if (OwnsProperty(propertyId)) return true;
            if (!TrySpend(price)) return false;
            OwnedProperties.Add(propertyId);
            return true;
        }
    }
}
