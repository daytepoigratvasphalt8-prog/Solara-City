using UnityEngine;

namespace SolaraCity.Core
{
    /// <summary>
    /// Creates URP-compatible PBR materials safely with fallback to Built-in Standard shader.
    /// Supports BaseMap, NormalMap, EmissionMap, tiling, smoothness, and metallic tuning for mobile GPUs.
    /// </summary>
    public static class MaterialFactory
    {
        private static Shader _cachedShader;

        private static Shader GetLitShader()
        {
            if (_cachedShader != null) return _cachedShader;
            _cachedShader = Shader.Find("Universal Render Pipeline/Lit");
            if (_cachedShader == null)
                _cachedShader = Shader.Find("Standard");
            if (_cachedShader == null)
                _cachedShader = Shader.Find("Sprites/Default");
            return _cachedShader;
        }

        public static Material CreateLit(string name, Color color, float smoothness = 0.25f, float metallic = 0f)
        {
            var mat = new Material(GetLitShader()) { name = name };
            if (mat.HasProperty("_BaseColor"))
                mat.SetColor("_BaseColor", color);
            if (mat.HasProperty("_Color"))
                mat.SetColor("_Color", color);
            if (mat.HasProperty("_Smoothness"))
                mat.SetFloat("_Smoothness", smoothness);
            if (mat.HasProperty("_Glossiness"))
                mat.SetFloat("_Glossiness", smoothness);
            if (mat.HasProperty("_Metallic"))
                mat.SetFloat("_Metallic", metallic);
            return mat;
        }

        public static Material CreateTexturedLit(
            string name,
            Color tint,
            Texture2D albedo,
            Texture2D normalMap = null,
            Vector2? tiling = null,
            float smoothness = 0.25f,
            float metallic = 0f,
            float bumpScale = 0.8f)
        {
            var mat = CreateLit(name, tint, smoothness, metallic);
            Vector2 scale = tiling ?? Vector2.one;

            if (albedo != null)
            {
                if (mat.HasProperty("_BaseMap"))
                {
                    mat.SetTexture("_BaseMap", albedo);
                    mat.SetTextureScale("_BaseMap", scale);
                }
                if (mat.HasProperty("_MainTex"))
                {
                    mat.SetTexture("_MainTex", albedo);
                    mat.SetTextureScale("_MainTex", scale);
                }
            }

            if (normalMap != null && mat.HasProperty("_BumpMap"))
            {
                mat.EnableKeyword("_NORMALMAP");
                mat.SetTexture("_BumpMap", normalMap);
                mat.SetTextureScale("_BumpMap", scale);
                if (mat.HasProperty("_BumpScale"))
                    mat.SetFloat("_BumpScale", bumpScale);
            }

            return mat;
        }

        public static Material CreateEmissive(string name, Color baseColor, Color emissionColor, float intensity = 2.0f)
        {
            var mat = CreateLit(name, baseColor, 0.4f, 0f);
            mat.EnableKeyword("_EMISSION");
            if (mat.HasProperty("_EmissionColor"))
                mat.SetColor("_EmissionColor", emissionColor * intensity);
            return mat;
        }

        public static void SetEmissionMap(Material mat, Texture2D emissionMap, Color color, float intensity, Vector2? tiling = null)
        {
            if (mat == null) return;
            mat.EnableKeyword("_EMISSION");
            if (emissionMap != null && mat.HasProperty("_EmissionMap"))
            {
                mat.SetTexture("_EmissionMap", emissionMap);
                if (tiling.HasValue)
                    mat.SetTextureScale("_EmissionMap", tiling.Value);
            }
            if (mat.HasProperty("_EmissionColor"))
                mat.SetColor("_EmissionColor", color * intensity);
        }
    }
}
