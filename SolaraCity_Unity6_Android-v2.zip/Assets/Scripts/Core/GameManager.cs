using UnityEngine;
using SolaraCity.Player;
using SolaraCity.Vehicles;
using SolaraCity.Economy;
using SolaraCity.Missions;
using SolaraCity.SaveSystem;
using SolaraCity.World;
using SolaraCity.Optimization;

namespace SolaraCity.Core
{
    public class GameManager : MonoBehaviour
    {
        public static GameManager Instance { get; private set; }

        public GameState CurrentState { get; private set; } = GameState.MainMenu;
        public VisualAssetCatalog VisualCatalog { get; set; }
        public PlayerController Player { get; set; }
        public ThirdPersonCamera MainCamera { get; set; }
        public VehicleController ActiveVehicle { get; private set; }
        public EconomyManager Economy { get; set; }
        public MissionManager Missions { get; set; }
        public SaveManager SaveSystem { get; set; }
        public DayNightCycle DayNight { get; set; }
        public MobileQualityController Quality { get; set; }
        public VehicleSpawner VehicleSpawner { get; set; }

        private GameState _stateBeforePause = GameState.PlayingOnFoot;

        private void Awake()
        {
            if (Instance != null && Instance != this)
            {
                Destroy(gameObject);
                return;
            }

            Instance = this;
            DontDestroyOnLoad(gameObject);
        }

        private void OnDestroy()
        {
            if (Instance == this)
            {
                EventBus.Clear();
                Instance = null;
            }
        }

        public void SetState(GameState newState)
        {
            if (CurrentState == newState) return;
            var prev = CurrentState;
            CurrentState = newState;

            Time.timeScale = (newState == GameState.Paused || newState == GameState.MainMenu) ? 0f : 1f;
            EventBus.Publish(new GameStateChangedEvent(prev, newState));
        }

        public void StartNewGame()
        {
            SaveSystem?.DeleteSave();
            Economy?.ResetToDefaults();
            Missions?.ResetMissions();
            if (Player != null)
            {
                Player.TeleportTo(new Vector3(0f, 1.2f, -12f));
                Player.Stats.ResetStats();
            }
            if (ActiveVehicle != null)
            {
                ExitCurrentVehicle();
            }
            SetState(GameState.PlayingOnFoot);
            EventBus.Publish(new ToastNotificationEvent("Добро пожаловать в Solara City!"));
        }

        public void ContinueOrStartGame()
        {
            if (SaveSystem != null && SaveSystem.HasSaveFile())
            {
                SaveSystem.LoadGame();
                EventBus.Publish(new ToastNotificationEvent("Прогресс загружен"));
            }
            else
            {
                Economy?.ResetToDefaults();
                EventBus.Publish(new ToastNotificationEvent("Добро пожаловать в Solara City!"));
            }

            SetState(GameState.PlayingOnFoot);
        }

        public void TogglePause()
        {
            if (CurrentState == GameState.Paused)
            {
                SetState(_stateBeforePause);
            }
            else if (CurrentState == GameState.PlayingOnFoot || CurrentState == GameState.PlayingInVehicle)
            {
                _stateBeforePause = CurrentState;
                SetState(GameState.Paused);
            }
        }

        public void OpenMenuOverlay()
        {
            if (CurrentState == GameState.PlayingOnFoot || CurrentState == GameState.PlayingInVehicle)
            {
                _stateBeforePause = CurrentState;
                SetState(GameState.InMenuOverlay);
            }
        }

        public void CloseMenuOverlay()
        {
            if (CurrentState == GameState.InMenuOverlay)
            {
                SetState(_stateBeforePause);
            }
        }

        public void EnterVehicle(VehicleController vehicle)
        {
            if (vehicle == null || Player == null || ActiveVehicle != null) return;

            ActiveVehicle = vehicle;
            Player.SetInVehicleState(true, vehicle.transform, vehicle.DriverSeatAnchor);
            vehicle.SetDriverActive(true);

            if (MainCamera != null)
                MainCamera.SetVehicleTarget(vehicle.transform, vehicle.CameraProfile);

            SetState(GameState.PlayingInVehicle);
            EventBus.Publish(new InteractablePromptEvent(false));
            EventBus.Publish(new ToastNotificationEvent($"За рулём: {vehicle.DisplayName}", 2f));
        }

        public void ExitCurrentVehicle()
        {
            if (ActiveVehicle == null || Player == null) return;

            Vector3 exitPos = ActiveVehicle.GetSafeExitPosition();
            ActiveVehicle.SetDriverActive(false);
            ActiveVehicle = null;

            Player.SetInVehicleState(false, null, null);
            Player.TeleportTo(exitPos);

            if (MainCamera != null)
                MainCamera.SetPlayerTarget(Player.CameraPivot);

            SetState(GameState.PlayingOnFoot);
        }

        public void ReturnToMainMenu()
        {
            SaveSystem?.SaveGame();
            if (ActiveVehicle != null)
                ExitCurrentVehicle();
            SetState(GameState.MainMenu);
        }
    }
}
