using System;
using System.Collections.Generic;

namespace SolaraCity.Core
{
    /// <summary>
    /// Lightweight decoupled publish-subscribe bus for cross-system communication.
    /// Avoids tight coupling between UI, Missions, Economy, Vehicles, and Player.
    /// </summary>
    public static class EventBus
    {
        private static readonly Dictionary<Type, Delegate> Handlers = new Dictionary<Type, Delegate>();

        public static void Subscribe<T>(Action<T> handler)
        {
            var type = typeof(T);
            if (Handlers.TryGetValue(type, out var existing))
                Handlers[type] = Delegate.Combine(existing, handler);
            else
                Handlers[type] = handler;
        }

        public static void Unsubscribe<T>(Action<T> handler)
        {
            var type = typeof(T);
            if (!Handlers.TryGetValue(type, out var existing)) return;
            var current = Delegate.Remove(existing, handler);
            if (current == null)
                Handlers.Remove(type);
            else
                Handlers[type] = current;
        }

        public static void Publish<T>(T evt)
        {
            if (Handlers.TryGetValue(typeof(T), out var existing) && existing is Action<T> action)
                action.Invoke(evt);
        }

        public static void Clear()
        {
            Handlers.Clear();
        }
    }

    public readonly struct GameStateChangedEvent
    {
        public readonly GameState Previous;
        public readonly GameState Current;

        public GameStateChangedEvent(GameState previous, GameState current)
        {
            Previous = previous;
            Current = current;
        }
    }

    public readonly struct MoneyChangedEvent
    {
        public readonly int NewBalance;
        public readonly int Delta;

        public MoneyChangedEvent(int newBalance, int delta)
        {
            NewBalance = newBalance;
            Delta = delta;
        }
    }

    public readonly struct HealthChangedEvent
    {
        public readonly float Current;
        public readonly float Max;

        public HealthChangedEvent(float current, float max)
        {
            Current = current;
            Max = max;
        }
    }

    public readonly struct ToastNotificationEvent
    {
        public readonly string Message;
        public readonly float Duration;

        public ToastNotificationEvent(string message, float duration = 3.0f)
        {
            Message = message;
            Duration = duration;
        }
    }

    public readonly struct InteractablePromptEvent
    {
        public readonly bool Visible;
        public readonly string Label;

        public InteractablePromptEvent(bool visible, string label = "")
        {
            Visible = visible;
            Label = label;
        }
    }

    public readonly struct MissionUpdatedEvent
    {
        public readonly string Title;
        public readonly string ObjectiveText;
        public readonly bool IsActive;

        public MissionUpdatedEvent(string title, string objectiveText, bool isActive)
        {
            Title = title;
            ObjectiveText = objectiveText;
            IsActive = isActive;
        }
    }
}
