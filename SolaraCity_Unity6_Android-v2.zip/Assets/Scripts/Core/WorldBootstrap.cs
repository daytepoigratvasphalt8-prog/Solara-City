using UnityEngine;
using SolaraCity.Player;
using SolaraCity.Vehicles;
using SolaraCity.World;
using SolaraCity.Economy;
using SolaraCity.Missions;
using SolaraCity.SaveSystem;
using SolaraCity.UI;
using SolaraCity.Optimization;

namespace SolaraCity.Core
{
    /// <summary>
    /// Initializes District 01, VisualAssetCatalog, ReflectionRig, Player, Vehicles, and Mobile UI
    /// cleanly on startup without broken scene links.
    /// </summary>
    public class WorldBootstrap : MonoBehaviour
    {
        [SerializeField] private bool startInMainMenu = true;
        [SerializeField] private VisualAssetCatalog visualCatalog;

        private void Awake()
        {
            InitializeSystems();
        }

        private void InitializeSystems()
        {
            if (visualCatalog == null)
                visualCatalog = Resources.Load<VisualAssetCatalog>("SolaraVisualCatalog");

            var gm = FindFirstObjectByType<GameManager>();
            if (gm == null)
            {
                var gmObj = new GameObject("GameManager");
                gm = gmObj.AddComponent<GameManager>();
            }
            gm.VisualCatalog = visualCatalog;

            var quality = FindFirstObjectByType<MobileQualityController>();
            if (quality == null)
                quality = new GameObject("MobileQualityController").AddComponent<MobileQualityController>();
            gm.Quality = quality;

            var economy = FindFirstObjectByType<EconomyManager>();
            if (economy == null)
                economy = new GameObject("EconomyManager").AddComponent<EconomyManager>();
            gm.Economy = economy;

            var spawner = FindFirstObjectByType<VehicleSpawner>();
            if (spawner == null)
                spawner = new GameObject("VehicleSpawner").AddComponent<VehicleSpawner>();
            spawner.VisualCatalog = visualCatalog;
            gm.VehicleSpawner = spawner;

            var dayNight = FindFirstObjectByType<DayNightCycle>();
            if (dayNight == null)
                dayNight = new GameObject("DayNightCycle").AddComponent<DayNightCycle>();
            gm.DayNight = dayNight;

            var district = FindFirstObjectByType<DistrictBuilder>();
            if (district == null)
            {
                district = new GameObject("SolaraDistrict01").AddComponent<DistrictBuilder>();
                district.VisualCatalog = visualCatalog;
                district.BuildDistrict(dayNight);
            }

            // Mobile-safe ReflectionProbe rig for car paint & skyscraper glass
            if (visualCatalog == null || visualCatalog.EnableEnvironmentReflections)
            {
                var reflRig = FindFirstObjectByType<EnvironmentReflectionRig>();
                if (reflRig == null)
                {
                    reflRig = new GameObject("EnvironmentReflectionRig").AddComponent<EnvironmentReflectionRig>();
                    reflRig.Initialize();
                }
                dayNight.SetReflectionRig(reflRig);
            }

            var player = FindFirstObjectByType<PlayerController>();
            if (player == null)
                player = PlayerFactory.CreatePlayer(new Vector3(0f, 1.2f, -12f), visualCatalog);
            gm.Player = player;

            var mainCam = Camera.main;
            if (mainCam == null)
            {
                var camObj = new GameObject("Main Camera");
                camObj.tag = "MainCamera";
                mainCam = camObj.AddComponent<Camera>();
                camObj.AddComponent<AudioListener>();
            }
            mainCam.farClipPlane = 450f;
            mainCam.nearClipPlane = 0.2f;
            var tpsCam = mainCam.GetComponent<ThirdPersonCamera>();
            if (tpsCam == null)
                tpsCam = mainCam.gameObject.AddComponent<ThirdPersonCamera>();
            tpsCam.SetPlayerTarget(player.CameraPivot);
            gm.MainCamera = tpsCam;

            if (FindObjectsByType<VehicleController>(FindObjectsSortMode.None).Length == 0)
                spawner.SpawnInitialFleet();

            var missions = FindFirstObjectByType<MissionManager>();
            if (missions == null)
                missions = new GameObject("MissionManager").AddComponent<MissionManager>();
            gm.Missions = missions;

            var saveManager = FindFirstObjectByType<SaveManager>();
            if (saveManager == null)
                saveManager = new GameObject("SaveManager").AddComponent<SaveManager>();
            gm.SaveSystem = saveManager;

            var minimap = FindFirstObjectByType<MinimapController>();
            if (minimap == null)
                minimap = new GameObject("MinimapSystem").AddComponent<MinimapController>();
            minimap.Initialize(player.transform);

            var uiFactory = FindFirstObjectByType<RuntimeUIFactory>();
            if (uiFactory == null)
            {
                uiFactory = new GameObject("MobileUIRoot").AddComponent<RuntimeUIFactory>();
                uiFactory.BuildUI(minimap.RenderTexture);
            }

            gm.SetState(startInMainMenu ? GameState.MainMenu : GameState.PlayingOnFoot);
        }
    }
}
