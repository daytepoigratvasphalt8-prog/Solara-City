using System.Collections.Generic;
using UnityEngine;

namespace SolaraCity.Core
{
    /// <summary>
    /// Generates lightweight, cached procedural Albedo, Normal, and Emission maps (256x256)
    /// to elevate visual clarity of temporary geometry on mobile GPUs without bloating APK size.
    /// Automatically bypassed when final artist textures/prefabs are assigned.
    /// </summary>
    public static class ProceduralTextureGenerator
    {
        private static readonly Dictionary<string, Texture2D> Cache = new Dictionary<string, Texture2D>();

        public static Texture2D GetAsphaltAlbedo()
        {
            return GetOrCreate("asphalt_albedo", 256, (x, y, s) =>
            {
                float n1 = HashNoise(x, y, 17);
                float n2 = HashNoise(x / 2, y / 2, 53);
                float v = 0.145f + n1 * 0.045f + n2 * 0.025f;
                return new Color(v, v * 1.02f, v * 1.08f, 1f);
            });
        }

        public static Texture2D GetAsphaltNormal()
        {
            return GetOrCreateNormal("asphalt_normal", 256, 0.35f, (x, y) =>
                HashNoise(x, y, 17) * 0.6f + HashNoise(x / 2, y / 2, 53) * 0.4f);
        }

        public static Texture2D GetSidewalkAlbedo()
        {
            return GetOrCreate("sidewalk_albedo", 256, (x, y, s) =>
            {
                bool seamX = (x % 64) < 2;
                bool seamY = (y % 64) < 2;
                float grit = HashNoise(x, y, 31) * 0.045f;
                float baseVal = (seamX || seamY) ? 0.42f : (0.61f + grit);
                return new Color(baseVal, baseVal * 1.01f, baseVal * 1.02f, 1f);
            });
        }

        public static Texture2D GetSidewalkNormal()
        {
            return GetOrCreateNormal("sidewalk_normal", 256, 0.45f, (x, y) =>
            {
                bool seam = (x % 64) < 2 || (y % 64) < 2;
                return seam ? 0.15f : 0.85f + HashNoise(x, y, 31) * 0.12f;
            });
        }

        public static Texture2D GetGrassAlbedo()
        {
            return GetOrCreate("grass_albedo", 256, (x, y, s) =>
            {
                float fine = HashNoise(x, y, 91);
                float patch = Mathf.PerlinNoise(x * 0.045f, y * 0.045f);
                float r = 0.17f + patch * 0.09f + fine * 0.03f;
                float g = 0.38f + patch * 0.15f + fine * 0.05f;
                float b = 0.16f + patch * 0.06f + fine * 0.02f;
                return new Color(r, g, b, 1f);
            });
        }

        public static Texture2D GetSkyscraperFacadeAlbedo()
        {
            return GetOrCreate("skyscraper_albedo", 256, (x, y, s) =>
            {
                int gx = x % 32;
                int gy = y % 32;
                bool mullion = gx < 4 || gy < 6;
                if (mullion)
                    return new Color(0.28f, 0.31f, 0.36f, 1f);

                float variation = HashNoise(x / 32, y / 32, 71) * 0.10f;
                float verticalGrad = (gy - 6) / 26f * 0.08f;
                return new Color(0.14f + variation * 0.5f, 0.24f + variation + verticalGrad, 0.36f + variation + verticalGrad, 1f);
            });
        }

        public static Texture2D GetSkyscraperWindowEmission()
        {
            return GetOrCreate("skyscraper_emission", 256, (x, y, s) =>
            {
                int gx = x % 32;
                int gy = y % 32;
                if (gx < 5 || gx > 27 || gy < 7 || gy > 27)
                    return Color.black;

                float roomRoll = HashNoise(x / 32, y / 32, 137);
                if (roomRoll < 0.55f)
                    return Color.black;

                bool warm = HashNoise(x / 32, y / 32, 211) > 0.38f;
                return warm
                    ? new Color(1.0f, 0.84f, 0.54f, 1f)
                    : new Color(0.65f, 0.86f, 1.0f, 1f);
            });
        }

        public static Texture2D GetResidentialFacadeAlbedo(Color wallTint)
        {
            string key = $"res_{ColorUtility.ToHtmlStringRGB(wallTint)}";
            return GetOrCreate(key, 256, (x, y, s) =>
            {
                int gx = x % 64;
                int gy = y % 64;
                bool isWindow = gx >= 14 && gx <= 48 && gy >= 18 && gy <= 48;
                if (isWindow)
                {
                    bool frame = gx < 17 || gx > 45 || gy < 21 || gy > 45 || (gx >= 30 && gx <= 32);
                    if (frame) return new Color(0.24f, 0.25f, 0.27f, 1f);
                    return new Color(0.16f, 0.22f, 0.28f, 1f);
                }

                float plaster = (HashNoise(x, y, 47) - 0.5f) * 0.05f;
                bool floorLedge = gy < 4;
                float mult = floorLedge ? 0.84f : 1f;
                return new Color(
                    Mathf.Clamp01(wallTint.r * mult + plaster),
                    Mathf.Clamp01(wallTint.g * mult + plaster),
                    Mathf.Clamp01(wallTint.b * mult + plaster),
                    1f);
            });
        }

        public static Texture2D GetIndustrialMetalAlbedo()
        {
            return GetOrCreate("industrial_albedo", 256, (x, y, s) =>
            {
                float rib = Mathf.Sin(x * 0.45f) * 0.045f;
                float wear = HashNoise(x, y, 103) * 0.03f;
                float v = 0.39f + rib + wear;
                return new Color(v, v * 1.04f, v * 1.08f, 1f);
            });
        }

        public static Texture2D GetIndustrialMetalNormal()
        {
            return GetOrCreateNormal("industrial_normal", 256, 0.55f, (x, y) =>
                0.5f + 0.45f * Mathf.Sin(x * 0.45f));
        }

        private static Texture2D GetOrCreate(string key, int size, System.Func<int, int, int, Color> pixelFunc)
        {
            if (Cache.TryGetValue(key, out var existing) && existing != null)
                return existing;

            var tex = new Texture2D(size, size, TextureFormat.RGBA32, true)
            {
                name = $"ProcTex_{key}",
                wrapMode = TextureWrapMode.Repeat,
                filterMode = FilterMode.Trilinear,
                anisoLevel = 4
            };

            var pixels = new Color[size * size];
            for (int y = 0; y < size; y++)
                for (int x = 0; x < size; x++)
                    pixels[y * size + x] = pixelFunc(x, y, size);

            tex.SetPixels(pixels);
            tex.Apply(true, true); // makeNoLongerReadable=true saves 50% RAM on Android
            Cache[key] = tex;
            return tex;
        }

        private static Texture2D GetOrCreateNormal(string key, int size, float strength, System.Func<int, int, float> heightFunc)
        {
            if (Cache.TryGetValue(key, out var existing) && existing != null)
                return existing;

            var tex = new Texture2D(size, size, TextureFormat.RGBA32, true, true)
            {
                name = $"ProcNorm_{key}",
                wrapMode = TextureWrapMode.Repeat,
                filterMode = FilterMode.Bilinear,
                anisoLevel = 2
            };

            var pixels = new Color[size * size];
            for (int y = 0; y < size; y++)
            {
                for (int x = 0; x < size; x++)
                {
                    float hL = heightFunc((x - 1 + size) % size, y);
                    float hR = heightFunc((x + 1) % size, y);
                    float hD = heightFunc(x, (y - 1 + size) % size);
                    float hU = heightFunc(x, (y + 1) % size);

                    Vector3 n = new Vector3((hL - hR) * strength, (hD - hU) * strength, 1f).normalized;
                    pixels[y * size + x] = new Color(n.x * 0.5f + 0.5f, n.y * 0.5f + 0.5f, n.z * 0.5f + 0.5f, 1f);
                }
            }

            tex.SetPixels(pixels);
            tex.Apply(true, true);
            Cache[key] = tex;
            return tex;
        }

        private static float HashNoise(int x, int y, int seed)
        {
            int n = x * 374761393 + y * 668265263 + seed * 1442695041;
            n = (n ^ (n >> 13)) * 1274126177;
            n ^= n >> 16;
            return (n & 0x7fffffff) / (float)0x7fffffff;
        }
    }
}
