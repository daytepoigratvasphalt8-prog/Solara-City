using System;
using UnityEngine;

namespace SolaraCity.Core
{
    [Serializable]
    public class VehiclePrefabOverride
    {
        public string VehicleId;
        public GameObject Prefab;
    }

    [Serializable]
    public class EnvironmentPrefabSet
    {
        public GameObject[] SkyscraperVariants;
        public GameObject[] ResidentialVariants;
        public GameObject TreePrefab;
        public GameObject StreetLampPrefab;
        public GameObject FountainPrefab;
        public GameObject DealershipPrefab;
        public GameObject FuelStationPrefab;
        public GameObject WarehousePrefab;
    }

    /// <summary>
    /// Central registry allowing seamless zero-code migration from temporary procedural geometry
    /// to production FBX/GLTF prefabs, Humanoid Rigs, and Animator Controllers.
    /// Any null slot automatically falls back to the built-in procedural representation.
    /// </summary>
    [CreateAssetMenu(fileName = "SolaraVisualCatalog", menuName = "SolaraCity/Visual Asset Catalog")]
    public class VisualAssetCatalog : ScriptableObject
    {
        [Header("Player Character (Humanoid Rig)")]
        public GameObject PlayerHumanoidPrefab;
        public RuntimeAnimatorController PlayerAnimatorController;

        [Header("Detailed Vehicle Prefabs")]
        public VehiclePrefabOverride[] VehicleOverrides = Array.Empty<VehiclePrefabOverride>();

        [Header("Modular City & Environment Prefabs")]
        public EnvironmentPrefabSet Environment = new EnvironmentPrefabSet();

        [Header("Android Rendering & Material Options")]
        public bool UseProceduralPBRTextures = true;
        public bool EnableEnvironmentReflections = true;
        public bool AttachAutomaticLODGroups = true;

        public GameObject GetVehiclePrefab(string vehicleId)
        {
            if (VehicleOverrides == null) return null;
            foreach (var entry in VehicleOverrides)
            {
                if (entry != null && entry.VehicleId == vehicleId && entry.Prefab != null)
                    return entry.Prefab;
            }
            return null;
        }
    }
}
