namespace SolaraCity.Core
{
    public enum GameState
    {
        MainMenu,
        PlayingOnFoot,
        PlayingInVehicle,
        Paused,
        InMenuOverlay
    }
}
