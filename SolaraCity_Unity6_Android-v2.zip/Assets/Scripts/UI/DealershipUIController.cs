using UnityEngine;
using UnityEngine.UI;
using SolaraCity.Core;
using SolaraCity.Vehicles;

namespace SolaraCity.UI
{
    public class DealershipUIController : MonoBehaviour
    {
        public GameObject PanelRoot;
        public Transform ListContainer;
        public Text BalanceHeader;

        private Vector3 _spawnPoint;

        public void Open(Vector3 deliverySpawnPoint)
        {
            _spawnPoint = deliverySpawnPoint;
            if (PanelRoot != null) PanelRoot.SetActive(true);
            GameManager.Instance?.OpenMenuOverlay();
            RefreshList();
        }

        public void Close()
        {
            if (PanelRoot != null) PanelRoot.SetActive(false);
            GameManager.Instance?.CloseMenuOverlay();
        }

        private void RefreshList()
        {
            if (ListContainer == null || GameManager.Instance == null) return;
            var econ = GameManager.Instance.Economy;
            if (BalanceHeader != null && econ != null)
                BalanceHeader.text = $"SOLARA MOTORS  |  Баланс: $ {econ.Balance:N0}";

            for (int i = ListContainer.childCount - 1; i >= 0; i--)
                Destroy(ListContainer.GetChild(i).gameObject);

            foreach (var spec in VehicleCatalog.AllVehicles)
            {
                bool owned = econ != null && econ.OwnsVehicle(spec.Id);
                string btnLabel = owned ? "Вызвать на парковку" : $"Купить (${spec.Price:N0})";
                string desc = $"{spec.DisplayName} ({spec.Category}) — до {spec.MaxSpeedKmh:0} км/ч";

                RuntimeUIFactory.CreateShopRow(ListContainer, desc, btnLabel, () =>
                {
                    if (owned)
                    {
                        GameManager.Instance.VehicleSpawner.SpawnVehicle(spec, _spawnPoint, Quaternion.identity);
                        EventBus.Publish(new ToastNotificationEvent($"{spec.DisplayName} доставлен на площадку!"));
                        Close();
                    }
                    else if (econ.TryBuyVehicle(spec.Id, spec.Price))
                    {
                        GameManager.Instance.VehicleSpawner.SpawnVehicle(spec, _spawnPoint, Quaternion.identity);
                        GameManager.Instance.SaveSystem?.SaveGame();
                        EventBus.Publish(new ToastNotificationEvent($"Куплен {spec.DisplayName}!"));
                        RefreshList();
                    }
                    else
                    {
                        EventBus.Publish(new ToastNotificationEvent("Недостаточно средств!"));
                    }
                });
            }
        }
    }
}
