using UnityEngine;
using SolaraCity.Core;

namespace SolaraCity.UI
{
    public class MissionListUI : MonoBehaviour
    {
        public GameObject PanelRoot;
        public Transform ListContainer;

        public void Open()
        {
            if (PanelRoot != null) PanelRoot.SetActive(true);
            GameManager.Instance?.OpenMenuOverlay();
            Refresh();
        }

        public void Close()
        {
            if (PanelRoot != null) PanelRoot.SetActive(false);
            GameManager.Instance?.CloseMenuOverlay();
        }

        private void Refresh()
        {
            if (ListContainer == null || GameManager.Instance?.Missions == null) return;
            var mm = GameManager.Instance.Missions;

            for (int i = ListContainer.childCount - 1; i >= 0; i--)
                Destroy(ListContainer.GetChild(i).gameObject);

            foreach (var m in mm.AvailableMissions)
            {
                bool active = mm.ActiveMission != null && mm.ActiveMission.Id == m.Id;
                bool done = mm.CompletedMissionIds.Contains(m.Id);
                string status = active ? "Отменить" : (done ? "Повторить" : "Начать");
                string info = $"{m.Title} (+${m.Reward:N0})
{m.Summary}";

                var missionId = m.Id;
                RuntimeUIFactory.CreateShopRow(ListContainer, info, status, () =>
                {
                    if (active)
                        mm.CancelActiveMission();
                    else
                        mm.StartMission(missionId);
                    Close();
                });
            }
        }
    }
}
