using UnityEngine;

namespace SolaraCity.UI
{
    /// <summary>
    /// Adapts HUD panels to Android screen cutouts, notches, and varying aspect ratios.
    /// </summary>
    [RequireComponent(typeof(RectTransform))]
    public class SafeAreaFitter : MonoBehaviour
    {
        private RectTransform _rect;
        private Rect _lastSafeArea;

        private void Awake()
        {
            _rect = GetComponent<RectTransform>();
            ApplySafeArea();
        }

        private void Update()
        {
            if (Screen.safeArea != _lastSafeArea)
                ApplySafeArea();
        }

        private void ApplySafeArea()
        {
            Rect safe = Screen.safeArea;
            _lastSafeArea = safe;

            if (Screen.width <= 0 || Screen.height <= 0) return;

            Vector2 anchorMin = safe.position;
            Vector2 anchorMax = safe.position + safe.size;
            anchorMin.x /= Screen.width;
            anchorMin.y /= Screen.height;
            anchorMax.x /= Screen.width;
            anchorMax.y /= Screen.height;

            _rect.anchorMin = anchorMin;
            _rect.anchorMax = anchorMax;
        }
    }
}
