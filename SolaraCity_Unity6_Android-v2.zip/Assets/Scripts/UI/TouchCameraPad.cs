using UnityEngine;
using UnityEngine.EventSystems;
using SolaraCity.Core;

namespace SolaraCity.UI
{
    public class TouchCameraPad : MonoBehaviour, IDragHandler
    {
        public void OnDrag(PointerEventData eventData)
        {
            var player = GameManager.Instance?.Player;
            if (player != null && player.InputHandler != null)
                player.InputHandler.AddMobileLook(eventData.delta);
        }
    }
}
