using System;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using SolaraCity.Core;
using SolaraCity.Optimization;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem.UI;
#endif

namespace SolaraCity.UI
{
    /// <summary>
    /// Constructs a responsive, modern dark-glass mobile UI hierarchy for all Android resolutions.
    /// Guarantees zero broken prefab links on fresh import.
    /// </summary>
    public class RuntimeUIFactory : MonoBehaviour
    {
        private static Font _font;

        private static Font GetFont()
        {
            if (_font != null) return _font;
            _font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            if (_font == null)
                _font = Resources.GetBuiltinResource<Font>("Arial.ttf");
            return _font;
        }

        public void BuildUI(RenderTexture minimapRT)
        {
            EnsureEventSystem();

            var canvasObj = new GameObject("MobileCanvas");
            canvasObj.transform.SetParent(transform, false);
            var canvas = canvasObj.AddComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvas.sortingOrder = 10;

            var scaler = canvasObj.AddComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1920f, 1080f);
            scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
            scaler.matchWidthOrHeight = 0.5f;
            canvasObj.AddComponent<GraphicRaycaster>();

            var safeRoot = CreateRect("SafeAreaRoot", canvasObj.transform, Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero);
            safeRoot.gameObject.AddComponent<SafeAreaFitter>();

            var hud = gameObject.AddComponent<MobileHUDController>();

            // 1. Gameplay HUD Root
            var hudRoot = CreateRect("HUDRoot", safeRoot, Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero).gameObject;
            hud.HudRoot = hudRoot;

            // Touch Camera Look Zone (right half background)
            var lookPad = CreatePanel("TouchCameraPad", hudRoot.transform, new Vector2(0.38f, 0f), new Vector2(1f, 1f), Vector2.zero, Vector2.zero, new Color(0, 0, 0, 0));
            lookPad.gameObject.AddComponent<TouchCameraPad>();

            // Top-Left: Minimap
            var minimapFrame = CreatePanel("MinimapFrame", hudRoot.transform, new Vector2(0, 1), new Vector2(0, 1), new Vector2(28, -28), new Vector2(240, 240), new Color(0.08f, 0.10f, 0.14f, 0.88f), new Vector2(0, 1));
            var mapRawObj = new GameObject("MinimapImage");
            mapRawObj.transform.SetParent(minimapFrame, false);
            var mapRect = mapRawObj.AddComponent<RectTransform>();
            mapRect.anchorMin = Vector2.zero;
            mapRect.anchorMax = Vector2.one;
            mapRect.offsetMin = new Vector2(6, 6);
            mapRect.offsetMax = new Vector2(-6, -6);
            var rawImg = mapRawObj.AddComponent<RawImage>();
            rawImg.texture = minimapRT;
            CreateText("MinimapCenterDot", minimapFrame, "▲", 22, new Color(0.2f, 0.95f, 0.55f), TextAnchor.MiddleCenter);

            // Top-Right: Money, Health, Pause & Missions Buttons
            var statsPanel = CreatePanel("StatsPanel", hudRoot.transform, new Vector2(1, 1), new Vector2(1, 1), new Vector2(-28, -28), new Vector2(360, 118), new Color(0.08f, 0.10f, 0.14f, 0.82f), new Vector2(1, 1));
            hud.CashText = CreateTextAnchored("CashText", statsPanel, "$ 5,000", 34, new Color(0.32f, 0.94f, 0.52f), TextAnchor.MiddleRight, new Vector2(0, 0.48f), new Vector2(1, 1), new Vector2(16, 0), new Vector2(-18, -6));
            hud.HealthBar = CreateHealthSlider(statsPanel);

            var missionListUI = gameObject.AddComponent<MissionListUI>();

            var btnPause = CreateButton("PauseBtn", hudRoot.transform, "❚❚", new Vector2(1, 1), new Vector2(1, 1), new Vector2(-406, -28), new Vector2(78, 78), new Color(0.14f, 0.17f, 0.23f, 0.9f), () => GameManager.Instance?.TogglePause(), new Vector2(1, 1));
            CreateButton("MissionsBtn", hudRoot.transform, "ЗАДАНИЯ", new Vector2(1, 1), new Vector2(1, 1), new Vector2(-498, -28), new Vector2(175, 78), new Color(0.14f, 0.42f, 0.72f, 0.92f), () => missionListUI.Open(), new Vector2(1, 1));

            // Top-Center: Active Mission Tracker
            var missionBox = CreatePanel("MissionTracker", hudRoot.transform, new Vector2(0.5f, 1), new Vector2(0.5f, 1), new Vector2(0, -28), new Vector2(520, 96), new Color(0.08f, 0.11f, 0.16f, 0.85f), new Vector2(0.5f, 1));
            hud.MissionTrackerBox = missionBox.gameObject;
            hud.MissionTitleText = CreateTextAnchored("MTitle", missionBox, "", 24, new Color(0.28f, 0.85f, 1f), TextAnchor.MiddleCenter, new Vector2(0, 0.5f), new Vector2(1, 1), new Vector2(10, 0), new Vector2(-10, -4));
            hud.MissionObjectiveText = CreateTextAnchored("MObj", missionBox, "", 20, Color.white, TextAnchor.MiddleCenter, new Vector2(0, 0), new Vector2(1, 0.55f), new Vector2(10, 4), new Vector2(-10, 0));
            missionBox.gameObject.SetActive(false);

            // Toast Notification Banner
            var toastBox = CreatePanel("ToastBox", hudRoot.transform, new Vector2(0.5f, 1), new Vector2(0.5f, 1), new Vector2(0, -140), new Vector2(640, 62), new Color(0.09f, 0.12f, 0.18f, 0.92f), new Vector2(0.5f, 1));
            hud.ToastBox = toastBox.gameObject;
            hud.ToastText = CreateText("ToastText", toastBox, "", 24, Color.white, TextAnchor.MiddleCenter);
            toastBox.gameObject.SetActive(false);

            // Context Interact Button
            var interactBtn = CreateButton("InteractBtn", hudRoot.transform, "Взаимодействие", new Vector2(0.5f, 0), new Vector2(0.5f, 0), new Vector2(0, 185), new Vector2(380, 82), new Color(0.14f, 0.72f, 0.45f, 0.95f), () => GameManager.Instance?.Player?.InputHandler.TriggerMobileInteract(), new Vector2(0.5f, 0));
            hud.InteractButton = interactBtn;
            hud.InteractButtonText = interactBtn.GetComponentInChildren<Text>();
            interactBtn.gameObject.SetActive(false);

            // 2. On-Foot Controls
            var footRoot = CreateRect("OnFootControls", hudRoot.transform, Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero).gameObject;
            hud.OnFootControlsRoot = footRoot;
            CreateJoystick(footRoot.transform);

            var sprintBtn = CreateButton("SprintBtn", footRoot.transform, "БЕГ", new Vector2(1, 0), new Vector2(1, 0), new Vector2(-210, 65), new Vector2(130, 130), new Color(0.16f, 0.22f, 0.32f, 0.85f), null, new Vector2(1, 0));
            var sprintHold = sprintBtn.gameObject.AddComponent<HoldButton>();
            sprintHold.OnStateChanged = active => GameManager.Instance?.Player?.InputHandler.SetMobileSprint(active);

            CreateButton("JumpBtn", footRoot.transform, "ПРЫЖОК", new Vector2(1, 0), new Vector2(1, 0), new Vector2(-50, 65), new Vector2(140, 140), new Color(0.18f, 0.48f, 0.82f, 0.9f), () => GameManager.Instance?.Player?.InputHandler.TriggerMobileJump(), new Vector2(1, 0));

            // 3. Vehicle Controls
            var vehRoot = CreateRect("VehicleControls", hudRoot.transform, Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero).gameObject;
            hud.VehicleControlsRoot = vehRoot;

            var speedBox = CreatePanel("SpeedBox", vehRoot.transform, new Vector2(0.5f, 0), new Vector2(0.5f, 0), new Vector2(0, 36), new Vector2(400, 68), new Color(0.07f, 0.09f, 0.13f, 0.88f), new Vector2(0.5f, 0));
            hud.SpeedText = CreateText("SpeedText", speedBox, "0 KM/H", 28, new Color(0.28f, 0.92f, 1f), TextAnchor.MiddleCenter);

            var leftBtn = CreateButton("SteerLeft", vehRoot.transform, "◀", new Vector2(0, 0), new Vector2(0, 0), new Vector2(55, 65), new Vector2(150, 135), new Color(0.14f, 0.17f, 0.23f, 0.88f), null, new Vector2(0, 0));
            leftBtn.gameObject.AddComponent<HoldButton>().OnStateChanged = p => GameManager.Instance?.Player?.InputHandler.SetTouchSteerLeft(p);

            var rightBtn = CreateButton("SteerRight", vehRoot.transform, "▶", new Vector2(0, 0), new Vector2(0, 0), new Vector2(225, 65), new Vector2(150, 135), new Color(0.14f, 0.17f, 0.23f, 0.88f), null, new Vector2(0, 0));
            rightBtn.gameObject.AddComponent<HoldButton>().OnStateChanged = p => GameManager.Instance?.Player?.InputHandler.SetTouchSteerRight(p);

            var brakeBtn = CreateButton("BrakeBtn", vehRoot.transform, "ТОРМОЗ", new Vector2(1, 0), new Vector2(1, 0), new Vector2(-235, 65), new Vector2(155, 135), new Color(0.76f, 0.18f, 0.20f, 0.9f), null, new Vector2(1, 0));
            brakeBtn.gameObject.AddComponent<HoldButton>().OnStateChanged = p => GameManager.Instance?.Player?.InputHandler.SetTouchBrake(p);

            var gasBtn = CreateButton("GasBtn", vehRoot.transform, "ГАЗ", new Vector2(1, 0), new Vector2(1, 0), new Vector2(-55, 65), new Vector2(160, 175), new Color(0.14f, 0.68f, 0.36f, 0.92f), null, new Vector2(1, 0));
            gasBtn.gameObject.AddComponent<HoldButton>().OnStateChanged = p => GameManager.Instance?.Player?.InputHandler.SetTouchGas(p);

            CreateButton("ExitVehBtn", vehRoot.transform, "ВЫЙТИ ИЗ АВТО", new Vector2(1, 0), new Vector2(1, 0), new Vector2(-55, 265), new Vector2(240, 74), new Color(0.22f, 0.26f, 0.34f, 0.92f), () => GameManager.Instance?.ExitCurrentVehicle(), new Vector2(1, 0));

            // 4. Menus: Main Menu, Pause, Settings, Dealership, Missions
            hud.SettingsMenuRoot = BuildSettingsMenu(safeRoot);
            hud.MainMenuRoot = BuildMainMenu(safeRoot, hud.SettingsMenuRoot);
            hud.PauseMenuRoot = BuildPauseMenu(safeRoot, hud.SettingsMenuRoot, missionListUI);
            BuildDealershipPanel(safeRoot);
            BuildMissionsPanel(safeRoot, missionListUI);
            hud.MissionsPanelRoot = missionListUI.PanelRoot;
        }

        private GameObject BuildMainMenu(Transform parent, GameObject settingsPanel)
        {
            var root = CreatePanel("MainMenu", parent, Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero, new Color(0.05f, 0.07f, 0.11f, 0.94f));
            CreateTextAnchored("Title", root, "SOLARA CITY", 86, new Color(0.25f, 0.88f, 1f), TextAnchor.MiddleCenter, new Vector2(0.1f, 0.72f), new Vector2(0.9f, 0.92f), Vector2.zero, Vector2.zero);
            CreateTextAnchored("Subtitle", root, "OPEN WORLD EDITION  •  DISTRICT 01", 26, new Color(0.75f, 0.80f, 0.88f), TextAnchor.MiddleCenter, new Vector2(0.1f, 0.65f), new Vector2(0.9f, 0.74f), Vector2.zero, Vector2.zero);

            CreateButton("ContinueBtn", root, "ИГРАТЬ / ПРОДОЛЖИТЬ", new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(0, 40), new Vector2(460, 86), new Color(0.14f, 0.62f, 0.88f, 1f), () => GameManager.Instance?.ContinueOrStartGame(), new Vector2(0.5f, 0.5f));
            CreateButton("NewGameBtn", root, "НОВАЯ ИГРА", new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(0, -64), new Vector2(460, 78), new Color(0.18f, 0.22f, 0.30f, 1f), () => GameManager.Instance?.StartNewGame(), new Vector2(0.5f, 0.5f));
            CreateButton("SettingsBtn", root, "НАСТРОЙКИ", new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(0, -160), new Vector2(460, 78), new Color(0.18f, 0.22f, 0.30f, 1f), () => settingsPanel.SetActive(true), new Vector2(0.5f, 0.5f));
            CreateButton("QuitBtn", root, "ВЫХОД", new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(0, -256), new Vector2(460, 72), new Color(0.55f, 0.16f, 0.20f, 1f), () => Application.Quit(), new Vector2(0.5f, 0.5f));

            return root.gameObject;
        }

        private GameObject BuildPauseMenu(Transform parent, GameObject settingsPanel, MissionListUI missionUI)
        {
            var root = CreatePanel("PauseMenu", parent, Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero, new Color(0.04f, 0.06f, 0.10f, 0.85f));
            CreateTextAnchored("PauseTitle", root, "ПАУЗА", 64, Color.white, TextAnchor.MiddleCenter, new Vector2(0.2f, 0.72f), new Vector2(0.8f, 0.88f), Vector2.zero, Vector2.zero);

            CreateButton("ResumeBtn", root, "ПРОДОЛЖИТЬ", new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(0, 70), new Vector2(420, 78), new Color(0.14f, 0.65f, 0.42f, 1f), () => GameManager.Instance?.TogglePause(), new Vector2(0.5f, 0.5f));
            CreateButton("SaveBtn", root, "СОХРАНИТЬ ПРОГРЕСС", new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(0, -24), new Vector2(420, 74), new Color(0.18f, 0.42f, 0.72f, 1f), () =>
            {
                GameManager.Instance?.SaveSystem?.SaveGame();
                EventBus.Publish(new ToastNotificationEvent("Игра сохранена!"));
            }, new Vector2(0.5f, 0.5f));
            CreateButton("PauseSettingsBtn", root, "НАСТРОЙКИ", new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(0, -116), new Vector2(420, 74), new Color(0.20f, 0.24f, 0.32f, 1f), () => settingsPanel.SetActive(true), new Vector2(0.5f, 0.5f));
            CreateButton("ToMainMenuBtn", root, "ГЛАВНОЕ МЕНЮ", new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(0, -208), new Vector2(420, 74), new Color(0.55f, 0.18f, 0.22f, 1f), () => GameManager.Instance?.ReturnToMainMenu(), new Vector2(0.5f, 0.5f));

            root.gameObject.SetActive(false);
            return root.gameObject;
        }

        private GameObject BuildSettingsMenu(Transform parent)
        {
            var root = CreatePanel("SettingsMenu", parent, Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero, new Color(0.04f, 0.06f, 0.10f, 0.94f));
            var card = CreatePanel("SettingsCard", root, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(740, 560), new Color(0.10f, 0.13f, 0.19f, 1f), new Vector2(0.5f, 0.5f));

            CreateTextAnchored("Title", card, "НАСТРОЙКИ ГРАФИКИ И УПРАВЛЕНИЯ", 32, new Color(0.28f, 0.88f, 1f), TextAnchor.MiddleCenter, new Vector2(0, 0.82f), new Vector2(1, 0.98f), Vector2.zero, Vector2.zero);
            CreateTextAnchored("QualLabel", card, "Качество графики (URP Android):", 24, Color.white, TextAnchor.MiddleCenter, new Vector2(0, 0.66f), new Vector2(1, 0.78f), Vector2.zero, Vector2.zero);

            CreateButton("LowBtn", card, "НИЗКОЕ (30 FPS)", new Vector2(0.5f, 0.56f), new Vector2(0.5f, 0.56f), new Vector2(-215, 0), new Vector2(200, 68), new Color(0.22f, 0.26f, 0.34f, 1f), () =>
            {
                GameManager.Instance?.Quality?.ApplyTier(MobileQualityTier.Low);
                EventBus.Publish(new ToastNotificationEvent("Графика: Низкое"));
            }, new Vector2(0.5f, 0.5f));

            CreateButton("MedBtn", card, "СРЕДНЕЕ (60 FPS)", new Vector2(0.5f, 0.56f), new Vector2(0.5f, 0.56f), new Vector2(0, 0), new Vector2(205, 68), new Color(0.14f, 0.50f, 0.78f, 1f), () =>
            {
                GameManager.Instance?.Quality?.ApplyTier(MobileQualityTier.Medium);
                EventBus.Publish(new ToastNotificationEvent("Графика: Среднее"));
            }, new Vector2(0.5f, 0.5f));

            CreateButton("HighBtn", card, "ВЫСОКОЕ (60 FPS)", new Vector2(0.5f, 0.56f), new Vector2(0.5f, 0.56f), new Vector2(215, 0), new Vector2(205, 68), new Color(0.16f, 0.62f, 0.42f, 1f), () =>
            {
                GameManager.Instance?.Quality?.ApplyTier(MobileQualityTier.High);
                EventBus.Publish(new ToastNotificationEvent("Графика: Высокое"));
            }, new Vector2(0.5f, 0.5f));

            CreateButton("CloseSettingsBtn", card, "ЗАКРЫТЬ", new Vector2(0.5f, 0.14f), new Vector2(0.5f, 0.14f), Vector2.zero, new Vector2(280, 72), new Color(0.24f, 0.28f, 0.36f, 1f), () => root.gameObject.SetActive(false), new Vector2(0.5f, 0.5f));

            root.gameObject.SetActive(false);
            return root.gameObject;
        }

        private void BuildDealershipPanel(Transform parent)
        {
            var ctrl = gameObject.AddComponent<DealershipUIController>();
            var root = CreatePanel("DealershipPanel", parent, Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero, new Color(0.04f, 0.06f, 0.10f, 0.90f));
            var card = CreatePanel("Card", root, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(960, 680), new Color(0.10f, 0.13f, 0.19f, 1f), new Vector2(0.5f, 0.5f));

            ctrl.PanelRoot = root.gameObject;
            ctrl.BalanceHeader = CreateTextAnchored("Header", card, "SOLARA MOTORS", 32, new Color(0.28f, 0.88f, 1f), TextAnchor.MiddleLeft, new Vector2(0, 0.86f), new Vector2(0.8f, 0.98f), new Vector2(28, 0), Vector2.zero);

            CreateButton("CloseDealership", card, "✕", new Vector2(1, 1), new Vector2(1, 1), new Vector2(-24, -22), new Vector2(64, 64), new Color(0.65f, 0.18f, 0.22f, 1f), ctrl.Close, new Vector2(1, 1));

            var list = CreateRect("ListContainer", card, new Vector2(0.04f, 0.06f), new Vector2(0.96f, 0.84f), Vector2.zero, Vector2.zero);
            var vlg = list.gameObject.AddComponent<VerticalLayoutGroup>();
            vlg.spacing = 14f;
            vlg.childForceExpandWidth = true;
            vlg.childForceExpandHeight = false;
            ctrl.ListContainer = list;

            root.gameObject.SetActive(false);
        }

        private void BuildMissionsPanel(Transform parent, MissionListUI ctrl)
        {
            var root = CreatePanel("MissionsPanel", parent, Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero, new Color(0.04f, 0.06f, 0.10f, 0.90f));
            var card = CreatePanel("Card", root, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(960, 680), new Color(0.10f, 0.13f, 0.19f, 1f), new Vector2(0.5f, 0.5f));

            ctrl.PanelRoot = root.gameObject;
            CreateTextAnchored("Header", card, "ДОСТУПНЫЕ ЗАДАНИЯ", 32, new Color(0.28f, 0.88f, 1f), TextAnchor.MiddleLeft, new Vector2(0, 0.86f), new Vector2(0.8f, 0.98f), new Vector2(28, 0), Vector2.zero);
            CreateButton("CloseMissions", card, "✕", new Vector2(1, 1), new Vector2(1, 1), new Vector2(-24, -22), new Vector2(64, 64), new Color(0.65f, 0.18f, 0.22f, 1f), ctrl.Close, new Vector2(1, 1));

            var list = CreateRect("ListContainer", card, new Vector2(0.04f, 0.06f), new Vector2(0.96f, 0.84f), Vector2.zero, Vector2.zero);
            var vlg = list.gameObject.AddComponent<VerticalLayoutGroup>();
            vlg.spacing = 14f;
            vlg.childForceExpandWidth = true;
            vlg.childForceExpandHeight = false;
            ctrl.ListContainer = list;

            root.gameObject.SetActive(false);
        }

        public static void CreateShopRow(Transform parent, string labelText, string buttonText, Action onClick)
        {
            var row = CreatePanel("Row", parent, Vector2.zero, Vector2.one, Vector2.zero, new Vector2(0, 108), new Color(0.14f, 0.18f, 0.25f, 1f));
            var le = row.gameObject.AddComponent<LayoutElement>();
            le.preferredHeight = 108f;

            CreateTextAnchored("Info", row, labelText, 22, Color.white, TextAnchor.MiddleLeft, new Vector2(0, 0), new Vector2(0.68f, 1), new Vector2(20, 8), new Vector2(-10, -8));
            CreateButton("ActionBtn", row, buttonText, new Vector2(1, 0.5f), new Vector2(1, 0.5f), new Vector2(-18, 0), new Vector2(250, 68), new Color(0.14f, 0.58f, 0.82f, 1f), onClick, new Vector2(1, 0.5f));
        }

        private void CreateJoystick(Transform parent)
        {
            var bg = CreatePanel("JoystickBG", parent, new Vector2(0, 0), new Vector2(0, 0), new Vector2(65, 65), new Vector2(230, 230), new Color(0.10f, 0.13f, 0.19f, 0.55f), new Vector2(0, 0));
            var handle = CreatePanel("JoystickHandle", bg, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(96, 96), new Color(0.28f, 0.82f, 1f, 0.88f), new Vector2(0.5f, 0.5f));
            var joy = bg.gameObject.AddComponent<VirtualJoystick>();
            joy.Background = bg;
            joy.Handle = handle;
        }

        private Slider CreateHealthSlider(Transform parent)
        {
            var obj = new GameObject("HealthSlider");
            obj.transform.SetParent(parent, false);
            var rect = obj.AddComponent<RectTransform>();
            rect.anchorMin = new Vector2(0.06f, 0.16f);
            rect.anchorMax = new Vector2(0.94f, 0.42f);
            rect.offsetMin = Vector2.zero;
            rect.offsetMax = Vector2.zero;

            var bg = obj.AddComponent<Image>();
            bg.color = new Color(0.22f, 0.10f, 0.12f, 1f);

            var fillArea = CreateRect("FillArea", obj.transform, Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero);
            var fill = CreatePanel("Fill", fillArea, Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero, new Color(0.88f, 0.22f, 0.28f, 1f));

            var slider = obj.AddComponent<Slider>();
            slider.interactable = false;
            slider.fillRect = fill;
            slider.minValue = 0f;
            slider.maxValue = 1f;
            slider.value = 1f;
            return slider;
        }

        private static void EnsureEventSystem()
        {
            if (FindFirstObjectByType<EventSystem>() != null) return;
            var es = new GameObject("EventSystem");
            es.AddComponent<EventSystem>();
#if ENABLE_INPUT_SYSTEM
            es.AddComponent<InputSystemUIInputModule>();
#else
            es.AddComponent<StandaloneInputModule>();
#endif
        }

        private static RectTransform CreateRect(string name, Transform parent, Vector2 anchorMin, Vector2 anchorMax, Vector2 offsetMin, Vector2 offsetMax)
        {
            var go = new GameObject(name);
            go.transform.SetParent(parent, false);
            var rt = go.AddComponent<RectTransform>();
            rt.anchorMin = anchorMin;
            rt.anchorMax = anchorMax;
            rt.offsetMin = offsetMin;
            rt.offsetMax = offsetMax;
            return rt;
        }

        private static RectTransform CreatePanel(string name, Transform parent, Vector2 anchorMin, Vector2 anchorMax, Vector2 anchoredPos, Vector2 sizeDelta, Color color, Vector2? pivot = null)
        {
            var go = new GameObject(name);
            go.transform.SetParent(parent, false);
            var rt = go.AddComponent<RectTransform>();
            rt.anchorMin = anchorMin;
            rt.anchorMax = anchorMax;
            if (pivot.HasValue) rt.pivot = pivot.Value;
            rt.anchoredPosition = anchoredPos;
            rt.sizeDelta = sizeDelta;
            var img = go.AddComponent<Image>();
            img.color = color;
            return rt;
        }

        private static Text CreateText(string name, Transform parent, string content, int size, Color color, TextAnchor align)
        {
            return CreateTextAnchored(name, parent, content, size, color, align, Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero);
        }

        private static Text CreateTextAnchored(string name, Transform parent, string content, int size, Color color, TextAnchor align, Vector2 min, Vector2 max, Vector2 offsetMin, Vector2 offsetMax)
        {
            var go = new GameObject(name);
            go.transform.SetParent(parent, false);
            var rt = go.AddComponent<RectTransform>();
            rt.anchorMin = min;
            rt.anchorMax = max;
            rt.offsetMin = offsetMin;
            rt.offsetMax = offsetMax;
            var txt = go.AddComponent<Text>();
            txt.font = GetFont();
            txt.text = content;
            txt.fontSize = size;
            txt.color = color;
            txt.alignment = align;
            txt.horizontalOverflow = HorizontalWrapMode.Wrap;
            txt.verticalOverflow = VerticalWrapMode.Overflow;
            return txt;
        }

        private static Button CreateButton(string name, Transform parent, string label, Vector2 anchorMin, Vector2 anchorMax, Vector2 anchoredPos, Vector2 sizeDelta, Color bgColor, Action onClick, Vector2 pivot)
        {
            var rt = CreatePanel(name, parent, anchorMin, anchorMax, anchoredPos, sizeDelta, bgColor, pivot);
            var btn = rt.gameObject.AddComponent<Button>();
            btn.targetGraphic = rt.GetComponent<Image>();
            if (onClick != null) btn.onClick.AddListener(() => onClick());
            CreateText("Label", rt, label, 22, Color.white, TextAnchor.MiddleCenter);
            return btn;
        }
    }
}
