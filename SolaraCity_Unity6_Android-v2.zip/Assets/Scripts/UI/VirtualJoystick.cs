using UnityEngine;
using UnityEngine.EventSystems;
using SolaraCity.Core;

namespace SolaraCity.UI
{
    public class VirtualJoystick : MonoBehaviour, IPointerDownHandler, IDragHandler, IPointerUpHandler
    {
        public RectTransform Background;
        public RectTransform Handle;
        [SerializeField] private float maxRadius = 85f;

        private Vector2 _input;

        public void OnPointerDown(PointerEventData eventData)
        {
            OnDrag(eventData);
        }

        public void OnDrag(PointerEventData eventData)
        {
            if (Background == null || Handle == null) return;
            if (RectTransformUtility.ScreenPointToLocalPointInRectangle(Background, eventData.position, eventData.pressEventCamera, out Vector2 localPoint))
            {
                Vector2 clamped = Vector2.ClampMagnitude(localPoint, maxRadius);
                Handle.anchoredPosition = clamped;
                _input = clamped / maxRadius;
                PushInput(_input);
            }
        }

        public void OnPointerUp(PointerEventData eventData)
        {
            _input = Vector2.zero;
            if (Handle != null) Handle.anchoredPosition = Vector2.zero;
            PushInput(Vector2.zero);
        }

        private void OnDisable()
        {
            _input = Vector2.zero;
            if (Handle != null) Handle.anchoredPosition = Vector2.zero;
            PushInput(Vector2.zero);
        }

        private static void PushInput(Vector2 dir)
        {
            var player = GameManager.Instance?.Player;
            if (player != null && player.InputHandler != null)
                player.InputHandler.SetMobileMove(dir);
        }
    }
}
