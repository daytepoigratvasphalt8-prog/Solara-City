using UnityEngine;
using UnityEngine.UI;
using SolaraCity.Core;

namespace SolaraCity.UI
{
    public class MobileHUDController : MonoBehaviour
    {
        public GameObject HudRoot;
        public GameObject OnFootControlsRoot;
        public GameObject VehicleControlsRoot;
        public GameObject MainMenuRoot;
        public GameObject PauseMenuRoot;
        public GameObject SettingsMenuRoot;
        public GameObject MissionsPanelRoot;

        public Text CashText;
        public Slider HealthBar;
        public Text SpeedText;
        public Text MissionTitleText;
        public Text MissionObjectiveText;
        public GameObject MissionTrackerBox;
        public Button InteractButton;
        public Text InteractButtonText;
        public Text ToastText;
        public GameObject ToastBox;

        private float _toastTimer;

        private void OnEnable()
        {
            EventBus.Subscribe<GameStateChangedEvent>(OnGameStateChanged);
            EventBus.Subscribe<MoneyChangedEvent>(OnMoneyChanged);
            EventBus.Subscribe<HealthChangedEvent>(OnHealthChanged);
            EventBus.Subscribe<InteractablePromptEvent>(OnInteractPrompt);
            EventBus.Subscribe<MissionUpdatedEvent>(OnMissionUpdated);
            EventBus.Subscribe<ToastNotificationEvent>(OnToast);
        }

        private void OnDisable()
        {
            EventBus.Unsubscribe<GameStateChangedEvent>(OnGameStateChanged);
            EventBus.Unsubscribe<MoneyChangedEvent>(OnMoneyChanged);
            EventBus.Unsubscribe<HealthChangedEvent>(OnHealthChanged);
            EventBus.Unsubscribe<InteractablePromptEvent>(OnInteractPrompt);
            EventBus.Unsubscribe<MissionUpdatedEvent>(OnMissionUpdated);
            EventBus.Unsubscribe<ToastNotificationEvent>(OnToast);
        }

        private void Update()
        {
            if (_toastTimer > 0f)
            {
                _toastTimer -= Time.unscaledDeltaTime;
                if (_toastTimer <= 0f && ToastBox != null)
                    ToastBox.SetActive(false);
            }

            if (SpeedText != null && GameManager.Instance != null && GameManager.Instance.ActiveVehicle != null)
            {
                var veh = GameManager.Instance.ActiveVehicle;
                SpeedText.text = $"{Mathf.RoundToInt(veh.SpeedKmh)} KM/H  |  Топливо {Mathf.RoundToInt(veh.Fuel)}%";
            }
        }

        private void OnGameStateChanged(GameStateChangedEvent evt)
        {
            bool inGameplay = evt.Current == GameState.PlayingOnFoot || evt.Current == GameState.PlayingInVehicle;
            if (HudRoot != null) HudRoot.SetActive(inGameplay);
            if (OnFootControlsRoot != null) OnFootControlsRoot.SetActive(evt.Current == GameState.PlayingOnFoot);
            if (VehicleControlsRoot != null) VehicleControlsRoot.SetActive(evt.Current == GameState.PlayingInVehicle);
            if (MainMenuRoot != null) MainMenuRoot.SetActive(evt.Current == GameState.MainMenu);
            if (PauseMenuRoot != null) PauseMenuRoot.SetActive(evt.Current == GameState.Paused);
            if (SettingsMenuRoot != null && evt.Current != GameState.Paused && evt.Current != GameState.MainMenu)
                SettingsMenuRoot.SetActive(false);
            if (MissionsPanelRoot != null && evt.Current != GameState.InMenuOverlay)
                MissionsPanelRoot.SetActive(false);
        }

        private void OnMoneyChanged(MoneyChangedEvent evt)
        {
            if (CashText != null) CashText.text = $"$ {evt.NewBalance:N0}";
        }

        private void OnHealthChanged(HealthChangedEvent evt)
        {
            if (HealthBar != null)
                HealthBar.value = evt.Max > 0f ? evt.Current / evt.Max : 0f;
        }

        private void OnInteractPrompt(InteractablePromptEvent evt)
        {
            if (InteractButton != null) InteractButton.gameObject.SetActive(evt.Visible);
            if (InteractButtonText != null && evt.Visible) InteractButtonText.text = evt.Label;
        }

        private void OnMissionUpdated(MissionUpdatedEvent evt)
        {
            if (MissionTrackerBox != null) MissionTrackerBox.SetActive(evt.IsActive);
            if (MissionTitleText != null) MissionTitleText.text = evt.Title;
            if (MissionObjectiveText != null) MissionObjectiveText.text = evt.ObjectiveText;
        }

        private void OnToast(ToastNotificationEvent evt)
        {
            if (ToastBox == null || ToastText == null) return;
            ToastText.text = evt.Message;
            ToastBox.SetActive(true);
            _toastTimer = evt.Duration;
        }
    }
}
