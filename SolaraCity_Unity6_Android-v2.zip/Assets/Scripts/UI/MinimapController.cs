using UnityEngine;
using SolaraCity.Core;

namespace SolaraCity.UI
{
    public class MinimapController : MonoBehaviour
    {
        public RenderTexture RenderTexture { get; private set; }
        private Camera _minimapCamera;
        private Transform _fallbackTarget;

        public void Initialize(Transform playerTransform)
        {
            _fallbackTarget = playerTransform;
            RenderTexture = new RenderTexture(256, 256, 16, RenderTextureFormat.ARGB32)
            {
                name = "MinimapRT",
                antiAliasing = 1
            };

            var camObj = new GameObject("MinimapCamera");
            camObj.transform.SetParent(transform, false);
            _minimapCamera = camObj.AddComponent<Camera>();
            _minimapCamera.orthographic = true;
            _minimapCamera.orthographicSize = 55f;
            _minimapCamera.clearFlags = CameraClearFlags.SolidColor;
            _minimapCamera.backgroundColor = new Color(0.11f, 0.14f, 0.19f);
            _minimapCamera.targetTexture = RenderTexture;
            _minimapCamera.depth = -10;
            _minimapCamera.farClipPlane = 200f;
            camObj.transform.rotation = Quaternion.Euler(90f, 0f, 0f);
        }

        private void LateUpdate()
        {
            if (_minimapCamera == null) return;
            Transform tracked = GameManager.Instance?.ActiveVehicle != null
                ? GameManager.Instance.ActiveVehicle.transform
                : (GameManager.Instance?.Player != null ? GameManager.Instance.Player.transform : _fallbackTarget);

            if (tracked == null) return;
            _minimapCamera.transform.position = new Vector3(tracked.position.x, 110f, tracked.position.z);
            float yaw = Camera.main != null ? Camera.main.transform.eulerAngles.y : tracked.eulerAngles.y;
            _minimapCamera.transform.rotation = Quaternion.Euler(90f, yaw, 0f);
        }

        private void OnDestroy()
        {
            if (RenderTexture != null)
            {
                RenderTexture.Release();
                Destroy(RenderTexture);
            }
        }
    }
}
