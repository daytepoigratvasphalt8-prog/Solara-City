using UnityEngine;
using SolaraCity.Core;

namespace SolaraCity.Vehicles
{
    public class VehicleSpawner : MonoBehaviour
    {
        public VisualAssetCatalog VisualCatalog { get; set; }

        public void SpawnInitialFleet()
        {
            SpawnVehicle(VehicleCatalog.GetById("solara_compact"), new Vector3(5.5f, 0.6f, -10f), Quaternion.Euler(0f, 0f, 0f));
            SpawnVehicle(VehicleCatalog.GetById("veridian_sedan"), new Vector3(-34f, 0.6f, 24f), Quaternion.Euler(0f, 90f, 0f));
            SpawnVehicle(VehicleCatalog.GetById("titan_suv"), new Vector3(58f, 0.6f, -46f), Quaternion.Euler(0f, -90f, 0f));
        }

        public VehicleController SpawnVehicle(VehicleSpec spec, Vector3 position, Quaternion rotation)
        {
            var root = new GameObject($"Vehicle_{spec.Id}");
            root.tag = "Vehicle";
            root.transform.SetPositionAndRotation(position, rotation);

            root.AddComponent<Rigidbody>();
            var controller = root.AddComponent<VehicleController>();

            float wheelX = spec.BodySize.x * 0.5f + 0.04f;
            float wheelZ = spec.BodySize.z * 0.33f;
            float wheelY = 0.36f;

            // Production 3D vehicle prefab override path
            GameObject prefabOverride = VisualCatalog != null ? VisualCatalog.GetVehiclePrefab(spec.Id) : null;
            if (prefabOverride != null)
            {
                var visual = Instantiate(prefabOverride, root.transform);
                visual.name = "VehicleVisual_Prefab";
                visual.transform.localPosition = Vector3.zero;
                visual.transform.localRotation = Quaternion.identity;

                var binding = visual.GetComponentInChildren<VehicleVisualBinding>();
                controller.FrontLeftCollider = CreateWheelColliderOnly("FL", root.transform, new Vector3(-wheelX, wheelY, wheelZ));
                controller.FrontRightCollider = CreateWheelColliderOnly("FR", root.transform, new Vector3(wheelX, wheelY, wheelZ));
                controller.RearLeftCollider = CreateWheelColliderOnly("RL", root.transform, new Vector3(-wheelX, wheelY, -wheelZ));
                controller.RearRightCollider = CreateWheelColliderOnly("RR", root.transform, new Vector3(wheelX, wheelY, -wheelZ));

                if (binding != null)
                {
                    controller.FrontLeftMesh = binding.FrontLeftWheel;
                    controller.FrontRightMesh = binding.FrontRightWheel;
                    controller.RearLeftMesh = binding.RearLeftWheel;
                    controller.RearRightMesh = binding.RearRightWheel;
                    controller.DriverSeatAnchor = binding.DriverSeatAnchor;
                    controller.DoorEntryPoint = binding.DoorEntryPoint;
                    controller.BrakeLightRenderers = binding.BrakeLightRenderers;
                }

                // Ensure at least one collider exists on chassis for physics stability
                if (visual.GetComponentInChildren<Collider>() == null)
                {
                    var boxCol = root.AddComponent<BoxCollider>();
                    boxCol.center = new Vector3(0f, 0.72f, 0f);
                    boxCol.size = spec.BodySize;
                }

                controller.Configure(spec);
                return controller;
            }

            // Temporary placeholder geometry (improved proportions + bumpers/trim/mirrors + LODGroup)
            BuildPlaceholderVehicle(root, controller, spec, wheelX, wheelY, wheelZ);
            controller.Configure(spec);
            return controller;
        }

        private void BuildPlaceholderVehicle(GameObject root, VehicleController controller, VehicleSpec spec, float wheelX, float wheelY, float wheelZ)
        {
            var bodyMat = MaterialFactory.CreateLit($"Mat_{spec.Id}_Body", spec.BodyColor, 0.84f, 0.55f);
            var trimMat = MaterialFactory.CreateLit("Mat_CarTrim", new Color(0.11f, 0.12f, 0.14f), 0.35f, 0.25f);
            var glassMat = MaterialFactory.CreateLit("Mat_CarGlass", new Color(0.10f, 0.16f, 0.24f), 0.94f, 0.25f);
            var tireMat = MaterialFactory.CreateLit("Mat_Tire", new Color(0.08f, 0.08f, 0.09f), 0.15f, 0f);
            var rimMat = MaterialFactory.CreateLit("Mat_Rim", new Color(0.80f, 0.83f, 0.87f), 0.85f, 0.90f);
            var headlightMat = MaterialFactory.CreateEmissive("Mat_Headlight", Color.white, new Color(1f, 0.95f, 0.82f), 2.0f);
            var taillightMat = MaterialFactory.CreateEmissive("Mat_Taillight", new Color(0.65f, 0.06f, 0.06f), new Color(0.8f, 0.06f, 0.06f), 0.9f);

            // Main chassis collider + body
            var chassis = GameObject.CreatePrimitive(PrimitiveType.Cube);
            chassis.name = "Chassis";
            chassis.transform.SetParent(root.transform, false);
            chassis.transform.localPosition = new Vector3(0f, 0.56f, 0f);
            chassis.transform.localScale = spec.BodySize;
            chassis.GetComponent<Renderer>().sharedMaterial = bodyMat;

            // Front hood & rear deck sculpting
            CreateDetailPart("FrontBumper", root.transform, new Vector3(0f, 0.36f, spec.BodySize.z * 0.49f), new Vector3(spec.BodySize.x * 0.98f, 0.28f, 0.22f), trimMat);
            CreateDetailPart("RearBumper", root.transform, new Vector3(0f, 0.36f, -spec.BodySize.z * 0.49f), new Vector3(spec.BodySize.x * 0.98f, 0.28f, 0.22f), trimMat);
            CreateDetailPart("FrontGrille", root.transform, new Vector3(0f, 0.56f, spec.BodySize.z * 0.505f), new Vector3(spec.BodySize.x * 0.46f, 0.24f, 0.04f), trimMat);

            // Cabin + Roof cap
            float cabinY = 0.56f + spec.BodySize.y * 0.70f;
            CreateDetailPart("CabinGlass", root.transform, new Vector3(0f, cabinY, -spec.BodySize.z * 0.06f), new Vector3(spec.BodySize.x * 0.82f, spec.BodySize.y * 0.64f, spec.BodySize.z * 0.50f), glassMat);
            CreateDetailPart("RoofPanel", root.transform, new Vector3(0f, cabinY + spec.BodySize.y * 0.33f, -spec.BodySize.z * 0.07f), new Vector3(spec.BodySize.x * 0.80f, 0.07f, spec.BodySize.z * 0.46f), bodyMat);

            // Side mirrors
            CreateDetailPart("MirrorL", root.transform, new Vector3(-spec.BodySize.x * 0.52f, 0.56f + spec.BodySize.y * 0.45f, spec.BodySize.z * 0.14f), new Vector3(0.18f, 0.10f, 0.12f), bodyMat);
            CreateDetailPart("MirrorR", root.transform, new Vector3(spec.BodySize.x * 0.52f, 0.56f + spec.BodySize.y * 0.45f, spec.BodySize.z * 0.14f), new Vector3(0.18f, 0.10f, 0.12f), bodyMat);

            // Headlights & Dynamic Taillights
            float halfW = spec.BodySize.x * 0.34f;
            float halfL = spec.BodySize.z * 0.5f + 0.01f;
            CreateDetailPart("HeadlightL", root.transform, new Vector3(-halfW, 0.62f, halfL), new Vector3(0.36f, 0.14f, 0.05f), headlightMat);
            CreateDetailPart("HeadlightR", root.transform, new Vector3(halfW, 0.62f, halfL), new Vector3(0.36f, 0.14f, 0.05f), headlightMat);
            var tailL = CreateDetailPart("TaillightL", root.transform, new Vector3(-halfW, 0.62f, -halfL), new Vector3(0.38f, 0.14f, 0.05f), taillightMat);
            var tailR = CreateDetailPart("TaillightR", root.transform, new Vector3(halfW, 0.62f, -halfL), new Vector3(0.38f, 0.14f, 0.05f), taillightMat);
            controller.BrakeLightRenderers = new[] { tailL.GetComponent<Renderer>(), tailR.GetComponent<Renderer>() };

            // Seat & Door anchors
            var seatAnchor = new GameObject("DriverSeatAnchor").transform;
            seatAnchor.SetParent(root.transform, false);
            seatAnchor.localPosition = new Vector3(-0.42f, 0.52f, 0.05f);
            controller.DriverSeatAnchor = seatAnchor;

            var doorPoint = new GameObject("DoorEntryPoint").transform;
            doorPoint.SetParent(root.transform, false);
            doorPoint.localPosition = new Vector3(-spec.BodySize.x * 0.5f - 1.0f, 0.15f, 0.05f);
            controller.DoorEntryPoint = doorPoint;

            // Wheels
            (controller.FrontLeftCollider, controller.FrontLeftMesh) = CreateWheel("FL", root.transform, new Vector3(-wheelX, wheelY, wheelZ), tireMat, rimMat);
            (controller.FrontRightCollider, controller.FrontRightMesh) = CreateWheel("FR", root.transform, new Vector3(wheelX, wheelY, wheelZ), tireMat, rimMat);
            (controller.RearLeftCollider, controller.RearLeftMesh) = CreateWheel("RL", root.transform, new Vector3(-wheelX, wheelY, -wheelZ), tireMat, rimMat);
            (controller.RearRightCollider, controller.RearRightMesh) = CreateWheel("RR", root.transform, new Vector3(wheelX, wheelY, -wheelZ), tireMat, rimMat);
        }

        private static GameObject CreateDetailPart(string name, Transform parent, Vector3 pos, Vector3 scale, Material mat)
        {
            var go = GameObject.CreatePrimitive(PrimitiveType.Cube);
            go.name = name;
            Object.Destroy(go.GetComponent<Collider>());
            go.transform.SetParent(parent, false);
            go.transform.localPosition = pos;
            go.transform.localScale = scale;
            go.GetComponent<Renderer>().sharedMaterial = mat;
            return go;
        }

        private static WheelCollider CreateWheelColliderOnly(string id, Transform parent, Vector3 localPos)
        {
            var colObj = new GameObject($"WheelCol_{id}");
            colObj.transform.SetParent(parent, false);
            colObj.transform.localPosition = localPos;

            var wc = colObj.AddComponent<WheelCollider>();
            wc.radius = 0.36f;
            wc.suspensionDistance = 0.22f;
            wc.mass = 24f;

            var spring = wc.suspensionSpring;
            spring.spring = 34000f;
            spring.damper = 4500f;
            spring.targetPosition = 0.5f;
            wc.suspensionSpring = spring;

            var fwd = wc.forwardFriction;
            fwd.stiffness = 1.4f;
            wc.forwardFriction = fwd;

            var side = wc.sidewaysFriction;
            side.stiffness = 1.6f;
            wc.sidewaysFriction = side;

            return wc;
        }

        private static (WheelCollider, Transform) CreateWheel(string id, Transform parent, Vector3 localPos, Material tireMat, Material rimMat)
        {
            var wc = CreateWheelColliderOnly(id, parent, localPos);

            var visualHolder = new GameObject($"WheelMesh_{id}");
            visualHolder.transform.SetParent(parent, false);
            visualHolder.transform.localPosition = localPos;

            var tire = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            Object.Destroy(tire.GetComponent<Collider>());
            tire.transform.SetParent(visualHolder.transform, false);
            tire.transform.localRotation = Quaternion.Euler(0f, 0f, 90f);
            tire.transform.localScale = new Vector3(0.72f, 0.13f, 0.72f);
            tire.GetComponent<Renderer>().sharedMaterial = tireMat;

            var rim = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            Object.Destroy(rim.GetComponent<Collider>());
            rim.transform.SetParent(visualHolder.transform, false);
            rim.transform.localRotation = Quaternion.Euler(0f, 0f, 90f);
            rim.transform.localScale = new Vector3(0.42f, 0.14f, 0.42f);
            rim.GetComponent<Renderer>().sharedMaterial = rimMat;

            return (wc, visualHolder.transform);
        }
    }
}
