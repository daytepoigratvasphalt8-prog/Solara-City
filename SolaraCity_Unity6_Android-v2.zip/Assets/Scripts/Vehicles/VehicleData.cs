using System;
using UnityEngine;

namespace SolaraCity.Vehicles
{
    [Serializable]
    public class VehicleSpec
    {
        public string Id;
        public string DisplayName;
        public string Category;
        public int Price;
        public Color BodyColor;
        public float MotorTorque;
        public float BrakeTorque;
        public float MaxSteerAngle;
        public float MaxSpeedKmh;
        public float Mass;
        public Vector3 BodySize;
    }

    [CreateAssetMenu(fileName = "VehicleData", menuName = "SolaraCity/Vehicle Data")]
    public class VehicleData : ScriptableObject
    {
        public VehicleSpec Spec = new VehicleSpec();
    }
}
