using UnityEngine;
using SolaraCity.Core;
using SolaraCity.World;

namespace SolaraCity.Vehicles
{
    [RequireComponent(typeof(Rigidbody))]
    public class VehicleController : MonoBehaviour, IInteractable
    {
        public string VehicleId { get; private set; }
        public string DisplayName { get; private set; } = "Solara Auto";
        public VehicleCameraProfile CameraProfile { get; } = new VehicleCameraProfile();

        public WheelCollider FrontLeftCollider;
        public WheelCollider FrontRightCollider;
        public WheelCollider RearLeftCollider;
        public WheelCollider RearRightCollider;

        public Transform FrontLeftMesh;
        public Transform FrontRightMesh;
        public Transform RearLeftMesh;
        public Transform RearRightMesh;

        public Transform DriverSeatAnchor;
        public Transform DoorEntryPoint;
        public Renderer[] BrakeLightRenderers;

        public float MotorTorque = 1600f;
        public float BrakeTorque = 3200f;
        public float MaxSteerAngle = 32f;
        public float MaxSpeedKmh = 140f;
        public float AntiRollForce = 4500f;

        public float Fuel { get; private set; } = 100f;
        public float Durability { get; private set; } = 100f;
        public float SpeedKmh => _rb != null ? _rb.linearVelocity.magnitude * 3.6f : 0f;
        public bool HasDriver { get; private set; }

        public bool CanInteract => !HasDriver;
        public string InteractionPrompt => $"Сесть в {DisplayName}";

        private Rigidbody _rb;
        private Material _brakeIdleMat;
        private Material _brakeActiveMat;
        private bool _isBrakingVisual;

        public void Configure(VehicleSpec spec)
        {
            VehicleId = spec.Id;
            DisplayName = spec.DisplayName;
            MotorTorque = spec.MotorTorque;
            BrakeTorque = spec.BrakeTorque;
            MaxSteerAngle = spec.MaxSteerAngle;
            MaxSpeedKmh = spec.MaxSpeedKmh;

            _rb = GetComponent<Rigidbody>();
            _rb.mass = spec.Mass;
            _rb.centerOfMass = new Vector3(0f, -0.45f, 0f);
            _rb.interpolation = RigidbodyInterpolation.Interpolate;
            _rb.linearDamping = 0.08f;
            _rb.angularDamping = 0.6f;

            _brakeIdleMat = MaterialFactory.CreateEmissive("Mat_BrakeIdle", new Color(0.55f, 0.06f, 0.06f), new Color(0.7f, 0.05f, 0.05f), 0.7f);
            _brakeActiveMat = MaterialFactory.CreateEmissive("Mat_BrakeActive", new Color(0.95f, 0.12f, 0.12f), new Color(1.0f, 0.12f, 0.08f), 2.8f);
        }

        private void Awake()
        {
            _rb = GetComponent<Rigidbody>();
            _rb.centerOfMass = new Vector3(0f, -0.45f, 0f);
        }

        public void Interact(GameObject interactor)
        {
            if (GameManager.Instance != null)
                GameManager.Instance.EnterVehicle(this);
        }

        public void SetDriverActive(bool active)
        {
            HasDriver = active;
            if (!active)
            {
                ApplyBrakeAll(BrakeTorque * 0.7f);
                SetMotorTorque(0f);
                SetBrakeLights(false);
            }
        }

        public void RefuelAndRepair()
        {
            Fuel = 100f;
            Durability = 100f;
        }

        public Vector3 GetSafeExitPosition()
        {
            if (DoorEntryPoint != null)
            {
                Vector3 doorPos = DoorEntryPoint.position + Vector3.up * 0.25f;
                if (!Physics.CheckSphere(doorPos + Vector3.up * 0.6f, 0.38f, ~0, QueryTriggerInteraction.Ignore))
                    return doorPos;
            }

            Vector3[] offsets =
            {
                -transform.right * 2.1f + Vector3.up * 0.5f,
                transform.right * 2.1f + Vector3.up * 0.5f,
                -transform.forward * 3.0f + Vector3.up * 0.5f,
                Vector3.up * 2.2f
            };

            foreach (var offset in offsets)
            {
                Vector3 candidate = transform.position + offset;
                if (!Physics.CheckSphere(candidate + Vector3.up * 0.6f, 0.38f, ~0, QueryTriggerInteraction.Ignore))
                    return candidate;
            }

            return transform.position + Vector3.up * 2.2f;
        }

        private void FixedUpdate()
        {
            if (FrontLeftCollider == null || RearLeftCollider == null) return;

            ApplyAntiRoll(FrontLeftCollider, FrontRightCollider);
            ApplyAntiRoll(RearLeftCollider, RearRightCollider);

            if (!HasDriver || GameManager.Instance == null || GameManager.Instance.CurrentState != GameState.PlayingInVehicle)
            {
                ApplyBrakeAll(BrakeTorque * 0.5f);
                SetMotorTorque(0f);
                UpdateAllWheelVisuals();
                return;
            }

            var input = GameManager.Instance.Player.InputHandler;
            float throttle = input.VehicleThrottle;
            float brakeInput = input.VehicleBrake;
            float steer = input.VehicleSteer;

            float speed = SpeedKmh;
            float forwardDot = Vector3.Dot(_rb.linearVelocity, transform.forward);

            float steerLimit = Mathf.Lerp(MaxSteerAngle, MaxSteerAngle * 0.45f, Mathf.Clamp01(speed / MaxSpeedKmh));
            float steerAngle = steer * steerLimit;
            FrontLeftCollider.steerAngle = steerAngle;
            FrontRightCollider.steerAngle = steerAngle;

            bool brakingNow = false;

            if (Fuel <= 0.1f)
            {
                SetMotorTorque(0f);
                ApplyBrakeAll(brakeInput * BrakeTorque);
                brakingNow = brakeInput > 0.05f;
            }
            else if (throttle > 0.05f && speed < MaxSpeedKmh)
            {
                ApplyBrakeAll(0f);
                SetMotorTorque(throttle * MotorTorque);
                Fuel = Mathf.Max(0f, Fuel - Time.fixedDeltaTime * 0.12f);
            }
            else if (brakeInput > 0.05f)
            {
                brakingNow = true;
                if (forwardDot > 1.5f)
                {
                    SetMotorTorque(0f);
                    ApplyBrakeAll(brakeInput * BrakeTorque);
                }
                else
                {
                    ApplyBrakeAll(0f);
                    SetMotorTorque(-brakeInput * MotorTorque * 0.6f);
                }
            }
            else
            {
                SetMotorTorque(0f);
                ApplyBrakeAll(BrakeTorque * 0.08f);
            }

            SetBrakeLights(brakingNow);
            UpdateAllWheelVisuals();
        }

        private void SetBrakeLights(bool active)
        {
            if (_isBrakingVisual == active || BrakeLightRenderers == null || _brakeIdleMat == null) return;
            _isBrakingVisual = active;
            var mat = active ? _brakeActiveMat : _brakeIdleMat;
            foreach (var rend in BrakeLightRenderers)
                if (rend != null) rend.sharedMaterial = mat;
        }

        private void SetMotorTorque(float torque)
        {
            RearLeftCollider.motorTorque = torque;
            RearRightCollider.motorTorque = torque;
            FrontLeftCollider.motorTorque = torque * 0.35f;
            FrontRightCollider.motorTorque = torque * 0.35f;
        }

        private void ApplyBrakeAll(float torque)
        {
            FrontLeftCollider.brakeTorque = torque;
            FrontRightCollider.brakeTorque = torque;
            RearLeftCollider.brakeTorque = torque;
            RearRightCollider.brakeTorque = torque;
        }

        private void ApplyAntiRoll(WheelCollider left, WheelCollider right)
        {
            float travelL = 1.0f;
            float travelR = 1.0f;

            bool groundedL = left.GetGroundHit(out WheelHit hitL);
            if (groundedL)
                travelL = (-left.transform.InverseTransformPoint(hitL.point).y - left.radius) / left.suspensionDistance;

            bool groundedR = right.GetGroundHit(out WheelHit hitR);
            if (groundedR)
                travelR = (-right.transform.InverseTransformPoint(hitR.point).y - right.radius) / right.suspensionDistance;

            float antiRoll = (travelL - travelR) * AntiRollForce;
            if (groundedL)
                _rb.AddForceAtPosition(left.transform.up * -antiRoll, left.transform.position);
            if (groundedR)
                _rb.AddForceAtPosition(right.transform.up * antiRoll, right.transform.position);
        }

        private void UpdateAllWheelVisuals()
        {
            SyncWheel(FrontLeftCollider, FrontLeftMesh);
            SyncWheel(FrontRightCollider, FrontRightMesh);
            SyncWheel(RearLeftCollider, RearLeftMesh);
            SyncWheel(RearRightCollider, RearRightMesh);
        }

        private static void SyncWheel(WheelCollider col, Transform mesh)
        {
            if (col == null || mesh == null) return;
            col.GetWorldPose(out Vector3 pos, out Quaternion rot);
            mesh.position = pos;
            mesh.rotation = rot;
        }
    }
}
