using UnityEngine;

namespace SolaraCity.Vehicles
{
    /// <summary>
    /// Attach this component to any imported high-detail 3D vehicle prefab (FBX/GLTF)
    /// so VehicleSpawner automatically binds its real wheel meshes, seat anchor,
    /// door entry point, and lights to the existing WheelCollider physics controller.
    /// </summary>
    public class VehicleVisualBinding : MonoBehaviour
    {
        [Header("Wheel Visual Meshes")]
        public Transform FrontLeftWheel;
        public Transform FrontRightWheel;
        public Transform RearLeftWheel;
        public Transform RearRightWheel;

        [Header("Character Interaction Anchors")]
        public Transform DriverSeatAnchor;
        public Transform DoorEntryPoint;

        [Header("Dynamic Lights")]
        public Renderer[] HeadlightRenderers;
        public Renderer[] BrakeLightRenderers;
    }
}
