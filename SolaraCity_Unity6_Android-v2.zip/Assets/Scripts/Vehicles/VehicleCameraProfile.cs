using System;

namespace SolaraCity.Vehicles
{
    [Serializable]
    public class VehicleCameraProfile
    {
        public float Distance = 7.2f;
        public float Height = 2.1f;
        public float LookHeight = 0.4f;
    }
}
