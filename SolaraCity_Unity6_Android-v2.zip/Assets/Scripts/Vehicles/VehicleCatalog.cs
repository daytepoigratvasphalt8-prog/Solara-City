using System.Collections.Generic;
using UnityEngine;

namespace SolaraCity.Vehicles
{
    public static class VehicleCatalog
    {
        public static readonly List<VehicleSpec> AllVehicles = new List<VehicleSpec>
        {
            new VehicleSpec
            {
                Id = "solara_compact",
                DisplayName = "Solara Pulse",
                Category = "Городской хэтчбек",
                Price = 0,
                BodyColor = new Color(0.18f, 0.52f, 0.88f),
                MotorTorque = 1550f,
                BrakeTorque = 3200f,
                MaxSteerAngle = 34f,
                MaxSpeedKmh = 135f,
                Mass = 1250f,
                BodySize = new Vector3(1.85f, 0.72f, 4.1f)
            },
            new VehicleSpec
            {
                Id = "veridian_sedan",
                DisplayName = "Veridian Executive",
                Category = "Бизнес-седан",
                Price = 12000,
                BodyColor = new Color(0.15f, 0.17f, 0.21f),
                MotorTorque = 2100f,
                BrakeTorque = 3800f,
                MaxSteerAngle = 31f,
                MaxSpeedKmh = 175f,
                Mass = 1550f,
                BodySize = new Vector3(1.95f, 0.74f, 4.65f)
            },
            new VehicleSpec
            {
                Id = "titan_suv",
                DisplayName = "Titan Ridge 4x4",
                Category = "Внедорожник",
                Price = 28000,
                BodyColor = new Color(0.22f, 0.36f, 0.28f),
                MotorTorque = 2600f,
                BrakeTorque = 4200f,
                MaxSteerAngle = 30f,
                MaxSpeedKmh = 160f,
                Mass = 2100f,
                BodySize = new Vector3(2.1f, 0.95f, 4.85f)
            },
            new VehicleSpec
            {
                Id = "apex_gt",
                DisplayName = "Apex Solara GT",
                Category = "Спорткар",
                Price = 45000,
                BodyColor = new Color(0.84f, 0.14f, 0.18f),
                MotorTorque = 3200f,
                BrakeTorque = 5000f,
                MaxSteerAngle = 29f,
                MaxSpeedKmh = 235f,
                Mass = 1380f,
                BodySize = new Vector3(2.02f, 0.62f, 4.55f)
            }
        };

        public static VehicleSpec GetById(string id)
        {
            foreach (var v in AllVehicles)
                if (v.Id == id) return v;
            return AllVehicles[0];
        }
    }
}
